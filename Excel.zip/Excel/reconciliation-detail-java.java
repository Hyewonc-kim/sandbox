// ============================================================================
//  정합결과 상세 조회 레포트 (4번 탭) — 추가/수정 파일
//
//  기존 1~3번 탭 코드는 그대로 유지하면서 이 탭만 추가합니다.
//  - enums/ReportType : 항목 1개 추가
//  - dto/ReconciliationDetailReport : 신규
//  - service/exporter/ReconciliationExcelExporter : 신규
//  - service/exporter/ReconciliationHtmlExporter  : 신규
//  - service/ReconciliationDataProvider : 신규
//  - service/ReportService : exportReconciliation() 메서드 추가
//  - controller/ReportController : 엔드포인트 추가
// ============================================================================


// ============================================================================
//  1. ENUM 확장
// ============================================================================
package com.ktds.report.enums;

public enum ReportType {
    COVERAGE_STATUS         ("커버리지_현황"),
    PRODUCT_COVERAGE_DETAIL ("상품별_커버리지_상세"),
    ITEM_STATUS             ("아이템별_현황"),
    RECONCILIATION_DETAIL   ("정합결과_상세조회");    // ← 신규

    private final String displayName;
    ReportType(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}


// ============================================================================
//  2. DTO — 정합결과 상세 조회
// ============================================================================
package com.ktds.report.dto;

import lombok.Builder;
import lombok.Getter;
import java.time.LocalDateTime;
import java.util.List;

@Getter @Builder
public class ReconciliationDetailReport {

    private String reportTitle;       // "정합결과 상세 조회"
    private String periodLabel;       // "2026년 01월"
    private LocalDateTime generatedAt;
    private String generatedBy;

    private ReconciliationSummary mobile;          // 1) 모바일 정합율 요약
    private ReconciliationSummary internetPhone;   // 1) 인터넷전화 정합율 요약

    private DiscrepancyAnalysis  countAnalysis;    // 2) 불일치 분석 - 건수
    private DiscrepancyAnalysis  amountAnalysis;   // 2) 불일치 분석 - 금액

    private DiscrepancyDetail    discrepancyDetail;// 3) 불일치 상세 내역

    // ──────────────── 1) 정합율 요약 ────────────────
    @Getter @Builder
    public static class ReconciliationSummary {
        private ServiceType   serviceType;        // MOBILE / INTERNET_PHONE
        private Long          totalCount;         // 전체 건수 (null → "—")
        private Long          customerCount;      // 고객 건수
        private Double        amountReconRate;    // 금액 정합율 (%)
        private Double        countReconRate;     // 건수 정합율 (%)
        private Double        amountReconRateByCustomer; // 금액 정합율 (고객단위)
        private Double        countReconRateByCustomer;  // 건수 정합율 (고객단위)
    }

    public enum ServiceType {
        MOBILE         ("📱 모바일",       "mobile"),
        INTERNET_PHONE ("📶 인터넷전화",   "internet");

        private final String label;
        private final String cssClass;
        ServiceType(String label, String cssClass) {
            this.label = label; this.cssClass = cssClass;
        }
        public String getLabel()    { return label; }
        public String getCssClass() { return cssClass; }
    }

    // ──────────────── 2) 불일치 분석 ────────────────
    @Getter @Builder
    public static class DiscrepancyAnalysis {
        private String                  title;          // "불일치 분석 - 건수" / "- 금액"
        private AnalysisMetric          metric;         // COUNT / AMOUNT
        private List<DiscrepancyRow>    rows;
        private DiscrepancyRow          totalRow;       // 합계 행
    }

    public enum AnalysisMetric {
        COUNT  ("건수",  "건"),
        AMOUNT ("금액",  "원");

        private final String label;
        private final String unit;
        AnalysisMetric(String label, String unit) {
            this.label = label; this.unit = unit;
        }
        public String getLabel() { return label; }
        public String getUnit()  { return unit; }
    }

    @Getter @Builder
    public static class DiscrepancyRow {
        private String type;              // 유형 (요금제 / 부가 / 할인 / 기타...)
        private Long   totalValue;        // 전체 건수 또는 전체 금액
        private Long   discrepancyValue;  // 불일치 건수 또는 불일치 금액
        private Double reconRate;         // 정합률 (%)
    }

    // ──────────────── 3) 불일치 상세 내역 ────────────────
    @Getter @Builder
    public static class DiscrepancyDetail {
        private List<DiscrepancyDetailRow> rows;   // 비어있으면 "데이터 없음" 표시
    }

    @Getter @Builder
    public static class DiscrepancyDetailRow {
        private String type;              // 유형
        private String category;          // 카테고리
        private String discrepancyType;   // 불일치 유형
        private String discrepancyReason; // 불일치 사유
        private long   count;             // 건수
    }
}


// ============================================================================
//  3. EXCEL EXPORTER — 정합결과 상세
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.ReconciliationDetailReport;
import com.ktds.report.dto.ReconciliationDetailReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class ReconciliationExcelExporter implements ReportExporter<ReconciliationDetailReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Override public ReportType   supportType()   { return ReportType.RECONCILIATION_DETAIL; }
    @Override public ReportFormat supportFormat() { return ReportFormat.EXCEL; }

    @Override
    public void export(ReconciliationDetailReport data, OutputStream out) throws IOException {
        try (Workbook wb = new XSSFWorkbook()) {
            Styles s = new Styles(wb);
            Sheet sheet = wb.createSheet("정합결과 상세");
            sheet.setDisplayGridlines(false);

            // 컬럼 폭 (8컬럼)
            //  0:라벨   1~2:값/지표   3:공백   4:헤더    5:전체값  6:불일치값  7:정합률(바+%)
            int[] widths = { 6000, 5000, 5000, 1000, 6000, 5000, 5000, 8000 };
            for (int i = 0; i < widths.length; i++) sheet.setColumnWidth(i, widths[i]);

            int rowIdx = 0;
            rowIdx = writeHeader(sheet, s, data, rowIdx);
            rowIdx = writeSummarySection(sheet, s, data.getMobile(),         rowIdx);
            rowIdx++;
            rowIdx = writeSummarySection(sheet, s, data.getInternetPhone(),  rowIdx);
            rowIdx++;
            rowIdx = writeAnalysisSection(sheet, s, data.getCountAnalysis(),  rowIdx);
            rowIdx++;
            rowIdx = writeAnalysisSection(sheet, s, data.getAmountAnalysis(), rowIdx);
            rowIdx++;
            rowIdx = writeDetailSection(sheet, s, data.getDiscrepancyDetail(), rowIdx);
            rowIdx++;
            writeFooter(sheet, s, data, rowIdx);

            // 인쇄 설정
            sheet.setFitToPage(true);
            sheet.getPrintSetup().setFitWidth((short) 1);
            sheet.getPrintSetup().setFitHeight((short) 0);
            sheet.getPrintSetup().setLandscape(true);
            sheet.createFreezePane(0, 3);

            wb.write(out);
        }
    }

    // ────────────────── 헤더 ──────────────────
    private int writeHeader(Sheet sheet, Styles s, ReconciliationDetailReport d, int rowIdx) {
        Row title = sheet.createRow(rowIdx);
        title.setHeightInPoints(32);
        Cell tc = title.createCell(0);
        tc.setCellValue("✓ " + d.getReportTitle());
        tc.setCellStyle(s.title);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 5));

        Cell period = title.createCell(6);
        period.setCellValue(d.getPeriodLabel());
        period.setCellStyle(s.periodTag);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 6, 7));
        rowIdx++;

        Row meta = sheet.createRow(rowIdx++);
        Cell mc = meta.createCell(0);
        mc.setCellValue("생성일시: " + d.getGeneratedAt().format(DTF)
                + "  |  생성자: " + (d.getGeneratedBy() != null ? d.getGeneratedBy() : "-"));
        mc.setCellStyle(s.meta);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        rowIdx++;
        return rowIdx;
    }

    // ────────────────── 섹션 1: 정합율 요약 ──────────────────
    private int writeSummarySection(Sheet sheet, Styles s, ReconciliationSummary sum, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, sum.getServiceType().getLabel() + " 정합율 요약", rowIdx);

        // 2컬럼 레이아웃: [라벨 | 값]   [라벨 | 값]
        rowIdx = writeSummaryRow(sheet, s,
                "전체 건수",            formatCount(sum.getTotalCount()),       false,
                "고객 건수",            formatCount(sum.getCustomerCount()),    false,
                rowIdx);

        rowIdx = writeSummaryRow(sheet, s,
                "금액 정합율",          formatRate(sum.getAmountReconRate()),   true,
                "건수 정합율",          formatRate(sum.getCountReconRate()),    true,
                rowIdx);

        rowIdx = writeSummaryRow(sheet, s,
                "금액 정합율 (고객단위)", formatRate(sum.getAmountReconRateByCustomer()), true,
                "건수 정합율 (고객단위)", formatRate(sum.getCountReconRateByCustomer()),  true,
                rowIdx);

        return rowIdx;
    }

    private int writeSummaryRow(Sheet sheet, Styles s,
                                 String leftLabel,  String leftValue,  boolean leftIsRate,
                                 String rightLabel, String rightValue, boolean rightIsRate,
                                 int rowIdx) {
        Row row = sheet.createRow(rowIdx++);
        row.setHeightInPoints(22);

        Cell l1 = row.createCell(0);
        l1.setCellValue(leftLabel);
        l1.setCellStyle(s.summaryLabel);

        Cell v1 = row.createCell(1);
        v1.setCellValue(leftValue);
        v1.setCellStyle(leftIsRate ? s.summaryRate : s.summaryValue);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 1, 2));

        Cell l2 = row.createCell(4);
        l2.setCellValue(rightLabel);
        l2.setCellStyle(s.summaryLabel);

        Cell v2 = row.createCell(5);
        v2.setCellValue(rightValue);
        v2.setCellStyle(rightIsRate ? s.summaryRate : s.summaryValue);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 5, 7));
        return rowIdx;
    }

    private String formatCount(Long v) { return v == null ? "—" : String.format("%,d", v); }
    private String formatRate(Double v){ return v == null ? "—" : String.format("%.1f%%", v); }

    // ────────────────── 섹션 2: 불일치 분석 ──────────────────
    private int writeAnalysisSection(Sheet sheet, Styles s, DiscrepancyAnalysis a, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, "📊 " + a.getTitle(), rowIdx);

        // 안내
        Row info = sheet.createRow(rowIdx++);
        Cell ic = info.createCell(0);
        ic.setCellValue("단위: " + a.getMetric().getUnit() + "  |  정합률 = (전체 - 불일치) / 전체 × 100");
        ic.setCellStyle(s.sectionSubText);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));

        // 헤더
        Row h = sheet.createRow(rowIdx++);
        h.setHeightInPoints(22);
        String headerLabel = "전체 " + a.getMetric().getLabel();
        String discLabel   = "불일치 " + a.getMetric().getLabel();
        String[] cols = { "유형", "", "", "", headerLabel, "", discLabel, "정합률" };

        h.createCell(0).setCellValue("유형");
        h.createCell(4).setCellValue(headerLabel);
        h.createCell(6).setCellValue(discLabel);
        h.createCell(7).setCellValue("정합률");
        for (int i : new int[]{0,4,6,7}) h.getCell(i).setCellStyle(s.tableHeader);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 3));
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 4, 5));

        // 데이터 행
        for (DiscrepancyRow r : a.getRows()) {
            rowIdx = writeAnalysisDataRow(sheet, s, r, rowIdx, false);
        }
        // 합계 행
        rowIdx = writeAnalysisDataRow(sheet, s, a.getTotalRow(), rowIdx, true);
        return rowIdx;
    }

    private int writeAnalysisDataRow(Sheet sheet, Styles s, DiscrepancyRow r, int rowIdx,
                                     boolean isTotal) {
        Row row = sheet.createRow(rowIdx++);
        row.setHeightInPoints(22);

        Cell c0 = row.createCell(0);
        c0.setCellValue(r.getType() == null ? "—" : r.getType());
        c0.setCellStyle(isTotal ? s.totalLabel : s.tableCellLeft);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 3));

        Cell c1 = row.createCell(4);
        if (r.getTotalValue() == null) c1.setCellValue("—");
        else c1.setCellValue(r.getTotalValue());
        c1.setCellStyle(isTotal ? s.totalNumber : s.tableCellNumber);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 4, 5));

        Cell c2 = row.createCell(6);
        if (r.getDiscrepancyValue() == null) c2.setCellValue("—");
        else c2.setCellValue(r.getDiscrepancyValue());
        c2.setCellStyle(isTotal ? s.totalNumber : s.tableCellDiscrepancy);

        Cell c3 = row.createCell(7);
        c3.setCellValue(buildBarText(r.getReconRate()));
        c3.setCellStyle(reconRateBarStyle(s, r.getReconRate(), isTotal));
        return rowIdx;
    }

    private String buildBarText(Double rate) {
        if (rate == null) return "—";
        int filled = (int) Math.round(rate / 5);
        if (filled > 20) filled = 20;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20; i++) sb.append(i < filled ? "█" : "░");
        sb.append(String.format("  %.1f%%", rate));
        return sb.toString();
    }

    private CellStyle reconRateBarStyle(Styles s, Double rate, boolean isTotal) {
        if (rate == null) return isTotal ? s.totalNumber : s.tableCellCenter;
        if (rate >= 95.0)   return isTotal ? s.totalBarHigh : s.barHigh;
        if (rate >= 80.0)   return isTotal ? s.totalBarMid  : s.barMid;
        return isTotal ? s.totalBarLow : s.barLow;
    }

    // ────────────────── 섹션 3: 불일치 상세 내역 ──────────────────
    private int writeDetailSection(Sheet sheet, Styles s, DiscrepancyDetail detail, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, "📋 불일치 상세 내역", rowIdx);

        // 헤더
        Row h = sheet.createRow(rowIdx++);
        h.setHeightInPoints(22);
        // 컬럼: 유형 | 카테고리 | 불일치 유형 | 불일치 사유(병합) | 건수
        h.createCell(0).setCellValue("유형");
        h.createCell(1).setCellValue("카테고리");
        h.createCell(2).setCellValue("불일치 유형");
        h.createCell(3).setCellValue("불일치 사유");
        h.createCell(7).setCellValue("건수");
        for (int i : new int[]{0,1,2,3,7}) h.getCell(i).setCellStyle(s.tableHeader);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 3, 6)); // 사유 컬럼 병합

        List<DiscrepancyDetailRow> rows = detail.getRows();
        if (rows == null || rows.isEmpty()) {
            Row empty = sheet.createRow(rowIdx++);
            empty.setHeightInPoints(40);
            Cell e = empty.createCell(0);
            e.setCellValue("데이터가 없습니다.");
            e.setCellStyle(s.emptyRow);
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        } else {
            for (DiscrepancyDetailRow r : rows) {
                Row row = sheet.createRow(rowIdx++);
                row.setHeightInPoints(22);
                row.createCell(0).setCellValue(nullToDash(r.getType()));
                row.createCell(1).setCellValue(nullToDash(r.getCategory()));
                row.createCell(2).setCellValue(nullToDash(r.getDiscrepancyType()));
                row.createCell(3).setCellValue(nullToDash(r.getDiscrepancyReason()));
                row.createCell(7).setCellValue(r.getCount());

                row.getCell(0).setCellStyle(s.tableCellCenter);
                row.getCell(1).setCellStyle(s.tableCellCenter);
                row.getCell(2).setCellStyle(s.tableCellLeft);
                row.getCell(3).setCellStyle(s.tableCellLeftWrap);
                row.getCell(7).setCellStyle(s.tableCellNumberBold);
                sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 3, 6));
            }
        }
        return rowIdx;
    }

    // ────────────────── 푸터 / 공통 ──────────────────
    private void writeFooter(Sheet sheet, Styles s, ReconciliationDetailReport d, int rowIdx) {
        rowIdx++;
        Row footer = sheet.createRow(rowIdx);
        Cell f = footer.createCell(0);
        f.setCellValue("※ 본 자료는 자동 생성되었으며, 데이터는 " + d.getPeriodLabel() + " 기준입니다.");
        f.setCellStyle(s.footer);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 7));
    }

    private int writeSectionTitle(Sheet sheet, Styles s, String text, int rowIdx) {
        Row r = sheet.createRow(rowIdx++);
        r.setHeightInPoints(26);
        Cell c = r.createCell(0);
        c.setCellValue(text);
        c.setCellStyle(s.sectionTitle);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        return rowIdx;
    }

    private static String nullToDash(String s) { return s == null || s.isBlank() ? "—" : s; }

    // ────────────────── 스타일 ──────────────────
    private static class Styles {
        final CellStyle title, periodTag, meta, sectionTitle, sectionSubText, footer;
        final CellStyle summaryLabel, summaryValue, summaryRate;
        final CellStyle tableHeader, tableCellLeft, tableCellLeftWrap, tableCellCenter;
        final CellStyle tableCellNumber, tableCellNumberBold, tableCellDiscrepancy;
        final CellStyle barHigh, barMid, barLow;
        final CellStyle totalLabel, totalNumber, totalBarHigh, totalBarMid, totalBarLow;
        final CellStyle emptyRow;

        Styles(Workbook wb) {
            DataFormat fmt = wb.createDataFormat();

            title           = build(wb, 18, true,  IndexedColors.DARK_GREEN.index,        null,                                      HorizontalAlignment.LEFT,   true,  null);
            periodTag       = build(wb, 11, true,  IndexedColors.WHITE.index,             IndexedColors.DARK_GREEN.index,            HorizontalAlignment.CENTER, true,  null);
            meta            = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                      HorizontalAlignment.LEFT,   false, null);
            sectionTitle    = build(wb, 13, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_CORNFLOWER_BLUE.index, HorizontalAlignment.LEFT,   true,  null);
            sectionSubText  = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                      HorizontalAlignment.LEFT,   false, null);
            footer          = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                      HorizontalAlignment.CENTER, false, null);

            // 정합율 요약 (카드 스타일)
            summaryLabel    = build(wb, 11, false, IndexedColors.GREY_80_PERCENT.index,   IndexedColors.GREY_25_PERCENT.index,       HorizontalAlignment.LEFT,   true,  BorderStyle.THIN);
            summaryValue    = build(wb, 11, true,  IndexedColors.BLACK.index,             null,                                      HorizontalAlignment.RIGHT,  true,  BorderStyle.THIN);
            summaryValue.setDataFormat(fmt.getFormat("#,##0"));
            summaryRate     = build(wb, 12, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_GREEN.index,           HorizontalAlignment.RIGHT,  true,  BorderStyle.THIN);

            // 테이블
            tableHeader     = build(wb, 10, true,  IndexedColors.WHITE.index,             IndexedColors.GREY_80_PERCENT.index,       HorizontalAlignment.CENTER, true,  BorderStyle.THIN);
            tableCellLeft   = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                      HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            tableCellLeftWrap = build(wb, 10, false, IndexedColors.BLACK.index,           null,                                      HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            tableCellCenter = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                      HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            tableCellNumber = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                      HorizontalAlignment.RIGHT,  true,  BorderStyle.HAIR);
            tableCellNumber.setDataFormat(fmt.getFormat("#,##0"));
            tableCellNumberBold = build(wb, 10, true, IndexedColors.BLACK.index,          null,                                      HorizontalAlignment.RIGHT,  true,  BorderStyle.HAIR);
            tableCellNumberBold.setDataFormat(fmt.getFormat("#,##0"));
            tableCellDiscrepancy = build(wb, 10, true, IndexedColors.BROWN.index,         IndexedColors.LIGHT_YELLOW.index,          HorizontalAlignment.RIGHT,  true,  BorderStyle.HAIR);
            tableCellDiscrepancy.setDataFormat(fmt.getFormat("#,##0"));

            // 정합률 막대 바 (3단계)
            barHigh         = barStyle(wb, IndexedColors.GREEN.index,         IndexedColors.WHITE.index, false);
            barMid          = barStyle(wb, IndexedColors.LIGHT_ORANGE.index,  IndexedColors.WHITE.index, false);
            barLow          = barStyle(wb, IndexedColors.GREY_25_PERCENT.index, IndexedColors.GREY_50_PERCENT.index, false);

            // 합계 행
            totalLabel      = build(wb, 11, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_YELLOW.index,          HorizontalAlignment.CENTER, true,  BorderStyle.MEDIUM);
            totalNumber     = build(wb, 11, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_YELLOW.index,          HorizontalAlignment.RIGHT,  true,  BorderStyle.MEDIUM);
            totalNumber.setDataFormat(fmt.getFormat("#,##0"));
            totalBarHigh    = barStyle(wb, IndexedColors.GREEN.index,         IndexedColors.WHITE.index, true);
            totalBarMid     = barStyle(wb, IndexedColors.LIGHT_ORANGE.index,  IndexedColors.WHITE.index, true);
            totalBarLow     = barStyle(wb, IndexedColors.GREY_25_PERCENT.index, IndexedColors.GREY_50_PERCENT.index, true);

            // 빈 데이터
            emptyRow        = build(wb, 11, false, IndexedColors.GREY_50_PERCENT.index,   IndexedColors.GREY_25_PERCENT.index,       HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
        }

        private CellStyle barStyle(Workbook wb, short bg, short fontColor, boolean total) {
            CellStyle cs = wb.createCellStyle();
            Font f = wb.createFont();
            f.setFontName("Consolas");
            f.setFontHeightInPoints((short) 10);
            f.setBold(true);
            f.setColor(fontColor);
            cs.setFont(f);
            cs.setAlignment(HorizontalAlignment.LEFT);
            cs.setVerticalAlignment(VerticalAlignment.CENTER);
            cs.setFillForegroundColor(bg);
            cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            BorderStyle border = total ? BorderStyle.MEDIUM : BorderStyle.HAIR;
            cs.setBorderTop(border);    cs.setBorderBottom(border);
            cs.setBorderLeft(border);   cs.setBorderRight(border);
            return cs;
        }

        private CellStyle build(Workbook wb, int fontPt, boolean bold, short fontColor,
                                Short bgColor, HorizontalAlignment align, boolean wrap,
                                BorderStyle border) {
            CellStyle cs = wb.createCellStyle();
            Font f = wb.createFont();
            f.setFontHeightInPoints((short) fontPt);
            f.setBold(bold);
            f.setColor(fontColor);
            f.setFontName("맑은 고딕");
            cs.setFont(f);
            cs.setAlignment(align);
            cs.setVerticalAlignment(VerticalAlignment.CENTER);
            cs.setWrapText(wrap);
            if (bgColor != null) {
                cs.setFillForegroundColor(bgColor);
                cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            }
            if (border != null) {
                cs.setBorderTop(border);    cs.setBorderBottom(border);
                cs.setBorderLeft(border);   cs.setBorderRight(border);
                cs.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setTopBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setRightBorderColor(IndexedColors.GREY_40_PERCENT.index);
            }
            return cs;
        }
    }
}


// ============================================================================
//  4. HTML EXPORTER — 정합결과 상세
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.ReconciliationDetailReport;
import com.ktds.report.dto.ReconciliationDetailReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class ReconciliationHtmlExporter implements ReportExporter<ReconciliationDetailReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Override public ReportType   supportType()   { return ReportType.RECONCILIATION_DETAIL; }
    @Override public ReportFormat supportFormat() { return ReportFormat.HTML; }

    @Override
    public void export(ReconciliationDetailReport data, OutputStream out) throws IOException {
        try (Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
            w.write(buildHtml(data));
        }
    }

    private String buildHtml(ReconciliationDetailReport d) {
        StringBuilder sb = new StringBuilder(16384);
        sb.append("<!doctype html><html lang=\"ko\"><head><meta charset=\"UTF-8\">")
          .append("<title>").append(escape(d.getReportTitle())).append("</title>")
          .append(css())
          .append("</head><body><div class=\"report\">");

        // 헤더
        sb.append("<header class=\"hdr\">")
          .append("<div class=\"hdr-left\"><h1>✓ ").append(escape(d.getReportTitle())).append("</h1>")
          .append("<div class=\"meta\">생성일시: ").append(d.getGeneratedAt().format(DTF))
          .append(" &nbsp;|&nbsp; 생성자: ").append(escape(nullToDash(d.getGeneratedBy())))
          .append("</div></div>")
          .append("<div class=\"period-tag\">").append(escape(d.getPeriodLabel())).append("</div>")
          .append("</header>");

        sb.append(summarySection(d.getMobile()));
        sb.append(summarySection(d.getInternetPhone()));
        sb.append(analysisSection(d.getCountAnalysis()));
        sb.append(analysisSection(d.getAmountAnalysis()));
        sb.append(detailSection(d.getDiscrepancyDetail()));

        sb.append("<footer class=\"ftr\">※ 본 자료는 자동 생성되었으며, 데이터는 ")
          .append(escape(d.getPeriodLabel())).append(" 기준입니다.</footer>");

        sb.append("</div></body></html>");
        return sb.toString();
    }

    // ────────────────── 섹션 1: 정합율 요약 ──────────────────
    private String summarySection(ReconciliationSummary s) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card service-").append(s.getServiceType().getCssClass()).append("\">")
          .append("<h2>").append(escape(s.getServiceType().getLabel())).append(" 정합율 요약</h2>")
          .append("<div class=\"summary-grid\">");

        sb.append(kvPair("전체 건수",            formatCount(s.getTotalCount()),                  false));
        sb.append(kvPair("고객 건수",            formatCount(s.getCustomerCount()),               false));
        sb.append(kvPair("금액 정합율",          formatRate(s.getAmountReconRate()),              true));
        sb.append(kvPair("건수 정합율",          formatRate(s.getCountReconRate()),               true));
        sb.append(kvPair("금액 정합율 <span class=\"unit\">(고객단위)</span>",
                          formatRate(s.getAmountReconRateByCustomer()), true));
        sb.append(kvPair("건수 정합율 <span class=\"unit\">(고객단위)</span>",
                          formatRate(s.getCountReconRateByCustomer()),  true));

        sb.append("</div></section>");
        return sb.toString();
    }

    private String kvPair(String label, String value, boolean isRate) {
        return "<div class=\"kv\"><span class=\"k\">" + label + "</span>"
             + "<span class=\"v" + (isRate ? " rate" : "") + "\">" + value + "</span></div>";
    }

    // ────────────────── 섹션 2: 불일치 분석 ──────────────────
    private String analysisSection(DiscrepancyAnalysis a) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>📊 ").append(escape(a.getTitle())).append("</h2>")
          .append("<div class=\"section-sub\">단위: ").append(a.getMetric().getUnit())
          .append("  |  정합률 = (전체 - 불일치) / 전체 × 100</div>")
          .append("<table class=\"data-table\"><thead><tr>")
          .append("<th>유형</th>")
          .append("<th>전체 ").append(a.getMetric().getLabel()).append("</th>")
          .append("<th>불일치 ").append(a.getMetric().getLabel()).append("</th>")
          .append("<th class=\"col-bar\">정합률</th>")
          .append("</tr></thead><tbody>");

        for (DiscrepancyRow r : a.getRows()) {
            sb.append(analysisRow(r, false));
        }
        sb.append(analysisRow(a.getTotalRow(), true));
        sb.append("</tbody></table></section>");
        return sb.toString();
    }

    private String analysisRow(DiscrepancyRow r, boolean isTotal) {
        String trCls = isTotal ? " class=\"total-row\"" : "";
        return "<tr" + trCls + ">"
             + "<td>" + escape(nullToDash(r.getType())) + "</td>"
             + "<td class=\"num\">" + formatLong(r.getTotalValue()) + "</td>"
             + "<td class=\"num discrepancy\">" + formatLong(r.getDiscrepancyValue()) + "</td>"
             + "<td>" + reconRateBar(r.getReconRate()) + "</td>"
             + "</tr>";
    }

    private String reconRateBar(Double rate) {
        if (rate == null) return "<span class=\"dash\">—</span>";
        String level = rate >= 95.0 ? "high" : (rate >= 80.0 ? "mid" : "low");
        double width = Math.min(rate, 100);
        return "<div class=\"bar-wrap\">"
             + "<div class=\"bar bar-" + level + "\" style=\"width:" + width + "%\"></div>"
             + "<span class=\"bar-pct bar-pct-" + level + "\">"
             + String.format("%.1f%%", rate) + "</span></div>";
    }

    // ────────────────── 섹션 3: 불일치 상세 내역 ──────────────────
    private String detailSection(DiscrepancyDetail detail) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>📋 불일치 상세 내역</h2>")
          .append("<table class=\"data-table\"><thead><tr>")
          .append("<th>유형</th><th>카테고리</th><th>불일치 유형</th>")
          .append("<th>불일치 사유</th><th>건수</th>")
          .append("</tr></thead><tbody>");

        List<DiscrepancyDetailRow> rows = detail.getRows();
        if (rows == null || rows.isEmpty()) {
            sb.append("<tr class=\"empty\"><td colspan=\"5\">데이터가 없습니다.</td></tr>");
        } else {
            for (DiscrepancyDetailRow r : rows) {
                sb.append("<tr>")
                  .append("<td class=\"center\">").append(escape(nullToDash(r.getType()))).append("</td>")
                  .append("<td class=\"center\">").append(escape(nullToDash(r.getCategory()))).append("</td>")
                  .append("<td>").append(escape(nullToDash(r.getDiscrepancyType()))).append("</td>")
                  .append("<td class=\"reason\">").append(escape(nullToDash(r.getDiscrepancyReason()))).append("</td>")
                  .append("<td class=\"num bold\">").append(String.format("%,d", r.getCount())).append("</td>")
                  .append("</tr>");
            }
        }
        sb.append("</tbody></table></section>");
        return sb.toString();
    }

    // 헬퍼
    private String formatCount(Long v) { return v == null ? "—" : String.format("%,d", v); }
    private String formatLong(Long v)  { return v == null ? "—" : String.format("%,d", v); }
    private String formatRate(Double v){ return v == null ? "—" : String.format("%.1f%%", v); }
    private String nullToDash(String s){ return s == null || s.isBlank() ? "—" : s; }
    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }

    // ────────────────── CSS ──────────────────
    private String css() {
        return "<style>"
             + "*{box-sizing:border-box;margin:0;padding:0;}"
             + "body{font-family:'맑은 고딕','Malgun Gothic',sans-serif;background:#f5f5f0;color:#2a2a28;padding:24px;}"
             + ".report{max-width:1280px;margin:0 auto;background:#fff;border-radius:12px;padding:32px;box-shadow:0 2px 12px rgba(0,0,0,0.06);}"
             + ".hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:20px;border-bottom:2px solid #6b7c3a;margin-bottom:24px;}"
             + ".hdr h1{font-size:22px;color:#4a5a26;margin-bottom:6px;}"
             + ".meta{font-size:12px;color:#888;}"
             + ".period-tag{background:#4a5a26;color:#fff;padding:8px 16px;border-radius:6px;font-weight:bold;font-size:13px;}"
             + ".card{border:1px solid #e5e5dc;border-radius:8px;padding:24px;margin-bottom:20px;background:#fafaf5;}"
             + ".card h2{font-size:16px;color:#4a5a26;margin-bottom:14px;padding-bottom:8px;border-bottom:1px solid #d9d9c8;}"
             + ".section-sub{font-size:11px;color:#888;margin-bottom:10px;}"
             // 정합율 요약 카드 — 서비스 타입별 색상
             + ".service-mobile{border-top:4px solid #6b7c3a;}"
             + ".service-internet{border-top:4px solid #5b7aa8;}"
             // 요약 그리드 (2컬럼)
             + ".summary-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;}"
             + ".kv{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:#fff;border:1px solid #e5e5dc;border-radius:6px;}"
             + ".kv .k{font-size:12px;color:#666;}"
             + ".kv .k .unit{color:#aaa;font-size:11px;}"
             + ".kv .v{font-size:14px;font-weight:bold;color:#2a2a28;}"
             + ".kv .v.rate{color:#4a5a26;font-size:15px;}"
             // 데이터 테이블
             + ".data-table{width:100%;border-collapse:collapse;font-size:11px;}"
             + ".data-table th{background:#3a3a30;color:#fff;padding:10px;text-align:center;font-weight:600;border:1px solid #2a2a20;}"
             + ".data-table td{padding:9px 10px;border-bottom:1px solid #e5e5dc;background:#fff;}"
             + ".data-table tr:not(.total-row):not(.empty):nth-child(even) td{background:#fafaf5;}"
             + ".data-table td.num{text-align:right;font-variant-numeric:tabular-nums;font-weight:600;}"
             + ".data-table td.num.bold{font-weight:bold;}"
             + ".data-table td.num.discrepancy{color:#c86f1a;background:#fdf6e3 !important;}"
             + ".data-table td.center{text-align:center;}"
             + ".data-table td.reason{font-size:11px;color:#444;}"
             + ".data-table tr.empty td{text-align:center;color:#aaa;padding:32px;background:#f8f8f3;}"
             + ".data-table tr.total-row td{background:#fdf6e3 !important;color:#4a5a26;font-weight:bold;border-top:2px solid #6b7c3a;}"
             // 정합률 바
             + ".col-bar{width:220px;}"
             + ".bar-wrap{position:relative;background:#eee8d8;height:18px;border-radius:9px;overflow:hidden;}"
             + ".bar{height:100%;border-radius:9px;}"
             + ".bar.bar-high{background:linear-gradient(90deg,#5b8a3a,#7da855);}"
             + ".bar.bar-mid{background:linear-gradient(90deg,#c89134,#d8a854);}"
             + ".bar.bar-low{background:#c8c8be;}"
             + ".bar-pct{position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:10px;font-weight:bold;}"
             + ".bar-pct.bar-pct-high{color:#fff;}"
             + ".bar-pct.bar-pct-mid{color:#fff;}"
             + ".bar-pct.bar-pct-low{color:#888;}"
             + ".dash{color:#bbb;}"
             + ".ftr{text-align:center;font-size:11px;color:#888;margin-top:24px;padding-top:16px;border-top:1px dashed #ddd;}"
             + "@media print{body{background:#fff;padding:0;}.report{box-shadow:none;padding:16px;}.card{break-inside:avoid;page-break-inside:avoid;}}"
             + "</style>";
    }
}


// ============================================================================
//  5. 데이터 조회 어댑터 (샘플 데이터로 채워서 출력)
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.ReconciliationDetailReport;
import com.ktds.report.dto.ReconciliationDetailReport.*;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class ReconciliationDataProvider {

    public ReconciliationDetailReport fetch(String yearMonth, String userId) {

        // ──── 섹션 1: 모바일 정합율 요약 ────
        ReconciliationSummary mobile = ReconciliationSummary.builder()
                .serviceType(ServiceType.MOBILE)
                .totalCount(24475497L)
                .customerCount(9638602L)
                .amountReconRate(99.87)
                .countReconRate(99.92)
                .amountReconRateByCustomer(99.95)
                .countReconRateByCustomer(99.96)
                .build();

        ReconciliationSummary internet = ReconciliationSummary.builder()
                .serviceType(ServiceType.INTERNET_PHONE)
                .totalCount(2826748L)
                .customerCount(1675360L)
                .amountReconRate(99.74)
                .countReconRate(99.81)
                .amountReconRateByCustomer(99.88)
                .countReconRateByCustomer(99.91)
                .build();

        // ──── 섹션 2-1: 불일치 분석 - 건수 ────
        List<DiscrepancyRow> countRows = List.of(
                discrepancyRow("요금제",    18_450_320L, 12_456L, 99.93),
                discrepancyRow("부가상품",  6_388_875L,   8_734L, 99.86),
                discrepancyRow("할인",      4_280_540L,   5_120L, 99.88),
                discrepancyRow("기본료",      895_320L,     412L, 99.95),
                discrepancyRow("기타",        287_190L,   1_658L, 99.42)
        );
        long sumCountTotal = countRows.stream().mapToLong(DiscrepancyRow::getTotalValue).sum();
        long sumCountDisc  = countRows.stream().mapToLong(DiscrepancyRow::getDiscrepancyValue).sum();
        double countRate   = sumCountTotal == 0 ? 0
                            : (double)(sumCountTotal - sumCountDisc) * 100 / sumCountTotal;

        DiscrepancyAnalysis countAnalysis = DiscrepancyAnalysis.builder()
                .title("불일치 분석 - 건수")
                .metric(AnalysisMetric.COUNT)
                .rows(countRows)
                .totalRow(discrepancyRow("합계", sumCountTotal, sumCountDisc, countRate))
                .build();

        // ──── 섹션 2-2: 불일치 분석 - 금액 ────
        List<DiscrepancyRow> amountRows = List.of(
                discrepancyRow("요금제",    523_840_512_000L,  712_345_000L, 99.86),
                discrepancyRow("부가상품",  187_295_840_000L,  456_120_000L, 99.76),
                discrepancyRow("할인",       89_450_320_000L,  124_580_000L, 99.86),
                discrepancyRow("기본료",     45_280_175_000L,   28_410_000L, 99.94),
                discrepancyRow("기타",       12_840_295_000L,   89_720_000L, 99.30)
        );
        long sumAmountTotal = amountRows.stream().mapToLong(DiscrepancyRow::getTotalValue).sum();
        long sumAmountDisc  = amountRows.stream().mapToLong(DiscrepancyRow::getDiscrepancyValue).sum();
        double amountRate   = sumAmountTotal == 0 ? 0
                            : (double)(sumAmountTotal - sumAmountDisc) * 100 / sumAmountTotal;

        DiscrepancyAnalysis amountAnalysis = DiscrepancyAnalysis.builder()
                .title("불일치 분석 - 금액")
                .metric(AnalysisMetric.AMOUNT)
                .rows(amountRows)
                .totalRow(discrepancyRow("합계", sumAmountTotal, sumAmountDisc, amountRate))
                .build();

        // ──── 섹션 3: 불일치 상세 내역 (샘플) ────
        DiscrepancyDetail detail = DiscrepancyDetail.builder()
                .rows(List.of(
                        detailRow("요금제",   "데이터",     "단가 차이",
                                  "프로모션 할인율 계산 시점 차이 (LegacyOMS vs nbss-uq)",        287L),
                        detailRow("요금제",   "음성",       "수량 차이",
                                  "심야 시간대 무료 통화 적용 누락 (특정 요금제 BSSIOTPP1)",      143L),
                        detailRow("부가상품", "데이터",     "결합 할인 누락",
                                  "Y덤 공유 데이터 가족결합 시 PIT 적용 시점 불일치",            89L),
                        detailRow("부가상품", "컨텐츠",     "정산 대상 누락",
                                  "월말 가입/해지 동시 발생 케이스 PIT 추출 누락",               54L),
                        detailRow("할인",     "선할인",     "단가 차이",
                                  "선할인 약정 만료 직전 일할 계산 오차 (1~2원)",                412L),
                        detailRow("할인",     "마켓",       "할인 미적용",
                                  "마켓상품(94개) 자동 적용 조건 누락",                          12L),
                        detailRow("기본료",   "—",          "단가 차이",
                                  "유선전화 기본료 5G 결합할인 중복 적용",                       38L),
                        detailRow("기타",     "로밍",       "환율 적용 시점 차이",
                                  "월 마감 환율 vs 사용 시점 환율 불일치",                       176L)
                ))
                .build();

        return ReconciliationDetailReport.builder()
                .reportTitle("정합결과 상세 조회")
                .periodLabel(yearMonth + " 기준")
                .generatedAt(LocalDateTime.now())
                .generatedBy(userId)
                .mobile(mobile)
                .internetPhone(internet)
                .countAnalysis(countAnalysis)
                .amountAnalysis(amountAnalysis)
                .discrepancyDetail(detail)
                .build();
    }

    private DiscrepancyRow discrepancyRow(String type, long total, long disc, double rate) {
        return DiscrepancyRow.builder()
                .type(type).totalValue(total).discrepancyValue(disc).reconRate(rate)
                .build();
    }

    private DiscrepancyDetailRow detailRow(String type, String category,
                                            String discType, String reason, long count) {
        return DiscrepancyDetailRow.builder()
                .type(type).category(category)
                .discrepancyType(discType).discrepancyReason(reason)
                .count(count).build();
    }
}


// ============================================================================
//  6. SERVICE — exportReconciliation() 메서드 추가
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.exporter.ReportExporter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final List<ReportExporter<?>> exporters;
    private final CoverageDataProvider coverageDataProvider;
    private final ProductDetailDataProvider productDetailDataProvider;
    private final ItemStatusDataProvider itemStatusDataProvider;
    private final ReconciliationDataProvider reconciliationDataProvider;   // 추가

    private Map<String, ReportExporter<?>> exporterMap;

    @jakarta.annotation.PostConstruct
    void init() {
        exporterMap = exporters.stream().collect(Collectors.toMap(
                e -> e.supportType().name() + ":" + e.supportFormat().name(),
                e -> e
        ));
    }

    @SuppressWarnings("unchecked")
    public void exportCoverage(ReportFormat format, OutputStream out,
                               String yearMonth, String userId) throws IOException {
        CoverageReport data = coverageDataProvider.fetch(yearMonth, userId);
        ReportExporter<CoverageReport> exporter = (ReportExporter<CoverageReport>)
                exporterMap.get(ReportType.COVERAGE_STATUS.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    @SuppressWarnings("unchecked")
    public void exportProductDetail(ReportFormat format, OutputStream out,
                                     String yearMonth, String userId) throws IOException {
        ProductCoverageDetailReport data = productDetailDataProvider.fetch(yearMonth, userId);
        ReportExporter<ProductCoverageDetailReport> exporter =
                (ReportExporter<ProductCoverageDetailReport>) exporterMap.get(
                        ReportType.PRODUCT_COVERAGE_DETAIL.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    @SuppressWarnings("unchecked")
    public void exportItemStatus(ReportFormat format, OutputStream out,
                                  String yearMonth, String userId) throws IOException {
        ItemStatusReport data = itemStatusDataProvider.fetch(yearMonth, userId);
        ReportExporter<ItemStatusReport> exporter = (ReportExporter<ItemStatusReport>)
                exporterMap.get(ReportType.ITEM_STATUS.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    @SuppressWarnings("unchecked")
    public void exportReconciliation(ReportFormat format, OutputStream out,
                                      String yearMonth, String userId) throws IOException {
        ReconciliationDetailReport data = reconciliationDataProvider.fetch(yearMonth, userId);
        ReportExporter<ReconciliationDetailReport> exporter =
                (ReportExporter<ReconciliationDetailReport>) exporterMap.get(
                        ReportType.RECONCILIATION_DETAIL.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    public String buildFileName(ReportType type, ReportFormat format, String yearMonth) {
        return String.format("%s_%s.%s",
                type.getDisplayName(),
                yearMonth.replace("-", ""),
                format.getExtension());
    }
}


// ============================================================================
//  7. CONTROLLER — 엔드포인트 추가
// ============================================================================
package com.ktds.report.controller;

import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/coverage-status")
    public void downloadCoverageStatus(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.COVERAGE_STATUS, format, yearMonth),
                out -> reportService.exportCoverage(format, out, yearMonth, userId));
    }

    @GetMapping("/product-coverage-detail")
    public void downloadProductCoverageDetail(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.PRODUCT_COVERAGE_DETAIL, format, yearMonth),
                out -> reportService.exportProductDetail(format, out, yearMonth, userId));
    }

    @GetMapping("/item-status")
    public void downloadItemStatus(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.ITEM_STATUS, format, yearMonth),
                out -> reportService.exportItemStatus(format, out, yearMonth, userId));
    }

    /** 4번 탭 - 정합결과 상세 조회 */
    @GetMapping("/reconciliation-detail")
    public void downloadReconciliationDetail(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.RECONCILIATION_DETAIL, format, yearMonth),
                out -> reportService.exportReconciliation(format, out, yearMonth, userId));
    }

    // 공통 다운로드 처리
    @FunctionalInterface
    private interface ExportAction {
        void apply(java.io.OutputStream out) throws IOException;
    }

    private void download(HttpServletResponse res, ReportFormat format,
                          String fileName, ExportAction action) throws IOException {
        String encoded = URLEncoder.encode(fileName, StandardCharsets.UTF_8)
                .replaceAll("\\+", "%20");
        res.setContentType(format.getContentType());
        res.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + encoded + "\"; filename*=UTF-8''" + encoded);
        action.apply(res.getOutputStream());
        res.flushBuffer();
    }
}


// ============================================================================
//  8. 프론트엔드 (참고)
// ============================================================================
/*
async function downloadReport(tab, format) {
  // tab: 'coverage-status' | 'product-coverage-detail' | 'item-status' | 'reconciliation-detail'
  const yearMonth = document.querySelector('#period').textContent.trim();
  const url = `/api/reports/${tab}?format=${format}`
            + `&yearMonth=${encodeURIComponent(yearMonth)}`;

  const res = await fetch(url);
  if (!res.ok) { alert('다운로드 실패'); return; }

  const cd = res.headers.get('content-disposition') || '';
  const m = cd.match(/filename\*=UTF-8''([^;]+)/);
  const fileName = m ? decodeURIComponent(m[1]) : `report.${format.toLowerCase()}`;

  const blob = await res.blob();
  const blobUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(blobUrl);
}

// 4번 탭 버튼 바인딩
document.querySelector('#btnTab4Excel').addEventListener('click',
  () => downloadReport('reconciliation-detail', 'EXCEL'));
document.querySelector('#btnTab4Html').addEventListener('click',
  () => downloadReport('reconciliation-detail', 'HTML'));
*/
