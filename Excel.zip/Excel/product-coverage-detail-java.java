// ============================================================================
//  상품별 커버리지 상세 레포트 (2번 탭) — 추가/수정 파일
//
//  기존 1번 탭 코드는 그대로 유지하면서 이 탭만 추가합니다.
//  - enums/ReportType : 항목 1개 추가
//  - dto/ProductCoverageDetailReport : 신규
//  - service/exporter/ProductDetailExcelExporter : 신규
//  - service/exporter/ProductDetailHtmlExporter  : 신규
//  - service/ProductDetailDataProvider : 신규
//  - service/ReportService : exportProductDetail() 메서드 추가
//  - controller/ReportController : 엔드포인트 추가
// ============================================================================


// ============================================================================
//  1. ENUM 확장
// ============================================================================
package com.ktds.report.enums;

public enum ReportType {
    COVERAGE_STATUS         ("커버리지_현황"),
    PRODUCT_COVERAGE_DETAIL ("상품별_커버리지_상세");   // ← 신규

    private final String displayName;
    ReportType(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}


// ============================================================================
//  2. DTO — 상품별 커버리지 상세
// ============================================================================
package com.ktds.report.dto;

import lombok.Builder;
import lombok.Getter;
import java.time.LocalDateTime;
import java.util.List;

@Getter @Builder
public class ProductCoverageDetailReport {

    private String reportTitle;       // "상품별 커버리지 상세"
    private String periodLabel;       // "2026년 01월"
    private LocalDateTime generatedAt;
    private String generatedBy;

    private ProductTypeSummary           summary;             // 1) 상품 유형별 요약
    private FilteredProductList          topSubscriberList;   // 2) 가입자 상위 10개
    private FilteredProductList          noUsageProductList;  // 3) 사용내역 없는 상품
    private NoSubscriberSample           noSubscriberSample;  // 4) 가입자 없는 상품 샘플

    // ──────────── 1) 상품 유형별 요약 ────────────
    @Getter @Builder
    public static class ProductTypeSummary {
        private SummaryRow totalProductCount;     // 전체 상품 수
        private SummaryRow matchTargetCount;      // 정합 대상 상품 수
        private SummaryRow noSubscriberCount;     // 가입자 없는 상품 수
        private SummaryRow noUsageCount;          // 사용내역 없는 상품 수
    }

    @Getter @Builder
    public static class SummaryRow {
        private String label;          // "전체 상품 수" 등
        private long wirelessFeePlan;  // 📱 무선 요금제
        private long wiredFeePlan;     // 📶 유선 요금제
        private long wirelessAddOn;    // ⊕ 무선 부가상품
        private long wiredAddOn;       // ⊕ 유선 부가상품
    }

    // ──────────── 2) & 3) 필터 칩 기반 상품 목록 ────────────
    /**
     * 화면의 4가지 필터 칩(무선요금제/무선부가/유선요금제/유선부가) 각각에 대한 상품 리스트.
     * 화면은 한 번에 하나만 보이지만, 저장 시엔 4종 모두 포함.
     */
    @Getter @Builder
    public static class FilteredProductList {
        private List<ProductRow> wirelessFeePlan;   // 무선 요금제 TOP 10
        private List<ProductRow> wirelessAddOn;     // 무선 부가상품 TOP 10
        private List<ProductRow> wiredFeePlan;      // 유선 요금제 TOP 10
        private List<ProductRow> wiredAddOn;        // 유선 부가상품 TOP 10
    }

    @Getter @Builder
    public static class ProductRow {
        private String productCode;      // BSSIOTPP1
        private String productName;      // 헬로표준
        private Long   subscriberCount;  // 3,132,462 (사용내역 없는 상품에서는 "가입자 수")
        private Double subscriberRatio;  // 12.8 (%)
        private Long   occurredItemCount;// 발생 아이템 (없으면 null → "—"로 표기)
        private Long   extractedItemCount;// 추출 아이템
        private Long   usageCount;       // 사용내역 (사용내역 없는 상품 테이블에서 사용)
        private Double verifyResultPct;  // 검증 결과 100.0(%) — 사용내역 없는 상품에선 null
        private Long   extractedCustomerCount; // 추출 고객수 — 사용내역 없는 상품에선 null
        private String lastUsageDate;    // 2024-08-12 — 사용내역 없는 상품에서만 사용
        private String statusBadge;      // 사용없음 / 테스트 / 종료 / 휴면 / 단종 / 베타 / 한정판 / 보류
    }

    // ──────────── 4) 가입자 없는 상품 샘플 ────────────
    @Getter @Builder
    public static class NoSubscriberSample {
        private long totalCount;                 // 전체 4,234개
        private List<NoSubscriberRow> samples;   // 화면에 보이는 8건
    }

    @Getter @Builder
    public static class NoSubscriberRow {
        private String productCode;     // NOSUB001
        private String productName;     // 신규 미출시 요금제 A
        private String productType;     // 무선 요금제 / 유선 부가상품 ...
        private String category;        // 준비중 / 테스트 / 내부용 / 임시 / 검토중
        private String registeredDate;  // 2025-12-15
    }
}


// ============================================================================
//  3. EXCEL EXPORTER — 상품별 커버리지 상세
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.ProductCoverageDetailReport;
import com.ktds.report.dto.ProductCoverageDetailReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class ProductDetailExcelExporter implements ReportExporter<ProductCoverageDetailReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    // 필터 칩 표시 라벨 (Excel용)
    private static final String[] FILTER_LABELS = {
            "📱 무선 요금제", "⊕ 무선 부가상품", "📶 유선 요금제", "⊕ 유선 부가상품"
    };

    @Override public ReportType   supportType()   { return ReportType.PRODUCT_COVERAGE_DETAIL; }
    @Override public ReportFormat supportFormat() { return ReportFormat.EXCEL; }

    @Override
    public void export(ProductCoverageDetailReport data, OutputStream out) throws IOException {
        try (Workbook wb = new XSSFWorkbook()) {
            Styles s = new Styles(wb);
            Sheet sheet = wb.createSheet("상품별 커버리지 상세");
            sheet.setDisplayGridlines(false);

            // 컬럼 폭 (8컬럼 기준)
            int[] widths = {3500, 6500, 4500, 3500, 3500, 3500, 3500, 4000};
            for (int i = 0; i < widths.length; i++) sheet.setColumnWidth(i, widths[i]);

            int rowIdx = 0;
            rowIdx = writeHeader(sheet, s, data, rowIdx);
            rowIdx = writeProductTypeSummary(sheet, s, data.getSummary(), rowIdx);
            rowIdx++;
            rowIdx = writeTopSubscriberSection(sheet, s, data.getTopSubscriberList(), rowIdx);
            rowIdx++;
            rowIdx = writeNoUsageSection(sheet, s, data.getNoUsageProductList(), rowIdx);
            rowIdx++;
            rowIdx = writeNoSubscriberSample(sheet, s, data.getNoSubscriberSample(), rowIdx);
            rowIdx++;
            writeFooter(sheet, s, data, rowIdx);

            // 인쇄 설정 (가로 1페이지 fit)
            sheet.setFitToPage(true);
            sheet.getPrintSetup().setFitWidth((short) 1);
            sheet.getPrintSetup().setFitHeight((short) 0);
            sheet.getPrintSetup().setLandscape(true);
            sheet.createFreezePane(0, 3);

            wb.write(out);
        }
    }

    // ────────────────── 헤더 ──────────────────
    private int writeHeader(Sheet sheet, Styles s, ProductCoverageDetailReport d, int rowIdx) {
        Row title = sheet.createRow(rowIdx);
        title.setHeightInPoints(32);
        Cell tc = title.createCell(0);
        tc.setCellValue("📦 " + d.getReportTitle());
        tc.setCellStyle(s.title);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 5));

        Cell period = title.createCell(6);
        period.setCellValue(d.getPeriodLabel());
        period.setCellStyle(s.periodTag);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 6, 7));
        rowIdx++;

        Row meta = sheet.createRow(rowIdx++);
        Cell mc = meta.createCell(0);
        mc.setCellValue("생성일시: " + d.getGeneratedAt().format(DTF)
                + "  |  생성자: " + (d.getGeneratedBy() != null ? d.getGeneratedBy() : "-"));
        mc.setCellStyle(s.meta);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        rowIdx++;
        return rowIdx;
    }

    // ────────────────── 섹션 1: 상품 유형별 요약 ──────────────────
    private int writeProductTypeSummary(Sheet sheet, Styles s, ProductTypeSummary p, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, "📦 상품 유형별 요약", rowIdx);

        // 헤더
        Row header = sheet.createRow(rowIdx++);
        header.setHeightInPoints(24);
        String[] headers = { "구분", "📱 무선 요금제", "📶 유선 요금제",
                             "⊕ 무선 부가상품", "⊕ 유선 부가상품" };
        for (int i = 0; i < headers.length; i++) {
            Cell c = header.createCell(i * (i == 0 ? 1 : 2) + (i == 0 ? 0 : -1));
            // 단순화: 0번 컬럼 / 1~2,3~4,5~6,7 병합
        }
        // 위 로직 단순화 - 직접 셀 설정
        sheet.getRow(rowIdx - 1).createCell(0).setCellValue("구분");
        sheet.getRow(rowIdx - 1).getCell(0).setCellStyle(s.tableHeader);
        for (int i = 1; i < headers.length; i++) {
            int col = (i - 1) * 2 + 1;
            Row r = sheet.getRow(rowIdx - 1);
            // 기존 빈 셀 정리하고 새로 작성
            for (Cell c : r) {
                if (c.getColumnIndex() != 0) {
                    // skip - clear all and rewrite below
                }
            }
        }
        // 헤더 셀을 깔끔하게 다시 작성
        Row hr = sheet.getRow(rowIdx - 1);
        // 헤더 셀이 이미 0번에 있으니 1~7 컬럼에 4개 헤더(병합)
        writeMergedHeader(sheet, hr, s, 1, 2, "📱 무선 요금제", rowIdx - 1);
        writeMergedHeader(sheet, hr, s, 3, 4, "📶 유선 요금제", rowIdx - 1);
        writeMergedHeader(sheet, hr, s, 5, 6, "⊕ 무선 부가상품", rowIdx - 1);
        writeMergedHeader(sheet, hr, s, 7, 7, "⊕ 유선 부가상품", rowIdx - 1);

        // 데이터 행 4개
        rowIdx = writeSummaryDataRow(sheet, s, p.getTotalProductCount(),  rowIdx, false);
        rowIdx = writeSummaryDataRow(sheet, s, p.getMatchTargetCount(),   rowIdx, true);   // 정합 대상 → 강조
        rowIdx = writeSummaryDataRow(sheet, s, p.getNoSubscriberCount(),  rowIdx, false);
        rowIdx = writeSummaryDataRow(sheet, s, p.getNoUsageCount(),       rowIdx, false);

        return rowIdx;
    }

    private void writeMergedHeader(Sheet sheet, Row row, Styles s, int colStart, int colEnd,
                                    String label, int rowIdx) {
        Cell c = row.createCell(colStart);
        c.setCellValue(label);
        c.setCellStyle(s.tableHeader);
        if (colEnd > colStart) {
            sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, colStart, colEnd));
        }
    }

    private int writeSummaryDataRow(Sheet sheet, Styles s, SummaryRow data, int rowIdx,
                                     boolean highlight) {
        Row r = sheet.createRow(rowIdx++);
        Cell label = r.createCell(0);
        label.setCellValue(data.getLabel());
        label.setCellStyle(highlight ? s.summaryLabelHighlight : s.summaryLabel);

        long[] values = { data.getWirelessFeePlan(), data.getWiredFeePlan(),
                          data.getWirelessAddOn(),  data.getWiredAddOn() };
        int[][] colRanges = { {1,2}, {3,4}, {5,6}, {7,7} };
        for (int i = 0; i < 4; i++) {
            Cell c = r.createCell(colRanges[i][0]);
            c.setCellValue(values[i] + "개");
            c.setCellStyle(highlight ? s.summaryValueHighlight : s.summaryValue);
            if (colRanges[i][1] > colRanges[i][0]) {
                sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1,
                        colRanges[i][0], colRanges[i][1]));
            }
        }
        return rowIdx;
    }

    // ────────────────── 섹션 2: 가입자 상위 10개 ──────────────────
    private int writeTopSubscriberSection(Sheet sheet, Styles s,
                                          FilteredProductList list, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, "👥 가입자 상위 10개 상품", rowIdx);

        // 필터 칩 4종을 서브섹션으로
        List<List<ProductRow>> all = List.of(
                nullToEmpty(list.getWirelessFeePlan()),
                nullToEmpty(list.getWirelessAddOn()),
                nullToEmpty(list.getWiredFeePlan()),
                nullToEmpty(list.getWiredAddOn())
        );
        for (int i = 0; i < 4; i++) {
            rowIdx = writeSubSectionTitle(sheet, s, FILTER_LABELS[i], rowIdx);
            rowIdx = writeTopSubscriberTable(sheet, s, all.get(i), rowIdx);
            rowIdx++; // 서브섹션 사이 여백
        }
        return rowIdx;
    }

    private int writeTopSubscriberTable(Sheet sheet, Styles s, List<ProductRow> rows, int rowIdx) {
        // 헤더
        Row h = sheet.createRow(rowIdx++);
        h.setHeightInPoints(22);
        String[] cols = { "상품코드", "상품명", "전체 가입자 수", "가입자 비율",
                          "발생 아이템", "추출 아이템", "검증 결과", "추출 고객수" };
        for (int i = 0; i < cols.length; i++) {
            Cell c = h.createCell(i);
            c.setCellValue(cols[i]);
            c.setCellStyle(s.tableHeader);
        }

        if (rows.isEmpty()) {
            Row empty = sheet.createRow(rowIdx++);
            Cell e = empty.createCell(0);
            e.setCellValue("해당 데이터가 없습니다.");
            e.setCellStyle(s.emptyRow);
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
            return rowIdx;
        }

        for (ProductRow r : rows) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(nullToDash(r.getProductCode()));
            row.createCell(1).setCellValue(nullToDash(r.getProductName()));
            row.createCell(2).setCellValue(r.getSubscriberCount() == null ? 0 : r.getSubscriberCount());
            row.createCell(3).setCellValue(r.getSubscriberRatio() == null
                    ? "-" : String.format("%.2f%%", r.getSubscriberRatio()));
            row.createCell(4).setCellValue(r.getOccurredItemCount() == null
                    ? "—" : String.format("%,d", r.getOccurredItemCount()));
            row.createCell(5).setCellValue(r.getExtractedItemCount() == null
                    ? "—" : String.format("%,d", r.getExtractedItemCount()));
            row.createCell(6).setCellValue(r.getVerifyResultPct() == null
                    ? "—" : String.format("%.1f%%", r.getVerifyResultPct()));
            row.createCell(7).setCellValue(r.getExtractedCustomerCount() == null
                    ? 0 : r.getExtractedCustomerCount());

            for (int i = 0; i < 8; i++) {
                Cell c = row.getCell(i);
                if (c == null) continue;
                if (i == 0 || i == 1) c.setCellStyle(s.tableCellLeft);
                else if (i == 2 || i == 7) {
                    c.setCellStyle(s.tableCellNumber);
                } else if (i == 6) {
                    c.setCellStyle(isHundredPercent(r.getVerifyResultPct())
                            ? s.verifyBadgeOk : s.tableCellCenter);
                } else {
                    c.setCellStyle(s.tableCellCenter);
                }
            }
        }
        return rowIdx;
    }

    private boolean isHundredPercent(Double v) {
        return v != null && v >= 100.0;
    }

    // ────────────────── 섹션 3: 사용내역 없는 상품 ──────────────────
    private int writeNoUsageSection(Sheet sheet, Styles s,
                                     FilteredProductList list, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s,
                "⚠ 사용내역 없는 상품 — 가입자 상위 10개", rowIdx);

        Row sub = sheet.createRow(rowIdx++);
        Cell sc = sub.createCell(0);
        sc.setCellValue("(가입자는 있으나 PIT 추출 평가 → 검증 대상 제외)");
        sc.setCellStyle(s.sectionSubText);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));

        List<List<ProductRow>> all = List.of(
                nullToEmpty(list.getWirelessFeePlan()),
                nullToEmpty(list.getWirelessAddOn()),
                nullToEmpty(list.getWiredFeePlan()),
                nullToEmpty(list.getWiredAddOn())
        );
        for (int i = 0; i < 4; i++) {
            rowIdx = writeSubSectionTitle(sheet, s, FILTER_LABELS[i], rowIdx);
            rowIdx = writeNoUsageTable(sheet, s, all.get(i), rowIdx);
            rowIdx++;
        }
        return rowIdx;
    }

    private int writeNoUsageTable(Sheet sheet, Styles s, List<ProductRow> rows, int rowIdx) {
        Row h = sheet.createRow(rowIdx++);
        h.setHeightInPoints(22);
        String[] cols = { "상품코드", "상품명", "가입자 수", "가입자 비율",
                          "발생 아이템", "사용내역", "최근 사용일", "상태" };
        for (int i = 0; i < cols.length; i++) {
            Cell c = h.createCell(i);
            c.setCellValue(cols[i]);
            c.setCellStyle(s.tableHeader);
        }

        if (rows.isEmpty()) {
            Row empty = sheet.createRow(rowIdx++);
            Cell e = empty.createCell(0);
            e.setCellValue("해당 데이터가 없습니다.");
            e.setCellStyle(s.emptyRow);
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
            return rowIdx;
        }

        for (ProductRow r : rows) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(nullToDash(r.getProductCode()));
            row.createCell(1).setCellValue(nullToDash(r.getProductName()));
            row.createCell(2).setCellValue(r.getSubscriberCount() == null ? 0 : r.getSubscriberCount());
            row.createCell(3).setCellValue(r.getSubscriberRatio() == null
                    ? "-" : String.format("%.2f%%", r.getSubscriberRatio()));
            row.createCell(4).setCellValue(r.getOccurredItemCount() == null
                    ? "—" : String.format("%,d", r.getOccurredItemCount()));
            row.createCell(5).setCellValue(r.getUsageCount() == null
                    ? 0 : r.getUsageCount());
            row.createCell(6).setCellValue(nullToDash(r.getLastUsageDate()));
            row.createCell(7).setCellValue(nullToDash(r.getStatusBadge()));

            for (int i = 0; i < 8; i++) {
                Cell c = row.getCell(i);
                if (c == null) continue;
                if (i == 0 || i == 1) c.setCellStyle(s.tableCellLeft);
                else if (i == 2 || i == 5) c.setCellStyle(s.tableCellNumber);
                else if (i == 7) c.setCellStyle(badgeStyleFor(r.getStatusBadge(), s));
                else c.setCellStyle(s.tableCellCenter);
            }
        }
        return rowIdx;
    }

    private CellStyle badgeStyleFor(String badge, Styles s) {
        if (badge == null) return s.tableCellCenter;
        return switch (badge) {
            case "사용없음", "종료", "단종", "보류" -> s.badgeGrey;
            case "테스트", "베타"                  -> s.badgeOrange;
            case "휴면", "한정판", "내부용", "임시"  -> s.badgeBlue;
            case "준비중", "검토중"                -> s.badgeGreen;
            default -> s.tableCellCenter;
        };
    }

    // ────────────────── 섹션 4: 가입자 없는 상품 샘플 ──────────────────
    private int writeNoSubscriberSample(Sheet sheet, Styles s, NoSubscriberSample sample, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s,
                "🔎 가입자 없는 상품 — 샘플 (전체 " + String.format("%,d", sample.getTotalCount())
                + "개 중 " + sample.getSamples().size() + "개 샘플)", rowIdx);

        Row h = sheet.createRow(rowIdx++);
        h.setHeightInPoints(22);
        String[] cols = { "상품코드", "상품명", "", "상품 유형", "", "분류", "", "등록일" };
        // 5컬럼이라 일부 컬럼 병합 처리
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 1, 2)); // 상품명
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 3, 4)); // 상품유형
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 5, 6)); // 분류

        h.createCell(0).setCellValue("상품코드");
        h.createCell(1).setCellValue("상품명");
        h.createCell(3).setCellValue("상품 유형");
        h.createCell(5).setCellValue("분류");
        h.createCell(7).setCellValue("등록일");
        for (int i : new int[]{0,1,3,5,7}) h.getCell(i).setCellStyle(s.tableHeader);

        for (NoSubscriberRow r : sample.getSamples()) {
            Row row = sheet.createRow(rowIdx++);
            row.createCell(0).setCellValue(nullToDash(r.getProductCode()));
            row.createCell(1).setCellValue(nullToDash(r.getProductName()));
            row.createCell(3).setCellValue(nullToDash(r.getProductType()));
            row.createCell(5).setCellValue(nullToDash(r.getCategory()));
            row.createCell(7).setCellValue(nullToDash(r.getRegisteredDate()));

            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 1, 2));
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 3, 4));
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 5, 6));

            row.getCell(0).setCellStyle(s.tableCellLeft);
            row.getCell(1).setCellStyle(s.tableCellLeft);
            row.getCell(3).setCellStyle(s.tableCellCenter);
            row.getCell(5).setCellStyle(badgeStyleFor(r.getCategory(), s));
            row.getCell(7).setCellStyle(s.tableCellCenter);
        }
        return rowIdx;
    }

    // ────────────────── 푸터 / 공통 ──────────────────
    private void writeFooter(Sheet sheet, Styles s, ProductCoverageDetailReport d, int rowIdx) {
        rowIdx++;
        Row footer = sheet.createRow(rowIdx);
        Cell f = footer.createCell(0);
        f.setCellValue("※ 본 자료는 자동 생성되었으며, 데이터는 " + d.getPeriodLabel() + " 기준입니다.");
        f.setCellStyle(s.footer);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 7));
    }

    private int writeSectionTitle(Sheet sheet, Styles s, String text, int rowIdx) {
        Row r = sheet.createRow(rowIdx++);
        r.setHeightInPoints(26);
        Cell c = r.createCell(0);
        c.setCellValue(text);
        c.setCellStyle(s.sectionTitle);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        return rowIdx;
    }

    private int writeSubSectionTitle(Sheet sheet, Styles s, String text, int rowIdx) {
        Row r = sheet.createRow(rowIdx++);
        r.setHeightInPoints(20);
        Cell c = r.createCell(0);
        c.setCellValue("▸ " + text);
        c.setCellStyle(s.subSectionTitle);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        return rowIdx;
    }

    private static <T> List<T> nullToEmpty(List<T> list) {
        return list == null ? List.of() : list;
    }
    private static String nullToDash(String s) { return s == null || s.isBlank() ? "—" : s; }

    // ────────────────── 스타일 ──────────────────
    private static class Styles {
        final CellStyle title, periodTag, meta, sectionTitle, subSectionTitle, sectionSubText;
        final CellStyle tableHeader, tableCellLeft, tableCellCenter, tableCellNumber, emptyRow;
        final CellStyle summaryLabel, summaryLabelHighlight, summaryValue, summaryValueHighlight;
        final CellStyle verifyBadgeOk;
        final CellStyle badgeGrey, badgeOrange, badgeBlue, badgeGreen;
        final CellStyle footer;

        Styles(Workbook wb) {
            DataFormat fmt = wb.createDataFormat();

            title           = build(wb, 18, true,  IndexedColors.DARK_GREEN.index,        null,                                   HorizontalAlignment.LEFT,   true,  null);
            periodTag       = build(wb, 11, true,  IndexedColors.WHITE.index,             IndexedColors.DARK_GREEN.index,         HorizontalAlignment.CENTER, true,  null);
            meta            = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                   HorizontalAlignment.LEFT,   false, null);
            sectionTitle    = build(wb, 13, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_CORNFLOWER_BLUE.index, HorizontalAlignment.LEFT, true, null);
            subSectionTitle = build(wb, 11, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_YELLOW.index,       HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            sectionSubText  = build(wb, 10, false, IndexedColors.GREY_50_PERCENT.index,   null,                                   HorizontalAlignment.LEFT,   false, null);

            tableHeader     = build(wb, 10, true,  IndexedColors.WHITE.index,             IndexedColors.DARK_GREEN.index,         HorizontalAlignment.CENTER, true,  BorderStyle.THIN);
            tableCellLeft   = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                   HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            tableCellCenter = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                   HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            tableCellNumber = build(wb, 10, true,  IndexedColors.BLACK.index,             null,                                   HorizontalAlignment.RIGHT,  true,  BorderStyle.HAIR);
            tableCellNumber.setDataFormat(fmt.getFormat("#,##0"));
            emptyRow        = build(wb, 10, false, IndexedColors.GREY_50_PERCENT.index,   IndexedColors.GREY_25_PERCENT.index,    HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);

            summaryLabel          = build(wb, 11, true,  IndexedColors.BLACK.index,        null,                                  HorizontalAlignment.LEFT,   true,  BorderStyle.THIN);
            summaryLabelHighlight = build(wb, 11, true,  IndexedColors.DARK_GREEN.index,   IndexedColors.LIGHT_GREEN.index,       HorizontalAlignment.LEFT,   true,  BorderStyle.THIN);
            summaryValue          = build(wb, 11, true,  IndexedColors.BLACK.index,        null,                                  HorizontalAlignment.RIGHT,  true,  BorderStyle.THIN);
            summaryValueHighlight = build(wb, 11, true,  IndexedColors.DARK_GREEN.index,   IndexedColors.LIGHT_GREEN.index,       HorizontalAlignment.RIGHT,  true,  BorderStyle.THIN);

            verifyBadgeOk   = build(wb, 10, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_GREEN.index,        HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);

            badgeGrey       = build(wb, 10, true,  IndexedColors.GREY_80_PERCENT.index,   IndexedColors.GREY_25_PERCENT.index,    HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            badgeOrange     = build(wb, 10, true,  IndexedColors.WHITE.index,             IndexedColors.LIGHT_ORANGE.index,       HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            badgeBlue       = build(wb, 10, true,  IndexedColors.WHITE.index,             IndexedColors.LIGHT_CORNFLOWER_BLUE.index, HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            badgeGreen      = build(wb, 10, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_GREEN.index,        HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);

            footer          = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                   HorizontalAlignment.CENTER, false, null);
        }

        private CellStyle build(Workbook wb, int fontPt, boolean bold, short fontColor,
                                Short bgColor, HorizontalAlignment align, boolean wrap,
                                BorderStyle border) {
            CellStyle cs = wb.createCellStyle();
            Font f = wb.createFont();
            f.setFontHeightInPoints((short) fontPt);
            f.setBold(bold);
            f.setColor(fontColor);
            f.setFontName("맑은 고딕");
            cs.setFont(f);
            cs.setAlignment(align);
            cs.setVerticalAlignment(VerticalAlignment.CENTER);
            cs.setWrapText(wrap);
            if (bgColor != null) {
                cs.setFillForegroundColor(bgColor);
                cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            }
            if (border != null) {
                cs.setBorderTop(border);    cs.setBorderBottom(border);
                cs.setBorderLeft(border);   cs.setBorderRight(border);
                cs.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setTopBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setRightBorderColor(IndexedColors.GREY_40_PERCENT.index);
            }
            return cs;
        }
    }
}


// ============================================================================
//  4. HTML EXPORTER — 상품별 커버리지 상세
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.ProductCoverageDetailReport;
import com.ktds.report.dto.ProductCoverageDetailReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class ProductDetailHtmlExporter implements ReportExporter<ProductCoverageDetailReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final String[] FILTER_LABELS = {
            "📱 무선 요금제", "⊕ 무선 부가상품", "📶 유선 요금제", "⊕ 유선 부가상품"
    };

    @Override public ReportType   supportType()   { return ReportType.PRODUCT_COVERAGE_DETAIL; }
    @Override public ReportFormat supportFormat() { return ReportFormat.HTML; }

    @Override
    public void export(ProductCoverageDetailReport data, OutputStream out) throws IOException {
        try (Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
            w.write(buildHtml(data));
        }
    }

    private String buildHtml(ProductCoverageDetailReport d) {
        StringBuilder sb = new StringBuilder(16384);
        sb.append("<!doctype html><html lang=\"ko\"><head><meta charset=\"UTF-8\">")
          .append("<title>").append(escape(d.getReportTitle())).append("</title>")
          .append(css())
          .append("</head><body><div class=\"report\">");

        // 헤더
        sb.append("<header class=\"hdr\">")
          .append("<div class=\"hdr-left\"><h1>📦 ").append(escape(d.getReportTitle())).append("</h1>")
          .append("<div class=\"meta\">생성일시: ").append(d.getGeneratedAt().format(DTF))
          .append(" &nbsp;|&nbsp; 생성자: ").append(escape(nullToDash(d.getGeneratedBy())))
          .append("</div></div>")
          .append("<div class=\"period-tag\">").append(escape(d.getPeriodLabel())).append("</div>")
          .append("</header>");

        sb.append(summarySection(d.getSummary()));
        sb.append(topSubscriberSection(d.getTopSubscriberList()));
        sb.append(noUsageSection(d.getNoUsageProductList()));
        sb.append(noSubscriberSampleSection(d.getNoSubscriberSample()));

        sb.append("<footer class=\"ftr\">※ 본 자료는 자동 생성되었으며, 데이터는 ")
          .append(escape(d.getPeriodLabel())).append(" 기준입니다.</footer>");

        sb.append("</div></body></html>");
        return sb.toString();
    }

    // ────────────────── 섹션 1: 요약 ──────────────────
    private String summarySection(ProductTypeSummary p) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>📦 상품 유형별 요약</h2>")
          .append("<table class=\"summary-table\"><thead><tr>")
          .append("<th>구분</th>")
          .append("<th>📱 무선 요금제</th>")
          .append("<th>📶 유선 요금제</th>")
          .append("<th>⊕ 무선 부가상품</th>")
          .append("<th>⊕ 유선 부가상품</th>")
          .append("</tr></thead><tbody>")
          .append(summaryRow(p.getTotalProductCount(),  false))
          .append(summaryRow(p.getMatchTargetCount(),   true))  // 정합 대상 강조
          .append(summaryRow(p.getNoSubscriberCount(),  false))
          .append(summaryRow(p.getNoUsageCount(),       false))
          .append("</tbody></table></section>");
        return sb.toString();
    }

    private String summaryRow(SummaryRow r, boolean highlight) {
        String cls = highlight ? " class=\"hl\"" : "";
        return "<tr" + cls + ">"
             + "<td class=\"label\">" + escape(r.getLabel()) + "</td>"
             + "<td class=\"num\">" + String.format("%,d", r.getWirelessFeePlan()) + "개</td>"
             + "<td class=\"num\">" + String.format("%,d", r.getWiredFeePlan())    + "개</td>"
             + "<td class=\"num\">" + String.format("%,d", r.getWirelessAddOn())   + "개</td>"
             + "<td class=\"num\">" + String.format("%,d", r.getWiredAddOn())      + "개</td>"
             + "</tr>";
    }

    // ────────────────── 섹션 2: 가입자 상위 10개 ──────────────────
    private String topSubscriberSection(FilteredProductList list) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>👥 가입자 상위 10개 상품</h2>");

        List<List<ProductRow>> all = List.of(
                nullToEmpty(list.getWirelessFeePlan()),
                nullToEmpty(list.getWirelessAddOn()),
                nullToEmpty(list.getWiredFeePlan()),
                nullToEmpty(list.getWiredAddOn())
        );
        for (int i = 0; i < 4; i++) {
            sb.append("<h3 class=\"sub-section\">▸ ").append(FILTER_LABELS[i]).append("</h3>");
            sb.append(topSubscriberTable(all.get(i)));
        }
        sb.append("</section>");
        return sb.toString();
    }

    private String topSubscriberTable(List<ProductRow> rows) {
        StringBuilder sb = new StringBuilder();
        sb.append("<table class=\"data-table\"><thead><tr>")
          .append("<th>상품코드</th><th>상품명</th>")
          .append("<th>전체 가입자 수</th><th>가입자 비율</th>")
          .append("<th>발생 아이템</th><th>추출 아이템</th>")
          .append("<th>검증 결과</th><th>추출 고객수</th>")
          .append("</tr></thead><tbody>");

        if (rows.isEmpty()) {
            sb.append("<tr class=\"empty\"><td colspan=\"8\">해당 데이터가 없습니다.</td></tr>");
        } else {
            for (ProductRow r : rows) {
                sb.append("<tr>")
                  .append("<td class=\"code\">").append(escape(nullToDash(r.getProductCode()))).append("</td>")
                  .append("<td>").append(escape(nullToDash(r.getProductName()))).append("</td>")
                  .append("<td class=\"num\">").append(formatLong(r.getSubscriberCount())).append("</td>")
                  .append("<td class=\"num\">").append(formatPct(r.getSubscriberRatio(), 2)).append("</td>")
                  .append("<td class=\"num\">").append(formatLong(r.getOccurredItemCount())).append("</td>")
                  .append("<td class=\"num\">").append(formatLong(r.getExtractedItemCount())).append("</td>")
                  .append("<td class=\"center\">").append(verifyBadge(r.getVerifyResultPct())).append("</td>")
                  .append("<td class=\"num\">").append(formatLong(r.getExtractedCustomerCount())).append("</td>")
                  .append("</tr>");
            }
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    private String verifyBadge(Double pct) {
        if (pct == null) return "—";
        if (pct >= 100.0) return "<span class=\"badge badge-ok\">" + String.format("%.1f%%", pct) + "</span>";
        return String.format("%.1f%%", pct);
    }

    // ────────────────── 섹션 3: 사용내역 없는 상품 ──────────────────
    private String noUsageSection(FilteredProductList list) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>⚠ 사용내역 없는 상품 — 가입자 상위 10개</h2>")
          .append("<div class=\"section-sub\">(가입자는 있으나 PIT 추출 평가 → 검증 대상 제외)</div>");

        List<List<ProductRow>> all = List.of(
                nullToEmpty(list.getWirelessFeePlan()),
                nullToEmpty(list.getWirelessAddOn()),
                nullToEmpty(list.getWiredFeePlan()),
                nullToEmpty(list.getWiredAddOn())
        );
        for (int i = 0; i < 4; i++) {
            sb.append("<h3 class=\"sub-section\">▸ ").append(FILTER_LABELS[i]).append("</h3>");
            sb.append(noUsageTable(all.get(i)));
        }
        sb.append("</section>");
        return sb.toString();
    }

    private String noUsageTable(List<ProductRow> rows) {
        StringBuilder sb = new StringBuilder();
        sb.append("<table class=\"data-table\"><thead><tr>")
          .append("<th>상품코드</th><th>상품명</th>")
          .append("<th>가입자 수</th><th>가입자 비율</th>")
          .append("<th>발생 아이템</th><th>사용내역</th>")
          .append("<th>최근 사용일</th><th>상태</th>")
          .append("</tr></thead><tbody>");

        if (rows.isEmpty()) {
            sb.append("<tr class=\"empty\"><td colspan=\"8\">해당 데이터가 없습니다.</td></tr>");
        } else {
            for (ProductRow r : rows) {
                sb.append("<tr>")
                  .append("<td class=\"code\">").append(escape(nullToDash(r.getProductCode()))).append("</td>")
                  .append("<td>").append(escape(nullToDash(r.getProductName()))).append("</td>")
                  .append("<td class=\"num\">").append(formatLong(r.getSubscriberCount())).append("</td>")
                  .append("<td class=\"num\">").append(formatPct(r.getSubscriberRatio(), 2)).append("</td>")
                  .append("<td class=\"num\">").append(formatLong(r.getOccurredItemCount())).append("</td>")
                  .append("<td class=\"num\">").append(formatLong(r.getUsageCount())).append("</td>")
                  .append("<td class=\"center\">").append(escape(nullToDash(r.getLastUsageDate()))).append("</td>")
                  .append("<td class=\"center\">").append(statusBadge(r.getStatusBadge())).append("</td>")
                  .append("</tr>");
            }
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    // ────────────────── 섹션 4: 가입자 없는 상품 샘플 ──────────────────
    private String noSubscriberSampleSection(NoSubscriberSample sample) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>🔎 가입자 없는 상품 — 샘플 ")
          .append("<span class=\"sub-count\">(전체 ").append(String.format("%,d", sample.getTotalCount()))
          .append("개 중 ").append(sample.getSamples().size()).append("개 샘플)</span></h2>");

        sb.append("<table class=\"data-table\"><thead><tr>")
          .append("<th>상품코드</th><th>상품명</th><th>상품 유형</th><th>분류</th><th>등록일</th>")
          .append("</tr></thead><tbody>");

        for (NoSubscriberRow r : sample.getSamples()) {
            sb.append("<tr>")
              .append("<td class=\"code\">").append(escape(nullToDash(r.getProductCode()))).append("</td>")
              .append("<td>").append(escape(nullToDash(r.getProductName()))).append("</td>")
              .append("<td class=\"center\">").append(escape(nullToDash(r.getProductType()))).append("</td>")
              .append("<td class=\"center\">").append(statusBadge(r.getCategory())).append("</td>")
              .append("<td class=\"center\">").append(escape(nullToDash(r.getRegisteredDate()))).append("</td>")
              .append("</tr>");
        }
        sb.append("</tbody></table></section>");
        return sb.toString();
    }

    // ────────────────── 뱃지 / 헬퍼 ──────────────────
    private String statusBadge(String badge) {
        if (badge == null || badge.isBlank()) return "—";
        String cls = switch (badge) {
            case "사용없음", "종료", "단종", "보류" -> "badge-grey";
            case "테스트", "베타"                  -> "badge-orange";
            case "휴면", "한정판", "내부용", "임시"  -> "badge-blue";
            case "준비중", "검토중"                -> "badge-green";
            default -> "badge-grey";
        };
        return "<span class=\"badge " + cls + "\">" + escape(badge) + "</span>";
    }

    private String formatLong(Long v) {
        return v == null ? "—" : String.format("%,d", v);
    }
    private String formatPct(Double v, int decimals) {
        return v == null ? "-" : String.format("%." + decimals + "f%%", v);
    }
    private String nullToDash(String s) { return s == null || s.isBlank() ? "—" : s; }
    private <T> List<T> nullToEmpty(List<T> list) { return list == null ? List.of() : list; }
    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }

    // ────────────────── CSS ──────────────────
    private String css() {
        return "<style>"
             + "*{box-sizing:border-box;margin:0;padding:0;}"
             + "body{font-family:'맑은 고딕','Malgun Gothic',sans-serif;background:#f5f5f0;color:#2a2a28;padding:24px;}"
             + ".report{max-width:1280px;margin:0 auto;background:#fff;border-radius:12px;padding:32px;box-shadow:0 2px 12px rgba(0,0,0,0.06);}"
             + ".hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:20px;border-bottom:2px solid #6b7c3a;margin-bottom:24px;}"
             + ".hdr h1{font-size:22px;color:#4a5a26;margin-bottom:6px;}"
             + ".meta{font-size:12px;color:#888;}"
             + ".period-tag{background:#4a5a26;color:#fff;padding:8px 16px;border-radius:6px;font-weight:bold;font-size:13px;}"
             + ".card{border:1px solid #e5e5dc;border-radius:8px;padding:24px;margin-bottom:20px;background:#fafaf5;}"
             + ".card h2{font-size:16px;color:#4a5a26;margin-bottom:14px;padding-bottom:8px;border-bottom:1px solid #d9d9c8;}"
             + ".sub-count{font-size:12px;color:#888;font-weight:normal;}"
             + ".section-sub{font-size:11px;color:#888;margin-bottom:12px;}"
             + ".sub-section{font-size:13px;color:#4a5a26;background:#fdf6e3;border-left:3px solid #6b7c3a;padding:8px 12px;margin:14px 0 8px 0;border-radius:3px;}"
             // 요약 테이블
             + ".summary-table{width:100%;border-collapse:collapse;font-size:12px;}"
             + ".summary-table th{background:#4a5a26;color:#fff;padding:10px;text-align:center;border:1px solid #3a4a16;}"
             + ".summary-table td{padding:10px;border:1px solid #d9d9c8;}"
             + ".summary-table td.label{font-weight:bold;background:#fff;}"
             + ".summary-table td.num{text-align:right;font-weight:bold;}"
             + ".summary-table tr.hl td{background:#eef4d8;color:#4a5a26;}"
             // 데이터 테이블
             + ".data-table{width:100%;border-collapse:collapse;font-size:11px;margin-bottom:8px;}"
             + ".data-table th{background:#4a5a26;color:#fff;padding:8px 6px;text-align:center;font-weight:600;border:1px solid #3a4a16;}"
             + ".data-table td{padding:7px 6px;border-bottom:1px solid #e5e5dc;background:#fff;}"
             + ".data-table tr:nth-child(even) td{background:#fafaf5;}"
             + ".data-table td.code{font-family:Consolas,'D2Coding',monospace;color:#666;}"
             + ".data-table td.num{text-align:right;font-weight:600;}"
             + ".data-table td.center{text-align:center;}"
             + ".data-table tr.empty td{text-align:center;color:#999;padding:20px;background:#f5f5f0;}"
             // 뱃지
             + ".badge{display:inline-block;padding:3px 10px;border-radius:11px;font-size:10px;font-weight:bold;}"
             + ".badge-ok{background:#eef4d8;color:#4a5a26;}"
             + ".badge-grey{background:#e5e5dc;color:#666;}"
             + ".badge-orange{background:#fdf6e3;color:#c86f1a;}"
             + ".badge-blue{background:#e0e8d0;color:#4a5a26;}"
             + ".badge-green{background:#d4e0a8;color:#3a4a16;}"
             + ".ftr{text-align:center;font-size:11px;color:#888;margin-top:24px;padding-top:16px;border-top:1px dashed #ddd;}"
             + "@media print{body{background:#fff;padding:0;}.report{box-shadow:none;padding:16px;}.card{break-inside:avoid;page-break-inside:avoid;}.data-table{font-size:10px;}}"
             + "</style>";
    }
}


// ============================================================================
//  5. 데이터 조회 어댑터 (샘플 데이터)
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.ProductCoverageDetailReport;
import com.ktds.report.dto.ProductCoverageDetailReport.*;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class ProductDetailDataProvider {

    public ProductCoverageDetailReport fetch(String yearMonth, String userId) {

        // ──── 섹션 1: 요약 ────
        ProductTypeSummary summary = ProductTypeSummary.builder()
                .totalProductCount(SummaryRow.builder()
                        .label("전체 상품 수")
                        .wirelessFeePlan(7202).wiredFeePlan(42)
                        .wirelessAddOn(1879).wiredAddOn(96).build())
                .matchTargetCount(SummaryRow.builder()
                        .label("정합 대상 상품 수")
                        .wirelessFeePlan(52).wiredFeePlan(0)
                        .wirelessAddOn(42).wiredAddOn(0).build())
                .noSubscriberCount(SummaryRow.builder()
                        .label("가입자 없는 상품 수")
                        .wirelessFeePlan(2966).wiredFeePlan(15)
                        .wirelessAddOn(1238).wiredAddOn(15).build())
                .noUsageCount(SummaryRow.builder()
                        .label("사용내역 없는 상품 수")
                        .wirelessFeePlan(4184).wiredFeePlan(27)
                        .wirelessAddOn(599).wiredAddOn(81).build())
                .build();

        // ──── 섹션 2: 가입자 상위 10개 (무선 요금제만 캡처에 존재) ────
        List<ProductRow> topWirelessFee = List.of(
                topRow("BSSIOTPP1", "헬로표준",        3132462L, 12.8,  1L,  1L,  100.0, 0L),
                topRow("PL23B1942", "5G 슬림 4GB",     939226L,  3.84, 65L, 65L, 100.0, 4L),
                topRow("5GINTMPP2", "5G 슬림 14GB",    831803L,  3.4,  65L, 65L, 100.0, 1L),
                topRow("5GINTMPP3", "베이직",          697324L,  2.85, 65L, 65L, 100.0, 4L),
                topRow("KDRTLTE40", "LTE 베이직",      615335L,  2.51, 62L, 62L, 100.0, 4L),
                topRow("PL225V838", "5G 심플 30GB",    611458L,  2.5,  65L, 65L, 100.0, 4L),
                topRow("5GINTMPP7", "5G 심플 110GB",   581912L,  2.38, 65L, 65L, 100.0, 3L),
                topRow("DATATGWRA", "데이터 투게더 Wearable", 563463L, 2.3, 51L, 51L, 100.0, 75L),
                topRow("PL2093132", "5G 슬림 7GB",     545766L,  2.23, 65L, 65L, 100.0, 0L),
                topRow("W3GMONITR", "3G중계기감시용",  519513L,  2.12, 1L,  1L,  100.0, 0L)
        );

        FilteredProductList topSubscriber = FilteredProductList.builder()
                .wirelessFeePlan(topWirelessFee)
                .wirelessAddOn(List.of())   // 화면에 안 보임 → 실제 데이터로 교체
                .wiredFeePlan(List.of())
                .wiredAddOn(List.of())
                .build();

        // ──── 섹션 3: 사용내역 없는 상품 ────
        List<ProductRow> noUsageWirelessFee = List.of(
                noUsageRow("OLD3GLG01", "3G LG 구형 요금제",  8432L, 0.03, 0L, "2024-08-12", "사용없음"),
                noUsageRow("LEGACY2G1", "2G 종량형",         5128L, 0.02, 0L, "2024-06-30", "사용없음"),
                noUsageRow("TESTPROD1", "테스트용 요금제 A",  2891L, 0.01, 0L, "2025-02-15", "테스트"),
                noUsageRow("PROMO2024", "2024 프로모션 종료", 1054L, 0.00, 0L, "2024-12-31", "종료"),
                noUsageRow("INACTIV01", "휴면 전용 요금제",    832L, 0.00, 0L, "2024-11-20", "휴면"),
                noUsageRow("DISCONT02", "단종 데이터팩",       421L, 0.00, 0L, "2024-05-10", "단종"),
                noUsageRow("SPECEVT01", "특별 이벤트 종료",    289L, 0.00, 0L, "2024-09-30", "종료"),
                noUsageRow("BETATEST1", "베타 테스트 요금제",  154L, 0.00, 0L, "2025-01-05", "베타"),
                noUsageRow("LIMITED01", "한정판 요금제 A",      98L, 0.00, 0L, "2024-12-15", "한정판"),
                noUsageRow("TEMPHOLD1", "임시 보류 요금제",     42L, 0.00, 0L, "2025-03-20", "보류")
        );

        FilteredProductList noUsage = FilteredProductList.builder()
                .wirelessFeePlan(noUsageWirelessFee)
                .wirelessAddOn(List.of())
                .wiredFeePlan(List.of())
                .wiredAddOn(List.of())
                .build();

        // ──── 섹션 4: 가입자 없는 상품 샘플 ────
        NoSubscriberSample noSubSample = NoSubscriberSample.builder()
                .totalCount(4234)
                .samples(List.of(
                        nsRow("NOSUB001", "신규 미출시 요금제 A", "무선 요금제",  "준비중", "2025-12-15"),
                        nsRow("NOSUB002", "준비중인 부가서비스",   "무선 부가상품","준비중", "2025-12-20"),
                        nsRow("NOSUB003", "테스트용 상품 코드",    "무선 요금제",  "테스트", "2025-11-30"),
                        nsRow("NOSUB004", "내부 검증 상품",        "유선 요금제",  "내부용", "2025-10-15"),
                        nsRow("NOSUB005", "마이그레이션 임시",     "무선 부가상품","임시",   "2025-09-22"),
                        nsRow("NOSUB006", "신상품 후보 B",         "유선 부가상품","준비중", "2025-12-01"),
                        nsRow("NOSUB007", "베타 미출시",           "무선 요금제",  "베타",   "2025-11-10"),
                        nsRow("NOSUB008", "마켓 종료 후보",        "유선 요금제",  "검토중", "2025-10-30")
                )).build();

        return ProductCoverageDetailReport.builder()
                .reportTitle("상품별 커버리지 상세")
                .periodLabel(yearMonth + " 기준")
                .generatedAt(LocalDateTime.now())
                .generatedBy(userId)
                .summary(summary)
                .topSubscriberList(topSubscriber)
                .noUsageProductList(noUsage)
                .noSubscriberSample(noSubSample)
                .build();
    }

    // 헬퍼
    private ProductRow topRow(String code, String name, long sub, double ratio,
                              long occ, long ext, double verify, long custCnt) {
        return ProductRow.builder()
                .productCode(code).productName(name)
                .subscriberCount(sub).subscriberRatio(ratio)
                .occurredItemCount(occ).extractedItemCount(ext)
                .verifyResultPct(verify).extractedCustomerCount(custCnt)
                .build();
    }

    private ProductRow noUsageRow(String code, String name, long sub, double ratio,
                                  long usage, String lastDate, String badge) {
        return ProductRow.builder()
                .productCode(code).productName(name)
                .subscriberCount(sub).subscriberRatio(ratio)
                .occurredItemCount(null)        // 화면에 "—"로 표시됨
                .usageCount(usage)
                .lastUsageDate(lastDate)
                .statusBadge(badge)
                .build();
    }

    private NoSubscriberRow nsRow(String code, String name, String type, String cat, String date) {
        return NoSubscriberRow.builder()
                .productCode(code).productName(name)
                .productType(type).category(cat).registeredDate(date).build();
    }
}


// ============================================================================
//  6. SERVICE — exportProductDetail() 메서드 추가
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.CoverageReport;
import com.ktds.report.dto.ProductCoverageDetailReport;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.exporter.ReportExporter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final List<ReportExporter<?>> exporters;
    private final CoverageDataProvider coverageDataProvider;
    private final ProductDetailDataProvider productDetailDataProvider;   // 추가

    private Map<String, ReportExporter<?>> exporterMap;

    @jakarta.annotation.PostConstruct
    void init() {
        exporterMap = exporters.stream().collect(Collectors.toMap(
                e -> e.supportType().name() + ":" + e.supportFormat().name(),
                e -> e
        ));
    }

    @SuppressWarnings("unchecked")
    public void exportCoverage(ReportFormat format, OutputStream out,
                               String yearMonth, String userId) throws IOException {
        CoverageReport data = coverageDataProvider.fetch(yearMonth, userId);
        ReportExporter<CoverageReport> exporter = (ReportExporter<CoverageReport>)
                exporterMap.get(ReportType.COVERAGE_STATUS.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    @SuppressWarnings("unchecked")
    public void exportProductDetail(ReportFormat format, OutputStream out,
                                     String yearMonth, String userId) throws IOException {
        ProductCoverageDetailReport data = productDetailDataProvider.fetch(yearMonth, userId);
        ReportExporter<ProductCoverageDetailReport> exporter =
                (ReportExporter<ProductCoverageDetailReport>) exporterMap.get(
                        ReportType.PRODUCT_COVERAGE_DETAIL.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    public String buildFileName(ReportType type, ReportFormat format, String yearMonth) {
        return String.format("%s_%s.%s",
                type.getDisplayName(),
                yearMonth.replace("-", ""),
                format.getExtension());
    }
}


// ============================================================================
//  7. CONTROLLER — 엔드포인트 추가
// ============================================================================
package com.ktds.report.controller;

import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    /** 1번 탭 - 커버리지 현황 */
    @GetMapping("/coverage-status")
    public void downloadCoverageStatus(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.COVERAGE_STATUS, format, yearMonth),
                out -> reportService.exportCoverage(format, out, yearMonth, userId));
    }

    /** 2번 탭 - 상품별 커버리지 상세 */
    @GetMapping("/product-coverage-detail")
    public void downloadProductCoverageDetail(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.PRODUCT_COVERAGE_DETAIL, format, yearMonth),
                out -> reportService.exportProductDetail(format, out, yearMonth, userId));
    }

    // 공통 다운로드 처리
    @FunctionalInterface
    private interface ExportAction {
        void apply(java.io.OutputStream out) throws IOException;
    }

    private void download(HttpServletResponse res, ReportFormat format,
                          String fileName, ExportAction action) throws IOException {
        String encoded = URLEncoder.encode(fileName, StandardCharsets.UTF_8)
                .replaceAll("\\+", "%20");
        res.setContentType(format.getContentType());
        res.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + encoded + "\"; filename*=UTF-8''" + encoded);
        action.apply(res.getOutputStream());
        res.flushBuffer();
    }
}


// ============================================================================
//  8. 프론트엔드 (참고)
// ============================================================================
/*
async function downloadReport(tab, format) {
  // tab: 'coverage-status' | 'product-coverage-detail'
  // format: 'EXCEL' | 'HTML'
  const yearMonth = document.querySelector('#period').textContent.trim();
  const url = `/api/reports/${tab}?format=${format}`
            + `&yearMonth=${encodeURIComponent(yearMonth)}`;

  const res = await fetch(url);
  if (!res.ok) { alert('다운로드 실패'); return; }

  const cd = res.headers.get('content-disposition') || '';
  const m = cd.match(/filename\*=UTF-8''([^;]+)/);
  const fileName = m ? decodeURIComponent(m[1]) : `report.${format.toLowerCase()}`;

  const blob = await res.blob();
  const blobUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(blobUrl);
}

// 사용
document.querySelector('#btnTab2Excel').addEventListener('click',
  () => downloadReport('product-coverage-detail', 'EXCEL'));
document.querySelector('#btnTab2Html').addEventListener('click',
  () => downloadReport('product-coverage-detail', 'HTML'));
*/
