// ============================================================================
//  커버리지 현황 레포트 다운로드 (Excel / HTML)
//  Spring Boot 3.x + Java 21 + Apache POI 5.x
//
//  패키지 구조:
//    com.ktds.report
//      ├─ controller / ReportController.java
//      ├─ service    / ReportService.java
//      │             / exporter / ReportExporter.java          (인터페이스)
//      │                        / ExcelReportExporter.java     (Excel 구현)
//      │                        / HtmlReportExporter.java      (HTML 구현)
//      │                        / CoverageExcelExporter.java   (커버리지 Excel)
//      │                        / CoverageHtmlExporter.java    (커버리지 HTML)
//      ├─ dto        / CoverageReport.java
//      └─ enums      / ReportFormat.java / ReportType.java
// ============================================================================


// ─────────────────────────────────────────────────────────────────────────────
// build.gradle.kts
// ─────────────────────────────────────────────────────────────────────────────
/*
plugins {
    id("org.springframework.boot") version "3.3.5"
    id("io.spring.dependency-management") version "1.1.6"
    java
}

group = "com.ktds"
version = "1.0.0"

java {
    toolchain { languageVersion.set(JavaLanguageVersion.of(21)) }
}

repositories { mavenCentral() }

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-validation")

    // Apache POI
    implementation("org.apache.poi:poi:5.3.0")
    implementation("org.apache.poi:poi-ooxml:5.3.0")

    // Lombok (선택)
    compileOnly("org.projectlombok:lombok")
    annotationProcessor("org.projectlombok:lombok")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}
*/


// ============================================================================
//  1. ENUM
// ============================================================================
package com.ktds.report.enums;

public enum ReportFormat {
    EXCEL("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    HTML ("html", "text/html; charset=UTF-8");

    private final String extension;
    private final String contentType;

    ReportFormat(String extension, String contentType) {
        this.extension = extension;
        this.contentType = contentType;
    }
    public String getExtension()  { return extension; }
    public String getContentType(){ return contentType; }
}

// ----------------------------------------------------------------------------
package com.ktds.report.enums;

public enum ReportType {
    COVERAGE_STATUS("커버리지_현황");
    // 향후 다른 탭 추가 시 여기에 enum 항목 추가
    //   PRODUCT_USAGE("상품_사용현황"),
    //   ITEM_DETAIL  ("아이템_상세"),
    //   ...

    private final String displayName;
    ReportType(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}


// ============================================================================
//  2. DTO  - 커버리지 현황 데이터 모델
// ============================================================================
package com.ktds.report.dto;

import lombok.Builder;
import lombok.Getter;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Builder
public class CoverageReport {

    private String reportTitle;       // "커버리지 현황"
    private String periodLabel;       // "2026년 01월"
    private LocalDateTime generatedAt;
    private String generatedBy;       // 로그인 사용자

    private ProductCoverage  productCoverage;
    private ItemCoverage     itemCoverage;
    private CustomerCoverage customerCoverage;

    // ──────────── 상품 커버리지 ────────────
    @Getter @Builder
    public static class ProductCoverage {
        private FunnelStep totalProduct;       // ① 전체 상품
        private FunnelStep subscriberHolding;  // ② 가입자 보유
        private FunnelStep usageOccurred;      // ③ 사용내역 발생
        private FunnelStep extractionCompleted;// ④ 추출 완료
        private int marketProductCount;        // 마켓상품 94개
    }

    @Getter @Builder
    public static class FunnelStep {
        private String label;          // 전체 상품 / 가입자 보유 / ...
        private long   totalCount;     // 7,244
        private long   mobileCount;    // 요금제 모바일
        private long   internetCount;  // 인터넷전화
        private Double feePlanRate;    // 요금제 비율 (%)
        private Double addOnRate;      // 부가상품 비율 (%)
    }

    // ──────────── 아이템 커버리지 ────────────
    @Getter @Builder
    public static class ItemCoverage {
        private Ratio totalToOccurred;   // 전체→발생 (17.4%)
        private Ratio occurredToExtract; // 발생→추출 (99.9%)
        private UnextractedStatus unextracted;
    }

    @Getter @Builder
    public static class Ratio {
        private long   numerator;   // 26,280
        private long   denominator; // 151,147
        private double percent;     // 17.4
    }

    @Getter @Builder
    public static class UnextractedStatus {
        private int  unextractedCount;       // 13개
        private long totalNotOccurred;       // 124,867
        private long terminatedItem;         // 49,726
        private long noSubscriberItem;       // 28,844
        private long unusedSubscriberItem;   // 46,297
    }

    // ──────────── 고객 커버리지 ────────────
    @Getter @Builder
    public static class CustomerCoverage {
        private DirectCoverage    direct;
        private IndirectFeePlan   indirectFeePlan;
        private IndirectAddOn     indirectAddOn;
    }

    @Getter @Builder
    public static class DirectCoverage {
        private CountPair total;        // 전체 가입자
        private CountPair mobile;       // 모바일
        private CountPair internet;     // 인터넷전화
        private CountPair addOn;        // 부가상품
        private CountPair addOnMobile;  // └ 모바일
        private CountPair addOnInternet;// └ 인터넷전화
    }

    @Getter @Builder
    public static class IndirectFeePlan {
        private RatioPair totalCoverSubscriber;
        private RatioPair mobileCoverSubscriber;
        private RatioPair internetCoverSubscriber;
        private double    indirectCoverageRate;  // 35.3%
    }

    @Getter @Builder
    public static class IndirectAddOn {
        private long      totalSubscription;     // 66,388,875
        private RatioPair coverSubscription;     // 19,443,056 (29.3%)
        private long      excludedTest;          // 583,676
        private double    indirectCoverageRate;  // 29.3%
    }

    @Getter @Builder
    public static class CountPair {
        private long primary;    // 27,302,245
        private long secondary;  // 4,263
    }

    @Getter @Builder
    public static class RatioPair {
        private long   count;
        private double percent;
    }
}


// ============================================================================
//  3. EXPORTER 인터페이스
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import java.io.IOException;
import java.io.OutputStream;

/**
 * 모든 레포트 출력기의 공통 인터페이스.
 * 탭이 추가될 때마다 (ReportType, ReportFormat) 조합 구현체를 빈으로 등록.
 */
public interface ReportExporter<T> {
    ReportType   supportType();
    ReportFormat supportFormat();
    void export(T data, OutputStream out) throws IOException;
}


// ============================================================================
//  4. EXCEL EXPORTER - 커버리지 현황
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.CoverageReport;
import com.ktds.report.dto.CoverageReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.time.format.DateTimeFormatter;

@Component
public class CoverageExcelExporter implements ReportExporter<CoverageReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    // 색상 (화면 디자인 기반)
    private static final byte[] OLIVE       = {(byte) 0x6B, (byte) 0x7C, (byte) 0x3A};
    private static final byte[] OLIVE_DARK  = {(byte) 0x4A, (byte) 0x5A, (byte) 0x26};
    private static final byte[] AMBER       = {(byte) 0xC8, (byte) 0x6F, (byte) 0x1A};
    private static final byte[] AMBER_BG    = {(byte) 0xFD, (byte) 0xF6, (byte) 0xE3};
    private static final byte[] HEADER_BG   = {(byte) 0xF5, (byte) 0xF5, (byte) 0xF0};

    @Override public ReportType   supportType()   { return ReportType.COVERAGE_STATUS; }
    @Override public ReportFormat supportFormat() { return ReportFormat.EXCEL; }

    @Override
    public void export(CoverageReport data, OutputStream out) throws IOException {
        try (Workbook wb = new XSSFWorkbook()) {
            Styles s = new Styles(wb);
            Sheet sheet = wb.createSheet("커버리지 현황");
            sheet.setDisplayGridlines(false);

            // 컬럼 폭
            int[] widths = {3500, 5000, 5000, 5000, 5000, 5000, 5000, 5000};
            for (int i = 0; i < widths.length; i++) sheet.setColumnWidth(i, widths[i]);

            int rowIdx = 0;
            rowIdx = writeHeader(sheet, s, data, rowIdx);
            rowIdx = writeProductCoverage(sheet, s, data.getProductCoverage(), rowIdx);
            rowIdx++;
            rowIdx = writeItemCoverage(sheet, s, data.getItemCoverage(), rowIdx);
            rowIdx++;
            rowIdx = writeCustomerCoverage(sheet, s, data.getCustomerCoverage(), rowIdx);
            rowIdx++;
            writeFooter(sheet, s, data, rowIdx);

            // 인쇄 설정
            sheet.setFitToPage(true);
            sheet.getPrintSetup().setFitWidth((short) 1);
            sheet.getPrintSetup().setFitHeight((short) 0);
            sheet.getPrintSetup().setLandscape(true);

            wb.write(out);
        }
    }

    // ────────────────── 헤더 ──────────────────
    private int writeHeader(Sheet sheet, Styles s, CoverageReport data, int rowIdx) {
        Row title = sheet.createRow(rowIdx);
        title.setHeightInPoints(32);
        Cell tc = title.createCell(0);
        tc.setCellValue("📊 " + data.getReportTitle());
        tc.setCellStyle(s.title);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 5));

        Cell period = title.createCell(6);
        period.setCellValue(data.getPeriodLabel());
        period.setCellStyle(s.periodTag);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 6, 7));

        rowIdx++;
        Row meta = sheet.createRow(rowIdx++);
        meta.createCell(0).setCellValue("생성일시: " + data.getGeneratedAt().format(DTF)
                + "  |  생성자: " + (data.getGeneratedBy() != null ? data.getGeneratedBy() : "-"));
        meta.getCell(0).setCellStyle(s.meta);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        rowIdx++;
        return rowIdx;
    }

    // ────────────────── 상품 커버리지 ──────────────────
    private int writeProductCoverage(Sheet sheet, Styles s, ProductCoverage p, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, "📦 상품 커버리지", rowIdx);

        FunnelStep[] steps = { p.getTotalProduct(), p.getSubscriberHolding(),
                               p.getUsageOccurred(), p.getExtractionCompleted() };
        String[] labels = { "① 전체 상품", "② 가입자 보유", "③ 사용내역 발생", "④ 추출 완료" };

        Row header = sheet.createRow(rowIdx++);
        header.setHeightInPoints(22);
        for (int i = 0; i < 4; i++) {
            Cell c = header.createCell(i * 2);
            c.setCellValue(labels[i]);
            c.setCellStyle(s.funnelStepLabel);
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, i * 2, i * 2 + 1));
        }

        Row valueRow = sheet.createRow(rowIdx++);
        valueRow.setHeightInPoints(32);
        for (int i = 0; i < 4; i++) {
            Cell c = valueRow.createCell(i * 2);
            c.setCellValue(steps[i].getTotalCount());
            c.setCellStyle(s.funnelBigNumber);
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, i * 2, i * 2 + 1));
        }

        // 세부: 요금제 모바일 / 인터넷전화
        for (int line = 0; line < 2; line++) {
            Row r = sheet.createRow(rowIdx++);
            for (int i = 0; i < 4; i++) {
                FunnelStep st = steps[i];
                Cell labelCell = r.createCell(i * 2);
                Cell valCell   = r.createCell(i * 2 + 1);
                if (line == 0) {
                    labelCell.setCellValue("요금제 모바일");
                    valCell.setCellValue(st.getMobileCount());
                } else {
                    labelCell.setCellValue("인터넷전화");
                    valCell.setCellValue(st.getInternetCount());
                }
                labelCell.setCellStyle(s.funnelSubLabel);
                valCell.setCellStyle(s.funnelSubValue);
            }
        }

        // 비율 (③, ④만)
        Row rateRow = sheet.createRow(rowIdx++);
        for (int i = 2; i < 4; i++) {
            FunnelStep st = steps[i];
            if (st.getFeePlanRate() != null && st.getAddOnRate() != null) {
                Cell c = rateRow.createCell(i * 2);
                c.setCellValue(String.format("요금제 %.1f%% / 부가상품 %.1f%%",
                        st.getFeePlanRate(), st.getAddOnRate()));
                c.setCellStyle(s.funnelRate);
                sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, i * 2, i * 2 + 1));
            }
        }

        // 마켓상품 안내
        Row notice = sheet.createRow(rowIdx++);
        Cell n = notice.createCell(0);
        n.setCellValue("⚠ 마켓상품 " + p.getMarketProductCount()
                + "개: 가입 없이 적용되는 상품으로 커버리지 대상에서 제외됩니다.");
        n.setCellStyle(s.notice);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        return rowIdx;
    }

    // ────────────────── 아이템 커버리지 ──────────────────
    private int writeItemCoverage(Sheet sheet, Styles s, ItemCoverage item, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, "🏷  아이템 커버리지", rowIdx);

        // 진행률 2종
        rowIdx = writeProgressRow(sheet, s, "전체 아이템 → 발생 아이템",
                item.getTotalToOccurred(), rowIdx);
        rowIdx = writeProgressRow(sheet, s, "발생 아이템 → 고객 추출 완료",
                item.getOccurredToExtract(), rowIdx);

        // 미추출 현황 박스
        rowIdx++;
        Row ueTitle = sheet.createRow(rowIdx++);
        Cell ueT = ueTitle.createCell(0);
        ueT.setCellValue("⊘ 미추출 현황: " + item.getUnextracted().getUnextractedCount() + "개");
        ueT.setCellStyle(s.unextractedTitle);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));

        UnextractedStatus u = item.getUnextracted();
        rowIdx = writeLabelValueRow(sheet, s, "전체 미발생",            u.getTotalNotOccurred(),     rowIdx);
        rowIdx = writeLabelValueRow(sheet, s, "  ▸ 서비스·상품 종료된 아이템", u.getTerminatedItem(),       rowIdx);
        rowIdx = writeLabelValueRow(sheet, s, "  ▸ 가입자 없는 상품의 아이템",  u.getNoSubscriberItem(),     rowIdx);
        rowIdx = writeLabelValueRow(sheet, s, "  ▸ 가입자 미사용 아이템",      u.getUnusedSubscriberItem(), rowIdx);
        return rowIdx;
    }

    private int writeProgressRow(Sheet sheet, Styles s, String label, Ratio r, int rowIdx) {
        Row row = sheet.createRow(rowIdx++);
        Cell lc = row.createCell(0);
        lc.setCellValue(label);
        lc.setCellStyle(s.progressLabel);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 3));

        Cell vc = row.createCell(4);
        vc.setCellValue(String.format("%,d / %,d (%.1f%%)",
                r.getNumerator(), r.getDenominator(), r.getPercent()));
        vc.setCellStyle(s.progressValue);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 4, 7));

        // 진행률 시각화 - 다음 행에 ▓ ░ 문자열로 표시
        Row barRow = sheet.createRow(rowIdx++);
        Cell barCell = barRow.createCell(0);
        barCell.setCellValue(buildProgressBar(r.getPercent()));
        barCell.setCellStyle(s.progressBar);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        return rowIdx;
    }

    private String buildProgressBar(double percent) {
        int filled = (int) Math.round(percent / 5);
        StringBuilder sb = new StringBuilder(String.format("%.1f%%  ", percent));
        for (int i = 0; i < 20; i++) sb.append(i < filled ? "▓" : "░");
        return sb.toString();
    }

    // ────────────────── 고객 커버리지 ──────────────────
    private int writeCustomerCoverage(Sheet sheet, Styles s, CustomerCoverage c, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s, "👥 고객 커버리지", rowIdx);

        Row sub = sheet.createRow(rowIdx++);
        sub.setHeightInPoints(20);
        String[] subTitles = { "직접 커버리지", "간접 커버리지 — 요금제", "간접 커버리지 — 부가상품" };
        for (int i = 0; i < 3; i++) {
            int colStart = i * 3;
            Cell c1 = sub.createCell(colStart);
            c1.setCellValue(subTitles[i]);
            c1.setCellStyle(s.subSection);
            sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, colStart, colStart + 1));
        }

        DirectCoverage d   = c.getDirect();
        IndirectFeePlan fp = c.getIndirectFeePlan();
        IndirectAddOn   ao = c.getIndirectAddOn();

        String[][] rows = new String[][]{
            // 직접
            { "전체 가입자",  formatCountPair(d.getTotal()) },
            { "모바일",       formatCountPair(d.getMobile()) },
            { "인터넷전화",   formatCountPair(d.getInternet()) },
            { "부가상품",     formatCountPair(d.getAddOn()) },
            { "└ 모바일",     formatCountPair(d.getAddOnMobile()) },
            { "└ 인터넷전화", formatCountPair(d.getAddOnInternet()) }
        };
        String[][] feeRows = new String[][]{
            { "전체 커버 가입자",       formatRatioPair(fp.getTotalCoverSubscriber()) },
            { "모바일 커버 가입자",     formatRatioPair(fp.getMobileCoverSubscriber()) },
            { "인터넷전화 커버 가입자", formatRatioPair(fp.getInternetCoverSubscriber()) },
            { "요금제 간접 커버리지",   String.format("%.1f%%", fp.getIndirectCoverageRate()) }
        };
        String[][] addOnRows = new String[][]{
            { "전체 가입 건수",      String.format("%,d", ao.getTotalSubscription()) },
            { "커버 가입 건수",      formatRatioPair(ao.getCoverSubscription()) },
            { "테스트 제외 (일시정지 등)", String.format("%,d", ao.getExcludedTest()) },
            { "부가상품 간접 커버리지",  String.format("%.1f%%", ao.getIndirectCoverageRate()) }
        };

        int maxRows = Math.max(rows.length, Math.max(feeRows.length, addOnRows.length));
        for (int i = 0; i < maxRows; i++) {
            Row r = sheet.createRow(rowIdx++);
            writeColumnEntry(r, s, 0, i < rows.length      ? rows[i]      : null);
            writeColumnEntry(r, s, 3, i < feeRows.length   ? feeRows[i]   : null);
            writeColumnEntry(r, s, 6, i < addOnRows.length ? addOnRows[i] : null,
                              sheet, rowIdx - 1, 7);
        }
        return rowIdx;
    }

    private void writeColumnEntry(Row row, Styles s, int startCol, String[] kv) {
        if (kv == null) return;
        Cell label = row.createCell(startCol);
        Cell value = row.createCell(startCol + 1);
        boolean isRate = kv[0].contains("간접 커버리지");
        label.setCellValue(kv[0]);
        value.setCellValue(kv[1]);
        label.setCellStyle(s.kvLabel);
        value.setCellStyle(isRate ? s.kvValueAccent : s.kvValue);
    }

    private void writeColumnEntry(Row row, Styles s, int startCol, String[] kv,
                                   Sheet sheet, int rowIdx, int endCol) {
        writeColumnEntry(row, s, startCol, kv);
    }

    private String formatCountPair(CountPair p) {
        if (p == null) return "-";
        return String.format("%,d / %,d", p.getPrimary(), p.getSecondary());
    }
    private String formatRatioPair(RatioPair p) {
        if (p == null) return "-";
        return String.format("%,d (%.1f%%)", p.getCount(), p.getPercent());
    }

    // ────────────────── 푸터 ──────────────────
    private void writeFooter(Sheet sheet, Styles s, CoverageReport data, int rowIdx) {
        rowIdx++;
        Row footer = sheet.createRow(rowIdx);
        Cell f = footer.createCell(0);
        f.setCellValue("※ 본 자료는 자동 생성되었으며, 데이터는 " + data.getPeriodLabel()
                + " 기준입니다.");
        f.setCellStyle(s.footer);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 7));
    }

    // ────────────────── 공용 ──────────────────
    private int writeSectionTitle(Sheet sheet, Styles s, String text, int rowIdx) {
        Row r = sheet.createRow(rowIdx++);
        r.setHeightInPoints(26);
        Cell c = r.createCell(0);
        c.setCellValue(text);
        c.setCellStyle(s.sectionTitle);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 7));
        return rowIdx;
    }

    private int writeLabelValueRow(Sheet sheet, Styles s, String label, long val, int rowIdx) {
        Row r = sheet.createRow(rowIdx++);
        Cell l = r.createCell(0);
        Cell v = r.createCell(7);
        l.setCellValue(label);
        v.setCellValue(val);
        l.setCellStyle(s.kvLabel);
        v.setCellStyle(s.kvValue);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 6));
        return rowIdx;
    }

    // ────────────────── 스타일 모음 ──────────────────
    private static class Styles {
        final CellStyle title, periodTag, meta, sectionTitle, subSection;
        final CellStyle funnelStepLabel, funnelBigNumber, funnelSubLabel, funnelSubValue, funnelRate;
        final CellStyle notice, progressLabel, progressValue, progressBar;
        final CellStyle unextractedTitle, kvLabel, kvValue, kvValueAccent, footer;

        Styles(Workbook wb) {
            DataFormat fmt = wb.createDataFormat();

            title           = build(wb, 18, true,  IndexedColors.DARK_GREEN.index, null, HorizontalAlignment.LEFT,   true,  null);
            periodTag       = build(wb, 11, true,  IndexedColors.WHITE.index, IndexedColors.DARK_GREEN.index, HorizontalAlignment.CENTER, true,  null);
            meta            = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index, null, HorizontalAlignment.LEFT, false, null);
            sectionTitle    = build(wb, 13, true,  IndexedColors.DARK_GREEN.index, IndexedColors.LIGHT_CORNFLOWER_BLUE.index, HorizontalAlignment.LEFT, true,  null);
            subSection      = build(wb, 11, true,  IndexedColors.DARK_GREEN.index, null, HorizontalAlignment.LEFT, true,  BorderStyle.MEDIUM);
            funnelStepLabel = build(wb, 10, true,  IndexedColors.WHITE.index, IndexedColors.DARK_GREEN.index, HorizontalAlignment.CENTER, true, BorderStyle.THIN);
            funnelBigNumber = build(wb, 20, true,  IndexedColors.BLACK.index, IndexedColors.LIGHT_YELLOW.index, HorizontalAlignment.CENTER, true, BorderStyle.THIN);
            funnelSubLabel  = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index, null, HorizontalAlignment.LEFT, true, BorderStyle.THIN);
            funnelSubValue  = build(wb, 10, true,  IndexedColors.BLACK.index, null, HorizontalAlignment.RIGHT, true, BorderStyle.THIN);
            funnelSubValue.setDataFormat(fmt.getFormat("#,##0"));
            funnelRate      = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index, null, HorizontalAlignment.LEFT, true, BorderStyle.THIN);
            notice          = build(wb, 10, false, IndexedColors.BROWN.index, IndexedColors.LIGHT_YELLOW.index, HorizontalAlignment.LEFT, true, null);

            progressLabel   = build(wb, 11, true,  IndexedColors.BLACK.index, null, HorizontalAlignment.LEFT,   true,  null);
            progressValue   = build(wb, 11, true,  IndexedColors.DARK_GREEN.index, null, HorizontalAlignment.RIGHT, true,  null);
            progressBar     = build(wb, 11, false, IndexedColors.DARK_GREEN.index, null, HorizontalAlignment.LEFT,   true,  null);
            Font monoFont = wb.createFont();
            monoFont.setFontName("Consolas");
            monoFont.setFontHeightInPoints((short) 11);
            monoFont.setColor(IndexedColors.DARK_GREEN.index);
            progressBar.setFont(monoFont);

            unextractedTitle= build(wb, 12, true,  IndexedColors.BROWN.index, IndexedColors.LIGHT_YELLOW.index, HorizontalAlignment.LEFT, true, BorderStyle.MEDIUM);
            kvLabel         = build(wb, 10, false, IndexedColors.GREY_80_PERCENT.index, null, HorizontalAlignment.LEFT,  true, BorderStyle.HAIR);
            kvValue         = build(wb, 10, true,  IndexedColors.BLACK.index, null, HorizontalAlignment.RIGHT, true, BorderStyle.HAIR);
            kvValueAccent   = build(wb, 11, true,  IndexedColors.BROWN.index, null, HorizontalAlignment.RIGHT, true, BorderStyle.HAIR);
            footer          = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index, null, HorizontalAlignment.CENTER, false, null);
        }

        private CellStyle build(Workbook wb, int fontPt, boolean bold, short fontColor,
                                Short bgColor, HorizontalAlignment align, boolean wrap,
                                BorderStyle border) {
            CellStyle cs = wb.createCellStyle();
            Font f = wb.createFont();
            f.setFontHeightInPoints((short) fontPt);
            f.setBold(bold);
            f.setColor(fontColor);
            f.setFontName("맑은 고딕");
            cs.setFont(f);
            cs.setAlignment(align);
            cs.setVerticalAlignment(VerticalAlignment.CENTER);
            cs.setWrapText(wrap);
            if (bgColor != null) {
                cs.setFillForegroundColor(bgColor);
                cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            }
            if (border != null) {
                cs.setBorderTop(border);    cs.setBorderBottom(border);
                cs.setBorderLeft(border);   cs.setBorderRight(border);
                cs.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setTopBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setRightBorderColor(IndexedColors.GREY_40_PERCENT.index);
            }
            return cs;
        }
    }
}


// ============================================================================
//  5. HTML EXPORTER - 커버리지 현황
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.CoverageReport;
import com.ktds.report.dto.CoverageReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;

@Component
public class CoverageHtmlExporter implements ReportExporter<CoverageReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Override public ReportType   supportType()   { return ReportType.COVERAGE_STATUS; }
    @Override public ReportFormat supportFormat() { return ReportFormat.HTML; }

    @Override
    public void export(CoverageReport data, OutputStream out) throws IOException {
        try (Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
            w.write(buildHtml(data));
        }
    }

    private String buildHtml(CoverageReport d) {
        StringBuilder sb = new StringBuilder(8192);
        sb.append("<!doctype html><html lang=\"ko\"><head><meta charset=\"UTF-8\">")
          .append("<title>").append(escape(d.getReportTitle())).append("</title>")
          .append(css())
          .append("</head><body><div class=\"report\">");

        // 헤더
        sb.append("<header class=\"hdr\">")
          .append("<div class=\"hdr-left\"><h1>📊 ").append(escape(d.getReportTitle())).append("</h1>")
          .append("<div class=\"meta\">생성일시: ").append(d.getGeneratedAt().format(DTF))
          .append(" &nbsp;|&nbsp; 생성자: ").append(escape(nullToDash(d.getGeneratedBy())))
          .append("</div></div>")
          .append("<div class=\"period-tag\">").append(escape(d.getPeriodLabel())).append("</div>")
          .append("</header>");

        sb.append(productSection(d.getProductCoverage()));
        sb.append(itemSection(d.getItemCoverage()));
        sb.append(customerSection(d.getCustomerCoverage()));

        sb.append("<footer class=\"ftr\">※ 본 자료는 자동 생성되었으며, 데이터는 ")
          .append(escape(d.getPeriodLabel())).append(" 기준입니다.</footer>");

        sb.append("</div></body></html>");
        return sb.toString();
    }

    // ────────────────── 상품 커버리지 ──────────────────
    private String productSection(ProductCoverage p) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>📦 상품 커버리지</h2>")
          .append("<div class=\"funnel\">");

        FunnelStep[] steps = { p.getTotalProduct(), p.getSubscriberHolding(),
                               p.getUsageOccurred(), p.getExtractionCompleted() };
        String[] labels = { "① 전체 상품", "② 가입자 보유", "③ 사용내역 발생", "④ 추출 완료" };

        for (int i = 0; i < steps.length; i++) {
            FunnelStep st = steps[i];
            sb.append("<div class=\"funnel-step\">")
              .append("<div class=\"step-label\">").append(labels[i]).append("</div>")
              .append("<div class=\"step-value\">").append(String.format("%,d", st.getTotalCount())).append("</div>")
              .append("<div class=\"step-detail\">")
              .append("<span>요금제 모바일</span><span>").append(String.format("%,d", st.getMobileCount())).append("</span></div>")
              .append("<div class=\"step-detail\">")
              .append("<span>인터넷전화</span><span>").append(String.format("%,d", st.getInternetCount())).append("</span></div>");
            if (st.getFeePlanRate() != null && st.getAddOnRate() != null) {
                sb.append("<div class=\"step-rate\">요금제 ").append(String.format("%.1f%%", st.getFeePlanRate()))
                  .append(" / 부가상품 ").append(String.format("%.1f%%", st.getAddOnRate())).append("</div>");
            }
            sb.append("</div>");
        }
        sb.append("</div>");
        sb.append("<div class=\"notice\">⚠ <b>마켓상품 ").append(p.getMarketProductCount()).append("개</b>: ")
          .append("가입 없이 적용되는 상품으로 커버리지 대상에서 제외됩니다.</div>");
        sb.append("</section>");
        return sb.toString();
    }

    // ────────────────── 아이템 커버리지 ──────────────────
    private String itemSection(ItemCoverage item) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>🏷  아이템 커버리지</h2>")
          .append("<div class=\"item-grid\"><div class=\"item-left\">");

        sb.append(progressBlock("전체 아이템 → 발생 아이템", item.getTotalToOccurred()));
        sb.append(progressBlock("발생 아이템 → 고객 추출 완료", item.getOccurredToExtract()));

        sb.append("</div>");

        UnextractedStatus u = item.getUnextracted();
        sb.append("<div class=\"unextracted-box\">")
          .append("<div class=\"ue-head\">⊘ 미추출 현황</div>")
          .append("<div class=\"ue-count\">").append(u.getUnextractedCount()).append("개</div>")
          .append("<table class=\"ue-table\">")
          .append(row("전체 미발생",            String.format("%,d개", u.getTotalNotOccurred())))
          .append(row("▸ 서비스·상품 종료된 아이템", String.format("%,d개", u.getTerminatedItem())))
          .append(row("▸ 가입자 없는 상품의 아이템",  String.format("%,d개", u.getNoSubscriberItem())))
          .append(row("▸ 가입자 미사용 아이템",      String.format("%,d개", u.getUnusedSubscriberItem())))
          .append("</table></div>");

        sb.append("</div></section>");
        return sb.toString();
    }

    private String progressBlock(String label, Ratio r) {
        return "<div class=\"progress-block\">"
             + "<div class=\"pb-head\"><span>" + label + "</span>"
             + "<span class=\"pb-val\">" + String.format("%,d / %,d (%.1f%%)",
                                  r.getNumerator(), r.getDenominator(), r.getPercent()) + "</span></div>"
             + "<div class=\"pb-bar\"><div class=\"pb-fill\" style=\"width:" + r.getPercent() + "%\"></div></div>"
             + "<div class=\"pb-percent\">" + String.format("%.1f%%", r.getPercent()) + "</div>"
             + "</div>";
    }

    private String row(String l, String v) {
        return "<tr><td>" + l + "</td><td class=\"num\">" + v + "</td></tr>";
    }

    // ────────────────── 고객 커버리지 ──────────────────
    private String customerSection(CustomerCoverage c) {
        DirectCoverage d   = c.getDirect();
        IndirectFeePlan fp = c.getIndirectFeePlan();
        IndirectAddOn   ao = c.getIndirectAddOn();

        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\"><h2>👥 고객 커버리지</h2>")
          .append("<div class=\"customer-grid\">");

        // 직접
        sb.append("<div class=\"sub-section\"><h3>직접 커버리지</h3><table class=\"kv\">")
          .append(row("전체 가입자",  cp(d.getTotal())))
          .append(row("모바일",       cp(d.getMobile())))
          .append(row("인터넷전화",   cp(d.getInternet())))
          .append(row("부가상품",     cp(d.getAddOn())))
          .append(row("└ 모바일",     cp(d.getAddOnMobile())))
          .append(row("└ 인터넷전화", cp(d.getAddOnInternet())))
          .append("</table></div>");

        // 간접 - 요금제
        sb.append("<div class=\"sub-section\"><h3>간접 커버리지 — 요금제</h3><table class=\"kv\">")
          .append(row("전체 커버 가입자",       rp(fp.getTotalCoverSubscriber())))
          .append(row("모바일 커버 가입자",     rp(fp.getMobileCoverSubscriber())))
          .append(row("인터넷전화 커버 가입자", rp(fp.getInternetCoverSubscriber())))
          .append("<tr class=\"accent\"><td>요금제 간접 커버리지</td><td class=\"num\">")
          .append(String.format("%.1f%%", fp.getIndirectCoverageRate())).append("</td></tr>")
          .append("</table>")
          .append("<div class=\"bar-mini\"><div style=\"width:")
          .append(fp.getIndirectCoverageRate()).append("%\"></div></div>")
          .append("</div>");

        // 간접 - 부가상품
        sb.append("<div class=\"sub-section\"><h3>간접 커버리지 — 부가상품</h3><table class=\"kv\">")
          .append(row("전체 가입 건수",      String.format("%,d", ao.getTotalSubscription())))
          .append(row("커버 가입 건수",      rp(ao.getCoverSubscription())))
          .append(row("테스트 제외 (일시정지 등)", String.format("%,d", ao.getExcludedTest())))
          .append("<tr class=\"accent\"><td>부가상품 간접 커버리지</td><td class=\"num\">")
          .append(String.format("%.1f%%", ao.getIndirectCoverageRate())).append("</td></tr>")
          .append("</table>")
          .append("<div class=\"bar-mini\"><div style=\"width:")
          .append(ao.getIndirectCoverageRate()).append("%\"></div></div>")
          .append("</div>");

        sb.append("</div></section>");
        return sb.toString();
    }

    private String cp(CountPair p) {
        return p == null ? "-" : String.format("%,d / %,d", p.getPrimary(), p.getSecondary());
    }
    private String rp(RatioPair p) {
        return p == null ? "-" : String.format("%,d (%.1f%%)", p.getCount(), p.getPercent());
    }
    private String nullToDash(String s) { return s == null || s.isBlank() ? "-" : s; }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                .replace("\"","&quot;");
    }

    // ────────────────── CSS ──────────────────
    private String css() {
        return "<style>"
             + "*{box-sizing:border-box;margin:0;padding:0;}"
             + "body{font-family:'맑은 고딕','Malgun Gothic',sans-serif;background:#f5f5f0;color:#2a2a28;padding:24px;}"
             + ".report{max-width:1280px;margin:0 auto;background:#fff;border-radius:12px;padding:32px;box-shadow:0 2px 12px rgba(0,0,0,0.06);}"
             + ".hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:20px;border-bottom:2px solid #6b7c3a;margin-bottom:24px;}"
             + ".hdr h1{font-size:22px;color:#4a5a26;margin-bottom:6px;}"
             + ".meta{font-size:12px;color:#888;}"
             + ".period-tag{background:#4a5a26;color:#fff;padding:8px 16px;border-radius:6px;font-weight:bold;font-size:13px;}"
             + ".card{border:1px solid #e5e5dc;border-radius:8px;padding:24px;margin-bottom:20px;background:#fafaf5;}"
             + ".card h2{font-size:16px;color:#4a5a26;margin-bottom:16px;padding-bottom:8px;border-bottom:1px solid #d9d9c8;}"
             + ".funnel{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;}"
             + ".funnel-step{background:#fff;border:1px solid #d9d9c8;border-radius:6px;padding:14px;}"
             + ".step-label{background:#6b7c3a;color:#fff;border-radius:50%;width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:bold;margin-bottom:8px;}"
             + ".step-value{font-size:28px;font-weight:bold;color:#2a2a28;margin-bottom:6px;}"
             + ".step-detail{display:flex;justify-content:space-between;font-size:11px;color:#666;padding:2px 0;}"
             + ".step-detail span:last-child{font-weight:bold;color:#2a2a28;}"
             + ".step-rate{margin-top:6px;font-size:10px;color:#888;border-top:1px dashed #ddd;padding-top:4px;}"
             + ".notice{margin-top:16px;background:#fdf6e3;border-left:3px solid #c86f1a;padding:10px 14px;font-size:12px;color:#7a5a1a;border-radius:4px;}"
             + ".item-grid{display:grid;grid-template-columns:1fr 320px;gap:20px;align-items:start;}"
             + ".progress-block{margin-bottom:18px;}"
             + ".pb-head{display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px;}"
             + ".pb-val{font-weight:bold;color:#4a5a26;}"
             + ".pb-bar{height:14px;background:#e5e5dc;border-radius:7px;overflow:hidden;}"
             + ".pb-fill{height:100%;background:linear-gradient(90deg,#6b7c3a,#8a9c4a);}"
             + ".pb-percent{font-size:11px;color:#888;margin-top:3px;}"
             + ".unextracted-box{background:#fdf6e3;border:1px solid #e8c98a;border-radius:6px;padding:16px;}"
             + ".ue-head{font-size:13px;color:#c86f1a;font-weight:bold;margin-bottom:6px;}"
             + ".ue-count{font-size:28px;font-weight:bold;color:#7a5a1a;margin-bottom:10px;}"
             + ".ue-table{width:100%;border-collapse:collapse;font-size:11px;}"
             + ".ue-table td{padding:4px 0;color:#666;}"
             + ".ue-table td.num{text-align:right;font-weight:bold;color:#2a2a28;}"
             + ".customer-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;}"
             + ".sub-section h3{font-size:13px;color:#4a5a26;border-bottom:1px solid #d9d9c8;padding-bottom:6px;margin-bottom:10px;}"
             + ".kv{width:100%;border-collapse:collapse;font-size:12px;}"
             + ".kv td{padding:6px 4px;}"
             + ".kv td.num{text-align:right;font-weight:bold;}"
             + ".kv tr.accent td{color:#c86f1a;border-top:1px solid #d9d9c8;padding-top:8px;font-weight:bold;}"
             + ".bar-mini{height:6px;background:#e5e5dc;border-radius:3px;overflow:hidden;margin-top:8px;}"
             + ".bar-mini div{height:100%;background:#c86f1a;}"
             + ".ftr{text-align:center;font-size:11px;color:#888;margin-top:24px;padding-top:16px;border-top:1px dashed #ddd;}"
             + "@media print{body{background:#fff;padding:0;}.report{box-shadow:none;padding:16px;}.card{break-inside:avoid;}}"
             + "</style>";
    }
}


// ============================================================================
//  6. SERVICE - 디스패처
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.CoverageReport;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.exporter.ReportExporter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final List<ReportExporter<?>> exporters;
    private final CoverageDataProvider coverageDataProvider;

    private Map<String, ReportExporter<?>> exporterMap;

    @jakarta.annotation.PostConstruct
    void init() {
        // 키: "TYPE:FORMAT"
        exporterMap = exporters.stream().collect(Collectors.toMap(
                e -> e.supportType().name() + ":" + e.supportFormat().name(),
                e -> e
        ));
    }

    @SuppressWarnings("unchecked")
    public void exportCoverage(ReportFormat format, OutputStream out,
                               // 필요한 조회 조건 (예: 기준년월)
                               String yearMonth, String userId) throws IOException {

        // 1) 실제 데이터 조회 (DB / Phoenix / API 등)
        CoverageReport data = coverageDataProvider.fetch(yearMonth, userId);

        // 2) 해당 (탭, 포맷)에 맞는 Exporter 선택
        ReportExporter<CoverageReport> exporter = (ReportExporter<CoverageReport>)
                exporterMap.get(ReportType.COVERAGE_STATUS.name() + ":" + format.name());

        if (exporter == null) {
            throw new IllegalStateException("지원하지 않는 레포트 형식: " + format);
        }
        exporter.export(data, out);
    }

    public String buildFileName(ReportType type, ReportFormat format, String yearMonth) {
        return String.format("%s_%s.%s",
                type.getDisplayName(),
                yearMonth.replace("-", ""),
                format.getExtension());
    }
}


// ============================================================================
//  7. 데이터 조회 어댑터 (Phoenix/Oracle/HBase 등에서 실제 데이터 가져오는 부분)
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.CoverageReport;
import com.ktds.report.dto.CoverageReport.*;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * 실제 환경에서는 JPA/JdbcTemplate으로 Phoenix/Oracle을 조회.
 * 여기서는 화면 캡처의 샘플 데이터를 그대로 반환.
 */
@Component
public class CoverageDataProvider {

    public CoverageReport fetch(String yearMonth, String userId) {

        // ──── 상품 커버리지 (4단계 퍼널)
        ProductCoverage product = ProductCoverage.builder()
                .totalProduct(FunnelStep.builder()
                        .label("전체 상품").totalCount(7244)
                        .mobileCount(7202).internetCount(42).build())
                .subscriberHolding(FunnelStep.builder()
                        .label("가입자 보유").totalCount(4263)
                        .mobileCount(4236).internetCount(27)
                        .feePlanRate(58.8).addOnRate(36.7).build())
                .usageOccurred(FunnelStep.builder()
                        .label("사용내역 발생").totalCount(52)
                        .mobileCount(52).internetCount(0)
                        .feePlanRate(1.2).addOnRate(5.8).build())
                .extractionCompleted(FunnelStep.builder()
                        .label("추출 완료").totalCount(55)
                        .mobileCount(55).internetCount(0)
                        .feePlanRate(105.8).addOnRate(100.0).build())
                .marketProductCount(94)
                .build();

        // ──── 아이템 커버리지
        ItemCoverage item = ItemCoverage.builder()
                .totalToOccurred(Ratio.builder()
                        .numerator(26280).denominator(151147).percent(17.4).build())
                .occurredToExtract(Ratio.builder()
                        .numerator(26267).denominator(26280).percent(99.9).build())
                .unextracted(UnextractedStatus.builder()
                        .unextractedCount(13)
                        .totalNotOccurred(124867)
                        .terminatedItem(49726)
                        .noSubscriberItem(28844)
                        .unusedSubscriberItem(46297)
                        .build())
                .build();

        // ──── 고객 커버리지
        CustomerCoverage customer = CustomerCoverage.builder()
                .direct(DirectCoverage.builder()
                        .total         (CountPair.builder().primary(27302245).secondary(4263).build())
                        .mobile        (CountPair.builder().primary(24475497).secondary(4236).build())
                        .internet      (CountPair.builder().primary(2826748) .secondary(27)  .build())
                        .addOn         (CountPair.builder().primary(66388875).secondary(726) .build())
                        .addOnMobile   (CountPair.builder().primary(64713515).secondary(641) .build())
                        .addOnInternet (CountPair.builder().primary(1675360) .secondary(81)  .build())
                        .build())
                .indirectFeePlan(IndirectFeePlan.builder()
                        .totalCoverSubscriber   (RatioPair.builder().count(9638602).percent(35.3).build())
                        .mobileCoverSubscriber  (RatioPair.builder().count(9638602).percent(39.4).build())
                        .internetCoverSubscriber(RatioPair.builder().count(0)      .percent(0.0) .build())
                        .indirectCoverageRate(35.3)
                        .build())
                .indirectAddOn(IndirectAddOn.builder()
                        .totalSubscription(66388875)
                        .coverSubscription(RatioPair.builder().count(19443056).percent(29.3).build())
                        .excludedTest(583676)
                        .indirectCoverageRate(29.3)
                        .build())
                .build();

        return CoverageReport.builder()
                .reportTitle("커버리지 현황")
                .periodLabel(yearMonth + " 기준")
                .generatedAt(LocalDateTime.now())
                .generatedBy(userId)
                .productCoverage(product)
                .itemCoverage(item)
                .customerCoverage(customer)
                .build();
    }
}


// ============================================================================
//  8. CONTROLLER
// ============================================================================
package com.ktds.report.controller;

import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    /**
     * 커버리지 현황 다운로드.
     *
     *  GET /api/reports/coverage-status?format=EXCEL&yearMonth=2026-01
     *  GET /api/reports/coverage-status?format=HTML&yearMonth=2026-01
     */
    @GetMapping("/coverage-status")
    public void downloadCoverageStatus(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            // 운영에서는 SecurityContext 등에서 추출
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {

        String fileName = reportService.buildFileName(
                ReportType.COVERAGE_STATUS, format, yearMonth);
        String encoded = URLEncoder.encode(fileName, StandardCharsets.UTF_8)
                .replaceAll("\\+", "%20");

        response.setContentType(format.getContentType());
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + encoded + "\"; filename*=UTF-8''" + encoded);

        reportService.exportCoverage(format, response.getOutputStream(), yearMonth, userId);
        response.flushBuffer();
    }
}


// ============================================================================
//  9. 프론트엔드 (참고용 JavaScript)
// ============================================================================
/*
async function downloadReport(format) {  // 'EXCEL' | 'HTML'
  const yearMonth = document.querySelector('#period').textContent.trim();
  const url = `/api/reports/coverage-status?format=${format}`
            + `&yearMonth=${encodeURIComponent(yearMonth)}`;

  const res = await fetch(url);
  if (!res.ok) { alert('다운로드 실패'); return; }

  // 파일명 추출
  const cd = res.headers.get('content-disposition') || '';
  const m = cd.match(/filename\*=UTF-8''([^;]+)/);
  const fileName = m ? decodeURIComponent(m[1]) : `report.${format.toLowerCase()}`;

  const blob = await res.blob();
  const blobUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(blobUrl);
}

document.querySelector('#btnExcel').addEventListener('click', () => downloadReport('EXCEL'));
document.querySelector('#btnHtml') .addEventListener('click', () => downloadReport('HTML'));
*/
