// ============================================================================
//  아이템별 현황 레포트 (3번 탭) — 추가/수정 파일
//
//  기존 1, 2번 탭 코드는 그대로 유지하면서 이 탭만 추가합니다.
//  - enums/ReportType : 항목 1개 추가
//  - dto/ItemStatusReport : 신규
//  - service/exporter/ItemStatusExcelExporter : 신규
//  - service/exporter/ItemStatusHtmlExporter  : 신규
//  - service/ItemStatusDataProvider : 신규
//  - service/ReportService : exportItemStatus() 메서드 추가
//  - controller/ReportController : 엔드포인트 추가
// ============================================================================


// ============================================================================
//  1. ENUM 확장
// ============================================================================
package com.ktds.report.enums;

public enum ReportType {
    COVERAGE_STATUS         ("커버리지_현황"),
    PRODUCT_COVERAGE_DETAIL ("상품별_커버리지_상세"),
    ITEM_STATUS             ("아이템별_현황");          // ← 신규

    private final String displayName;
    ReportType(String displayName) { this.displayName = displayName; }
    public String getDisplayName() { return displayName; }
}


// ============================================================================
//  2. DTO — 아이템별 현황
// ============================================================================
package com.ktds.report.dto;

import lombok.Builder;
import lombok.Getter;
import java.time.LocalDateTime;
import java.util.List;

@Getter @Builder
public class ItemStatusReport {

    private String reportTitle;       // "아이템별 현황"
    private String periodLabel;       // "2026년 01월"
    private LocalDateTime generatedAt;
    private String generatedBy;

    private ItemSummary    summary;          // 1) 전체 아이템 요약
    private SpecialFeature specialFeature;   // 2) 특화 기능 아이템

    // ────────────────────────────────────────────────
    // 1) 전체 아이템 요약 — 유형별 그룹
    // ────────────────────────────────────────────────
    @Getter @Builder
    public static class ItemSummary {
        private List<TypeGroup> typeGroups;   // 무료 / 요율 / 할인
    }

    @Getter @Builder
    public static class TypeGroup {
        private ItemType type;                // 무료 / 요율 / 할인
        private List<ItemSummaryRow> rows;
    }

    public enum ItemType {
        FREE     ("무료", "free"),
        RATE     ("요율", "rate"),
        DISCOUNT ("할인", "discount");

        private final String label;
        private final String cssClass;
        ItemType(String label, String cssClass) {
            this.label = label; this.cssClass = cssClass;
        }
        public String getLabel()    { return label; }
        public String getCssClass() { return cssClass; }
    }

    @Getter @Builder
    public static class ItemSummaryRow {
        private String category;           // MPMD / 금액 / 데이터 / 로밍 / 문자 / 음성 / 컨텐츠 ...
        private long   totalCount;         // 건수: 9
        private long   occurredCount;      // 발생건수: 0
        private double occurredRatio;      // 발생비율: 13.2 (%)
        private long   noSubscribeCount;   // 미가입건수: 19
        private long   noOccurrenceCount;  // 미발생건수: 0
        private long   unusedExpiredCount; // 미사용/만료: 119
        private long   pitOccurredCount;   // PIT 건수(발생): 2
    }

    /** 발생비율 색상 구분 (화면 우상단 범례 기준) */
    public enum RatioLevel {
        HIGH ("30%+",   "high"),    // 녹색
        MID  ("10~30%", "mid"),     // 앰버
        LOW  ("10% 미만","low");    // 회색

        private final String label;
        private final String cssClass;
        RatioLevel(String label, String cssClass) {
            this.label = label; this.cssClass = cssClass;
        }
        public String getLabel()    { return label; }
        public String getCssClass() { return cssClass; }

        public static RatioLevel of(double percent) {
            if (percent >= 30.0) return HIGH;
            if (percent >= 10.0) return MID;
            return LOW;
        }
    }

    // ────────────────────────────────────────────────
    // 2) 특화 기능 아이템
    // ────────────────────────────────────────────────
    @Getter @Builder
    public static class SpecialFeature {
        private int  totalFeatureCount;     // 15개
        private long totalItemCount;        // 2,847개
        private List<SpecialFeatureRow> rows;
    }

    @Getter @Builder
    public static class SpecialFeatureRow {
        private String rateType;        // YDUM / 3STEPQR / FAMSHARE ...
        private String category;        // 데이터 / 음성 / 로밍
        private String featureDesc;     // KT Allowance pooling volume recurring rolling...
        private long   itemCount;       // 32
        private long   productCount;    // 32
        private String sampleProductName; // PL25CF848_A : Y덤_공유데이터 90GB
        private VerifyStatus verifyStatus;
    }

    public enum VerifyStatus {
        COMPLETED ("검증완료", "completed"),
        IN_PROGRESS("검증중",  "progress"),
        PENDING   ("대기",     "pending");

        private final String label;
        private final String cssClass;
        VerifyStatus(String label, String cssClass) {
            this.label = label; this.cssClass = cssClass;
        }
        public String getLabel()    { return label; }
        public String getCssClass() { return cssClass; }
    }
}


// ============================================================================
//  3. EXCEL EXPORTER — 아이템별 현황
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.ItemStatusReport;
import com.ktds.report.dto.ItemStatusReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class ItemStatusExcelExporter implements ReportExporter<ItemStatusReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Override public ReportType   supportType()   { return ReportType.ITEM_STATUS; }
    @Override public ReportFormat supportFormat() { return ReportFormat.EXCEL; }

    @Override
    public void export(ItemStatusReport data, OutputStream out) throws IOException {
        try (Workbook wb = new XSSFWorkbook()) {
            Styles s = new Styles(wb);
            Sheet sheet = wb.createSheet("아이템별 현황");
            sheet.setDisplayGridlines(false);

            // 컬럼 폭 (9컬럼)
            //  0:유형  1:카테고리  2:건수  3:발생건수  4:발생비율(bar+%)  5:미가입  6:미발생  7:미사용/만료  8:PIT
            int[] widths = { 2500, 4500, 3000, 3500, 8000, 3500, 3500, 4000, 3500 };
            for (int i = 0; i < widths.length; i++) sheet.setColumnWidth(i, widths[i]);

            int rowIdx = 0;
            rowIdx = writeHeader(sheet, s, data, rowIdx);
            rowIdx = writeSummarySection(sheet, s, data.getSummary(), rowIdx);
            rowIdx++;
            rowIdx = writeSpecialFeatureSection(sheet, s, data.getSpecialFeature(), rowIdx);
            rowIdx++;
            writeFooter(sheet, s, data, rowIdx);

            // 인쇄 설정
            sheet.setFitToPage(true);
            sheet.getPrintSetup().setFitWidth((short) 1);
            sheet.getPrintSetup().setFitHeight((short) 0);
            sheet.getPrintSetup().setLandscape(true);
            sheet.createFreezePane(0, 3);

            wb.write(out);
        }
    }

    // ────────────────── 헤더 ──────────────────
    private int writeHeader(Sheet sheet, Styles s, ItemStatusReport d, int rowIdx) {
        Row title = sheet.createRow(rowIdx);
        title.setHeightInPoints(32);
        Cell tc = title.createCell(0);
        tc.setCellValue("📚 " + d.getReportTitle());
        tc.setCellStyle(s.title);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 6));

        Cell period = title.createCell(7);
        period.setCellValue(d.getPeriodLabel());
        period.setCellStyle(s.periodTag);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 7, 8));
        rowIdx++;

        Row meta = sheet.createRow(rowIdx++);
        Cell mc = meta.createCell(0);
        mc.setCellValue("생성일시: " + d.getGeneratedAt().format(DTF)
                + "  |  생성자: " + (d.getGeneratedBy() != null ? d.getGeneratedBy() : "-"));
        mc.setCellStyle(s.meta);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 8));
        rowIdx++;
        return rowIdx;
    }

    // ────────────────── 섹션 1: 전체 아이템 요약 ──────────────────
    private int writeSummarySection(Sheet sheet, Styles s, ItemSummary summary, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s,
                "📚 전체 아이템 요약   [🟢 30%+   🟠 10~30%   ⚪ 10% 미만]", rowIdx);

        // 테이블 헤더
        rowIdx = writeSummaryHeader(sheet, s, rowIdx);

        // 유형별 그룹
        for (TypeGroup group : summary.getTypeGroups()) {
            rowIdx = writeTypeGroupTitle(sheet, s, group.getType(), rowIdx);

            for (ItemSummaryRow r : group.getRows()) {
                rowIdx = writeSummaryDataRow(sheet, s, group.getType(), r, rowIdx);
            }

            // 그룹 소계
            rowIdx = writeTypeGroupSubtotal(sheet, s, group, rowIdx);
            rowIdx++; // 그룹 간 여백
        }

        // 안내 문구
        Row notice = sheet.createRow(rowIdx++);
        Cell n = notice.createCell(0);
        n.setCellValue("ⓘ Pre rate 및 기능 Pricing Item Type 제외");
        n.setCellStyle(s.notice);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 8));
        return rowIdx;
    }

    private int writeSummaryHeader(Sheet sheet, Styles s, int rowIdx) {
        Row h = sheet.createRow(rowIdx++);
        h.setHeightInPoints(24);
        String[] cols = { "유형", "카테고리", "건수", "발생건수", "발생비율",
                          "미가입건수", "미발생건수", "미사용/만료", "PIT 건수(발생)" };
        for (int i = 0; i < cols.length; i++) {
            Cell c = h.createCell(i);
            c.setCellValue(cols[i]);
            c.setCellStyle(s.tableHeader);
        }
        return rowIdx;
    }

    private int writeTypeGroupTitle(Sheet sheet, Styles s, ItemType type, int rowIdx) {
        Row r = sheet.createRow(rowIdx++);
        r.setHeightInPoints(20);
        Cell c = r.createCell(0);
        c.setCellValue("▸ " + type.getLabel() + " (Free / Rate / Discount 구분)"
                .replace("Free / Rate / Discount 구분",
                        switch (type) {
                            case FREE     -> "Free Pricing Item";
                            case RATE     -> "Rate Pricing Item";
                            case DISCOUNT -> "Discount Pricing Item";
                        }));
        c.setCellStyle(typeGroupStyle(s, type));
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 8));
        return rowIdx;
    }

    private CellStyle typeGroupStyle(Styles s, ItemType type) {
        return switch (type) {
            case FREE     -> s.typeGroupFree;
            case RATE     -> s.typeGroupRate;
            case DISCOUNT -> s.typeGroupDiscount;
        };
    }

    private CellStyle typeBadgeStyle(Styles s, ItemType type) {
        return switch (type) {
            case FREE     -> s.typeBadgeFree;
            case RATE     -> s.typeBadgeRate;
            case DISCOUNT -> s.typeBadgeDiscount;
        };
    }

    private int writeSummaryDataRow(Sheet sheet, Styles s, ItemType type,
                                     ItemSummaryRow r, int rowIdx) {
        Row row = sheet.createRow(rowIdx++);
        row.setHeightInPoints(20);

        // 0: 유형 뱃지
        Cell typeCell = row.createCell(0);
        typeCell.setCellValue(type.getLabel());
        typeCell.setCellStyle(typeBadgeStyle(s, type));

        // 1: 카테고리
        Cell catCell = row.createCell(1);
        catCell.setCellValue(r.getCategory());
        catCell.setCellStyle(s.tableCellLeft);

        // 2, 3: 건수, 발생건수
        Cell c2 = row.createCell(2);
        c2.setCellValue(r.getTotalCount());
        c2.setCellStyle(s.tableCellNumber);

        Cell c3 = row.createCell(3);
        c3.setCellValue(r.getOccurredCount());
        c3.setCellStyle(s.tableCellNumberBold);

        // 4: 발생비율 (진행률 바 + 컬러)
        Cell c4 = row.createCell(4);
        c4.setCellValue(buildBar(r.getOccurredRatio()));
        c4.setCellStyle(ratioBarStyle(s, RatioLevel.of(r.getOccurredRatio())));

        // 5~8: 미가입 / 미발생 / 미사용 / PIT
        long[] vals = { r.getNoSubscribeCount(), r.getNoOccurrenceCount(),
                        r.getUnusedExpiredCount(), r.getPitOccurredCount() };
        for (int i = 0; i < 4; i++) {
            Cell c = row.createCell(5 + i);
            c.setCellValue(vals[i]);
            c.setCellStyle(s.tableCellNumber);
        }
        return rowIdx;
    }

    private int writeTypeGroupSubtotal(Sheet sheet, Styles s, TypeGroup group, int rowIdx) {
        long sumTotal     = group.getRows().stream().mapToLong(ItemSummaryRow::getTotalCount).sum();
        long sumOccurred  = group.getRows().stream().mapToLong(ItemSummaryRow::getOccurredCount).sum();
        long sumNoSub     = group.getRows().stream().mapToLong(ItemSummaryRow::getNoSubscribeCount).sum();
        long sumNoOcc     = group.getRows().stream().mapToLong(ItemSummaryRow::getNoOccurrenceCount).sum();
        long sumUnused    = group.getRows().stream().mapToLong(ItemSummaryRow::getUnusedExpiredCount).sum();
        long sumPit       = group.getRows().stream().mapToLong(ItemSummaryRow::getPitOccurredCount).sum();
        double avgRatio   = sumTotal == 0 ? 0 : (double) sumOccurred * 100 / sumTotal;

        Row row = sheet.createRow(rowIdx++);
        row.setHeightInPoints(22);

        Cell label = row.createCell(0);
        label.setCellValue(group.getType().getLabel() + " 소계");
        label.setCellStyle(s.subtotalLabel);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 1));

        long[] vals = { sumTotal, sumOccurred };
        for (int i = 0; i < 2; i++) {
            Cell c = row.createCell(2 + i);
            c.setCellValue(vals[i]);
            c.setCellStyle(s.subtotalNumber);
        }

        Cell ratioCell = row.createCell(4);
        ratioCell.setCellValue(String.format("평균 %.1f%%", avgRatio));
        ratioCell.setCellStyle(s.subtotalLabel);

        long[] rest = { sumNoSub, sumNoOcc, sumUnused, sumPit };
        for (int i = 0; i < 4; i++) {
            Cell c = row.createCell(5 + i);
            c.setCellValue(rest[i]);
            c.setCellStyle(s.subtotalNumber);
        }
        return rowIdx;
    }

    /** 진행률 바 — 유니코드 블록 문자 + 퍼센트 텍스트 */
    private String buildBar(double percent) {
        int filled = (int) Math.round(percent / 5);  // 20단계
        if (filled > 20) filled = 20;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20; i++) sb.append(i < filled ? "█" : "░");
        sb.append(String.format("  %.1f%%", percent));
        return sb.toString();
    }

    private CellStyle ratioBarStyle(Styles s, RatioLevel level) {
        return switch (level) {
            case HIGH -> s.ratioBarHigh;
            case MID  -> s.ratioBarMid;
            case LOW  -> s.ratioBarLow;
        };
    }

    // ────────────────── 섹션 2: 특화 기능 아이템 ──────────────────
    private int writeSpecialFeatureSection(Sheet sheet, Styles s,
                                           SpecialFeature sf, int rowIdx) {
        rowIdx = writeSectionTitle(sheet, s,
                "⭐ 특화 기능 아이템 — 요금제 정합 검증 시 별도 처리가 필요한 KT 특화 로직 "
                + "(총 " + sf.getTotalFeatureCount() + "개 특화기능 · "
                + String.format("%,d", sf.getTotalItemCount()) + "개 아이템)", rowIdx);

        // 컬럼 폭 임시 조정: 특화기능 컬럼은 충분히 넓게
        // 0:요율유형  1:카테고리  2:특화기능(설명)  3:아이템건수  4:상품건수  5:상품명(샘플)  6:검증상태
        int[] sfWidths = { 3500, 3000, 14000, 3500, 3500, 12000, 3500 };
        // 기존 컬럼 폭과 충돌하지 않게 — 같은 시트이므로 가장 큰 값 기준으로 설정
        for (int i = 0; i < sfWidths.length; i++) {
            int cur = sheet.getColumnWidth(i);
            sheet.setColumnWidth(i, Math.max(cur, sfWidths[i]));
        }

        // 헤더
        Row h = sheet.createRow(rowIdx++);
        h.setHeightInPoints(24);
        String[] cols = { "요율유형", "카테고리", "특화기능", "아이템건수",
                          "상품건수", "상품명 (샘플)", "검증 상태" };
        for (int i = 0; i < cols.length; i++) {
            Cell c = h.createCell(i);
            c.setCellValue(cols[i]);
            c.setCellStyle(s.tableHeader);
        }

        // 데이터
        for (SpecialFeatureRow r : sf.getRows()) {
            Row row = sheet.createRow(rowIdx++);
            row.setHeightInPoints(28);  // 영문 설명 줄바꿈 대비

            row.createCell(0).setCellValue(nullToDash(r.getRateType()));
            row.createCell(1).setCellValue(nullToDash(r.getCategory()));
            row.createCell(2).setCellValue(nullToDash(r.getFeatureDesc()));
            row.createCell(3).setCellValue(r.getItemCount());
            row.createCell(4).setCellValue(r.getProductCount());
            row.createCell(5).setCellValue(nullToDash(r.getSampleProductName()));
            row.createCell(6).setCellValue(r.getVerifyStatus().getLabel());

            row.getCell(0).setCellStyle(s.codeCell);
            row.getCell(1).setCellStyle(categoryBadgeStyle(s, r.getCategory()));
            row.getCell(2).setCellStyle(s.tableCellLeftWrap);
            row.getCell(3).setCellStyle(s.tableCellNumberBold);
            row.getCell(4).setCellStyle(s.tableCellNumber);
            row.getCell(5).setCellStyle(s.tableCellLeft);
            row.getCell(6).setCellStyle(verifyBadgeStyle(s, r.getVerifyStatus()));
        }
        return rowIdx;
    }

    private CellStyle categoryBadgeStyle(Styles s, String category) {
        if (category == null) return s.tableCellCenter;
        return switch (category) {
            case "데이터" -> s.catBadgeData;
            case "음성"   -> s.catBadgeVoice;
            case "로밍"   -> s.catBadgeRoaming;
            case "문자"   -> s.catBadgeSms;
            default        -> s.tableCellCenter;
        };
    }

    private CellStyle verifyBadgeStyle(Styles s, VerifyStatus status) {
        return switch (status) {
            case COMPLETED   -> s.verifyBadgeCompleted;
            case IN_PROGRESS -> s.verifyBadgeProgress;
            case PENDING     -> s.verifyBadgePending;
        };
    }

    // ────────────────── 푸터 / 공통 ──────────────────
    private void writeFooter(Sheet sheet, Styles s, ItemStatusReport d, int rowIdx) {
        rowIdx++;
        Row footer = sheet.createRow(rowIdx);
        Cell f = footer.createCell(0);
        f.setCellValue("※ 본 자료는 자동 생성되었으며, 데이터는 " + d.getPeriodLabel() + " 기준입니다.");
        f.setCellStyle(s.footer);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx, rowIdx, 0, 8));
    }

    private int writeSectionTitle(Sheet sheet, Styles s, String text, int rowIdx) {
        Row r = sheet.createRow(rowIdx++);
        r.setHeightInPoints(26);
        Cell c = r.createCell(0);
        c.setCellValue(text);
        c.setCellStyle(s.sectionTitle);
        sheet.addMergedRegion(new CellRangeAddress(rowIdx - 1, rowIdx - 1, 0, 8));
        return rowIdx;
    }

    private static String nullToDash(String s) { return s == null || s.isBlank() ? "—" : s; }

    // ────────────────── 스타일 ──────────────────
    private static class Styles {
        final CellStyle title, periodTag, meta, sectionTitle, footer, notice;
        final CellStyle tableHeader, tableCellLeft, tableCellLeftWrap, tableCellCenter;
        final CellStyle tableCellNumber, tableCellNumberBold, codeCell;
        final CellStyle typeGroupFree, typeGroupRate, typeGroupDiscount;
        final CellStyle typeBadgeFree, typeBadgeRate, typeBadgeDiscount;
        final CellStyle ratioBarHigh, ratioBarMid, ratioBarLow;
        final CellStyle subtotalLabel, subtotalNumber;
        final CellStyle catBadgeData, catBadgeVoice, catBadgeRoaming, catBadgeSms;
        final CellStyle verifyBadgeCompleted, verifyBadgeProgress, verifyBadgePending;

        Styles(Workbook wb) {
            DataFormat fmt = wb.createDataFormat();

            title           = build(wb, 18, true,  IndexedColors.DARK_GREEN.index,        null,                                      HorizontalAlignment.LEFT,   true,  null);
            periodTag       = build(wb, 11, true,  IndexedColors.WHITE.index,             IndexedColors.DARK_GREEN.index,            HorizontalAlignment.CENTER, true,  null);
            meta            = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                      HorizontalAlignment.LEFT,   false, null);
            sectionTitle    = build(wb, 13, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_CORNFLOWER_BLUE.index, HorizontalAlignment.LEFT,   true,  null);
            footer          = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                      HorizontalAlignment.CENTER, false, null);
            notice          = build(wb, 9,  false, IndexedColors.GREY_50_PERCENT.index,   null,                                      HorizontalAlignment.LEFT,   false, null);

            tableHeader     = build(wb, 10, true,  IndexedColors.WHITE.index,             IndexedColors.DARK_GREEN.index,            HorizontalAlignment.CENTER, true,  BorderStyle.THIN);
            tableCellLeft   = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                      HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            tableCellLeftWrap = build(wb, 9,  false, IndexedColors.BLACK.index,           null,                                      HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            tableCellCenter = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                      HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            tableCellNumber = build(wb, 10, false, IndexedColors.BLACK.index,             null,                                      HorizontalAlignment.RIGHT,  true,  BorderStyle.HAIR);
            tableCellNumber.setDataFormat(fmt.getFormat("#,##0"));
            tableCellNumberBold = build(wb, 10, true, IndexedColors.BLACK.index,          null,                                      HorizontalAlignment.RIGHT,  true,  BorderStyle.HAIR);
            tableCellNumberBold.setDataFormat(fmt.getFormat("#,##0"));
            codeCell        = build(wb, 10, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_YELLOW.index,          HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);

            // 유형 그룹 서브타이틀
            typeGroupFree     = build(wb, 11, true, IndexedColors.WHITE.index,            IndexedColors.GREY_50_PERCENT.index,       HorizontalAlignment.LEFT,   true,  BorderStyle.MEDIUM);
            typeGroupRate     = build(wb, 11, true, IndexedColors.WHITE.index,            IndexedColors.DARK_BLUE.index,             HorizontalAlignment.LEFT,   true,  BorderStyle.MEDIUM);
            typeGroupDiscount = build(wb, 11, true, IndexedColors.WHITE.index,            IndexedColors.BROWN.index,                 HorizontalAlignment.LEFT,   true,  BorderStyle.MEDIUM);

            // 유형 뱃지 (각 행의 1번째 셀)
            typeBadgeFree     = build(wb, 9,  true, IndexedColors.GREY_80_PERCENT.index,  IndexedColors.GREY_25_PERCENT.index,       HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            typeBadgeRate     = build(wb, 9,  true, IndexedColors.WHITE.index,            IndexedColors.LIGHT_CORNFLOWER_BLUE.index, HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            typeBadgeDiscount = build(wb, 9,  true, IndexedColors.WHITE.index,            IndexedColors.LIGHT_ORANGE.index,          HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);

            // 발생비율 바 (3단계 컬러)
            ratioBarHigh    = build(wb, 10, true,  IndexedColors.WHITE.index,             IndexedColors.GREEN.index,                 HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            Font barFontHigh = wb.createFont();
            barFontHigh.setFontName("Consolas"); barFontHigh.setFontHeightInPoints((short) 10);
            barFontHigh.setBold(true); barFontHigh.setColor(IndexedColors.WHITE.index);
            ratioBarHigh.setFont(barFontHigh);

            ratioBarMid     = build(wb, 10, true,  IndexedColors.WHITE.index,             IndexedColors.LIGHT_ORANGE.index,          HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            Font barFontMid = wb.createFont();
            barFontMid.setFontName("Consolas"); barFontMid.setFontHeightInPoints((short) 10);
            barFontMid.setBold(true); barFontMid.setColor(IndexedColors.WHITE.index);
            ratioBarMid.setFont(barFontMid);

            ratioBarLow     = build(wb, 10, false, IndexedColors.GREY_50_PERCENT.index,   IndexedColors.GREY_25_PERCENT.index,       HorizontalAlignment.LEFT,   true,  BorderStyle.HAIR);
            Font barFontLow = wb.createFont();
            barFontLow.setFontName("Consolas"); barFontLow.setFontHeightInPoints((short) 10);
            barFontLow.setColor(IndexedColors.GREY_50_PERCENT.index);
            ratioBarLow.setFont(barFontLow);

            // 소계
            subtotalLabel   = build(wb, 10, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_GREEN.index,           HorizontalAlignment.CENTER, true,  BorderStyle.MEDIUM);
            subtotalNumber  = build(wb, 10, true,  IndexedColors.DARK_GREEN.index,        IndexedColors.LIGHT_GREEN.index,           HorizontalAlignment.RIGHT,  true,  BorderStyle.MEDIUM);
            subtotalNumber.setDataFormat(fmt.getFormat("#,##0"));

            // 카테고리 뱃지 (특화기능 테이블)
            catBadgeData    = build(wb, 9,  true,  IndexedColors.WHITE.index,             IndexedColors.LIGHT_CORNFLOWER_BLUE.index, HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            catBadgeVoice   = build(wb, 9,  true,  IndexedColors.WHITE.index,             IndexedColors.LIGHT_ORANGE.index,          HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            catBadgeRoaming = build(wb, 9,  true,  IndexedColors.WHITE.index,             IndexedColors.BROWN.index,                 HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            catBadgeSms     = build(wb, 9,  true,  IndexedColors.WHITE.index,             IndexedColors.DARK_GREEN.index,            HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);

            // 검증 상태 뱃지
            verifyBadgeCompleted = build(wb, 9, true, IndexedColors.DARK_GREEN.index,     IndexedColors.LIGHT_GREEN.index,           HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            verifyBadgeProgress  = build(wb, 9, true, IndexedColors.WHITE.index,          IndexedColors.LIGHT_ORANGE.index,          HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
            verifyBadgePending   = build(wb, 9, true, IndexedColors.GREY_80_PERCENT.index, IndexedColors.GREY_25_PERCENT.index,      HorizontalAlignment.CENTER, true,  BorderStyle.HAIR);
        }

        private CellStyle build(Workbook wb, int fontPt, boolean bold, short fontColor,
                                Short bgColor, HorizontalAlignment align, boolean wrap,
                                BorderStyle border) {
            CellStyle cs = wb.createCellStyle();
            Font f = wb.createFont();
            f.setFontHeightInPoints((short) fontPt);
            f.setBold(bold);
            f.setColor(fontColor);
            f.setFontName("맑은 고딕");
            cs.setFont(f);
            cs.setAlignment(align);
            cs.setVerticalAlignment(VerticalAlignment.CENTER);
            cs.setWrapText(wrap);
            if (bgColor != null) {
                cs.setFillForegroundColor(bgColor);
                cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            }
            if (border != null) {
                cs.setBorderTop(border);    cs.setBorderBottom(border);
                cs.setBorderLeft(border);   cs.setBorderRight(border);
                cs.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setTopBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.index);
                cs.setRightBorderColor(IndexedColors.GREY_40_PERCENT.index);
            }
            return cs;
        }
    }
}


// ============================================================================
//  4. HTML EXPORTER — 아이템별 현황
// ============================================================================
package com.ktds.report.service.exporter;

import com.ktds.report.dto.ItemStatusReport;
import com.ktds.report.dto.ItemStatusReport.*;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Component
public class ItemStatusHtmlExporter implements ReportExporter<ItemStatusReport> {

    private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Override public ReportType   supportType()   { return ReportType.ITEM_STATUS; }
    @Override public ReportFormat supportFormat() { return ReportFormat.HTML; }

    @Override
    public void export(ItemStatusReport data, OutputStream out) throws IOException {
        try (Writer w = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
            w.write(buildHtml(data));
        }
    }

    private String buildHtml(ItemStatusReport d) {
        StringBuilder sb = new StringBuilder(16384);
        sb.append("<!doctype html><html lang=\"ko\"><head><meta charset=\"UTF-8\">")
          .append("<title>").append(escape(d.getReportTitle())).append("</title>")
          .append(css())
          .append("</head><body><div class=\"report\">");

        // 헤더
        sb.append("<header class=\"hdr\">")
          .append("<div class=\"hdr-left\"><h1>📚 ").append(escape(d.getReportTitle())).append("</h1>")
          .append("<div class=\"meta\">생성일시: ").append(d.getGeneratedAt().format(DTF))
          .append(" &nbsp;|&nbsp; 생성자: ").append(escape(nullToDash(d.getGeneratedBy())))
          .append("</div></div>")
          .append("<div class=\"period-tag\">").append(escape(d.getPeriodLabel())).append("</div>")
          .append("</header>");

        sb.append(summarySection(d.getSummary()));
        sb.append(specialFeatureSection(d.getSpecialFeature()));

        sb.append("<footer class=\"ftr\">※ 본 자료는 자동 생성되었으며, 데이터는 ")
          .append(escape(d.getPeriodLabel())).append(" 기준입니다.</footer>");

        sb.append("</div></body></html>");
        return sb.toString();
    }

    // ────────────────── 섹션 1: 전체 아이템 요약 ──────────────────
    private String summarySection(ItemSummary summary) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\">")
          .append("<div class=\"card-head\">")
          .append("<h2>📚 전체 아이템 요약</h2>")
          .append("<div class=\"legend\">")
          .append("<span class=\"lg-item\"><i class=\"dot dot-high\"></i>30%+</span>")
          .append("<span class=\"lg-item\"><i class=\"dot dot-mid\"></i>10~30%</span>")
          .append("<span class=\"lg-item\"><i class=\"dot dot-low\"></i>10% 미만</span>")
          .append("</div></div>");

        sb.append("<table class=\"data-table summary-table\"><thead><tr>")
          .append("<th>유형</th><th>카테고리</th><th>건수</th><th>발생건수</th>")
          .append("<th class=\"col-bar\">발생비율</th>")
          .append("<th>미가입건수</th><th>미발생건수</th><th>미사용/만료</th><th>PIT 건수(발생)</th>")
          .append("</tr></thead><tbody>");

        for (TypeGroup group : summary.getTypeGroups()) {
            // 그룹 서브타이틀 행
            sb.append("<tr class=\"group-title type-").append(group.getType().getCssClass()).append("\">")
              .append("<td colspan=\"9\">▸ ").append(escape(group.getType().getLabel()))
              .append(" <span class=\"group-sub\">— ").append(subLabel(group.getType())).append("</span>")
              .append("</td></tr>");

            // 데이터 행
            for (ItemSummaryRow r : group.getRows()) {
                sb.append("<tr>")
                  .append("<td class=\"center\"><span class=\"type-badge type-").append(group.getType().getCssClass()).append("\">")
                  .append(escape(group.getType().getLabel())).append("</span></td>")
                  .append("<td>").append(escape(r.getCategory())).append("</td>")
                  .append("<td class=\"num\">").append(String.format("%,d", r.getTotalCount())).append("</td>")
                  .append("<td class=\"num bold\">").append(String.format("%,d", r.getOccurredCount())).append("</td>")
                  .append("<td>").append(ratioBar(r.getOccurredRatio())).append("</td>")
                  .append("<td class=\"num\">").append(String.format("%,d", r.getNoSubscribeCount())).append("</td>")
                  .append("<td class=\"num\">").append(String.format("%,d", r.getNoOccurrenceCount())).append("</td>")
                  .append("<td class=\"num\">").append(String.format("%,d", r.getUnusedExpiredCount())).append("</td>")
                  .append("<td class=\"num\">").append(String.format("%,d", r.getPitOccurredCount())).append("</td>")
                  .append("</tr>");
            }

            // 소계
            long sumTotal     = group.getRows().stream().mapToLong(ItemSummaryRow::getTotalCount).sum();
            long sumOccurred  = group.getRows().stream().mapToLong(ItemSummaryRow::getOccurredCount).sum();
            long sumNoSub     = group.getRows().stream().mapToLong(ItemSummaryRow::getNoSubscribeCount).sum();
            long sumNoOcc     = group.getRows().stream().mapToLong(ItemSummaryRow::getNoOccurrenceCount).sum();
            long sumUnused    = group.getRows().stream().mapToLong(ItemSummaryRow::getUnusedExpiredCount).sum();
            long sumPit       = group.getRows().stream().mapToLong(ItemSummaryRow::getPitOccurredCount).sum();
            double avgRatio   = sumTotal == 0 ? 0 : (double) sumOccurred * 100 / sumTotal;

            sb.append("<tr class=\"subtotal\">")
              .append("<td colspan=\"2\">").append(escape(group.getType().getLabel())).append(" 소계</td>")
              .append("<td class=\"num\">").append(String.format("%,d", sumTotal)).append("</td>")
              .append("<td class=\"num\">").append(String.format("%,d", sumOccurred)).append("</td>")
              .append("<td class=\"center\">평균 ").append(String.format("%.1f%%", avgRatio)).append("</td>")
              .append("<td class=\"num\">").append(String.format("%,d", sumNoSub)).append("</td>")
              .append("<td class=\"num\">").append(String.format("%,d", sumNoOcc)).append("</td>")
              .append("<td class=\"num\">").append(String.format("%,d", sumUnused)).append("</td>")
              .append("<td class=\"num\">").append(String.format("%,d", sumPit)).append("</td>")
              .append("</tr>");
        }

        sb.append("</tbody></table>")
          .append("<div class=\"notice\">ⓘ Pre rate 및 기능 Pricing Item Type 제외</div>")
          .append("</section>");
        return sb.toString();
    }

    private String subLabel(ItemType type) {
        return switch (type) {
            case FREE     -> "Free Pricing Item";
            case RATE     -> "Rate Pricing Item";
            case DISCOUNT -> "Discount Pricing Item";
        };
    }

    private String ratioBar(double percent) {
        RatioLevel level = RatioLevel.of(percent);
        double width = Math.min(percent, 100);
        return "<div class=\"bar-wrap\">"
             + "<div class=\"bar bar-" + level.getCssClass() + "\" style=\"width:" + width + "%\"></div>"
             + "<span class=\"bar-pct bar-pct-" + level.getCssClass() + "\">"
             + String.format("%.1f%%", percent) + "</span></div>";
    }

    // ────────────────── 섹션 2: 특화 기능 아이템 ──────────────────
    private String specialFeatureSection(SpecialFeature sf) {
        StringBuilder sb = new StringBuilder();
        sb.append("<section class=\"card\">")
          .append("<div class=\"card-head\">")
          .append("<h2>⭐ 특화 기능 아이템 ")
          .append("<span class=\"sub-title\">— 요금제 정합 검증 시 별도 처리가 필요한 KT 특화 로직</span>")
          .append("</h2>")
          .append("<div class=\"summary-count\">총 <b>").append(sf.getTotalFeatureCount())
          .append("개</b> 특화기능 · <b>").append(String.format("%,d", sf.getTotalItemCount()))
          .append("개</b> 아이템</div>")
          .append("</div>");

        sb.append("<table class=\"data-table feature-table\"><thead><tr>")
          .append("<th>요율유형</th><th>카테고리</th><th>특화기능</th>")
          .append("<th>아이템건수</th><th>상품건수</th>")
          .append("<th>상품명 (샘플)</th><th>검증 상태</th>")
          .append("</tr></thead><tbody>");

        for (SpecialFeatureRow r : sf.getRows()) {
            sb.append("<tr>")
              .append("<td class=\"code\">").append(escape(nullToDash(r.getRateType()))).append("</td>")
              .append("<td class=\"center\">").append(categoryBadge(r.getCategory())).append("</td>")
              .append("<td class=\"feature-desc\">").append(escape(nullToDash(r.getFeatureDesc()))).append("</td>")
              .append("<td class=\"num bold\">").append(String.format("%,d", r.getItemCount())).append("</td>")
              .append("<td class=\"num\">").append(String.format("%,d", r.getProductCount())).append("</td>")
              .append("<td class=\"sample\">").append(escape(nullToDash(r.getSampleProductName()))).append("</td>")
              .append("<td class=\"center\">").append(verifyBadge(r.getVerifyStatus())).append("</td>")
              .append("</tr>");
        }
        sb.append("</tbody></table></section>");
        return sb.toString();
    }

    private String categoryBadge(String category) {
        if (category == null) return "—";
        String cls = switch (category) {
            case "데이터" -> "cat-data";
            case "음성"   -> "cat-voice";
            case "로밍"   -> "cat-roaming";
            case "문자"   -> "cat-sms";
            default        -> "cat-default";
        };
        return "<span class=\"cat-badge " + cls + "\">" + escape(category) + "</span>";
    }

    private String verifyBadge(VerifyStatus status) {
        return "<span class=\"verify-badge verify-" + status.getCssClass() + "\">"
             + escape(status.getLabel()) + "</span>";
    }

    private String nullToDash(String s) { return s == null || s.isBlank() ? "—" : s; }
    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");
    }

    // ────────────────── CSS ──────────────────
    private String css() {
        return "<style>"
             + "*{box-sizing:border-box;margin:0;padding:0;}"
             + "body{font-family:'맑은 고딕','Malgun Gothic',sans-serif;background:#f5f5f0;color:#2a2a28;padding:24px;}"
             + ".report{max-width:1400px;margin:0 auto;background:#fff;border-radius:12px;padding:32px;box-shadow:0 2px 12px rgba(0,0,0,0.06);}"
             + ".hdr{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:20px;border-bottom:2px solid #6b7c3a;margin-bottom:24px;}"
             + ".hdr h1{font-size:22px;color:#4a5a26;margin-bottom:6px;}"
             + ".meta{font-size:12px;color:#888;}"
             + ".period-tag{background:#4a5a26;color:#fff;padding:8px 16px;border-radius:6px;font-weight:bold;font-size:13px;}"
             + ".card{border:1px solid #e5e5dc;border-radius:8px;padding:24px;margin-bottom:20px;background:#fafaf5;}"
             + ".card-head{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:14px;padding-bottom:8px;border-bottom:1px solid #d9d9c8;}"
             + ".card h2{font-size:16px;color:#4a5a26;}"
             + ".sub-title{font-size:12px;color:#888;font-weight:normal;}"
             + ".summary-count{font-size:12px;color:#666;}"
             + ".summary-count b{color:#4a5a26;}"
             // 범례
             + ".legend{display:flex;gap:14px;font-size:11px;color:#666;}"
             + ".lg-item{display:flex;align-items:center;gap:4px;}"
             + ".dot{display:inline-block;width:10px;height:10px;border-radius:50%;}"
             + ".dot-high{background:#5b8a3a;}"
             + ".dot-mid{background:#c89134;}"
             + ".dot-low{background:#c8c8be;}"
             // 데이터 테이블 공통
             + ".data-table{width:100%;border-collapse:collapse;font-size:11px;}"
             + ".data-table th{background:#4a5a26;color:#fff;padding:9px 6px;text-align:center;font-weight:600;border:1px solid #3a4a16;}"
             + ".data-table td{padding:7px 6px;border-bottom:1px solid #e5e5dc;background:#fff;}"
             + ".data-table tr:not(.group-title):not(.subtotal):nth-child(even) td{background:#fafaf5;}"
             + ".data-table td.num{text-align:right;font-variant-numeric:tabular-nums;}"
             + ".data-table td.num.bold{font-weight:bold;}"
             + ".data-table td.center{text-align:center;}"
             + ".data-table td.code{font-family:Consolas,'D2Coding',monospace;color:#4a5a26;font-weight:bold;background:#fdf6e3 !important;}"
             // 유형 그룹 서브타이틀
             + ".group-title td{font-weight:bold;color:#fff;padding:8px 12px;border:none;}"
             + ".group-title.type-free td{background:#7d7d70 !important;}"
             + ".group-title.type-rate td{background:#3a5a8a !important;}"
             + ".group-title.type-discount td{background:#a87434 !important;}"
             + ".group-title .group-sub{font-weight:normal;font-size:10px;opacity:0.85;margin-left:8px;}"
             // 유형 뱃지
             + ".type-badge{display:inline-block;padding:2px 10px;border-radius:10px;font-size:10px;font-weight:bold;}"
             + ".type-badge.type-free{background:#e5e5dc;color:#666;}"
             + ".type-badge.type-rate{background:#dbe4f0;color:#3a5a8a;}"
             + ".type-badge.type-discount{background:#f4e0c8;color:#a87434;}"
             // 발생비율 바
             + ".col-bar{width:240px;}"
             + ".bar-wrap{position:relative;background:#eee8d8;height:18px;border-radius:9px;overflow:hidden;}"
             + ".bar{height:100%;border-radius:9px;}"
             + ".bar.bar-high{background:linear-gradient(90deg,#5b8a3a,#7da855);}"
             + ".bar.bar-mid{background:linear-gradient(90deg,#c89134,#d8a854);}"
             + ".bar.bar-low{background:#c8c8be;}"
             + ".bar-pct{position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:10px;font-weight:bold;}"
             + ".bar-pct.bar-pct-high{color:#fff;}"
             + ".bar-pct.bar-pct-mid{color:#fff;}"
             + ".bar-pct.bar-pct-low{color:#888;}"
             // 소계
             + ".subtotal td{background:#eef4d8 !important;color:#4a5a26;font-weight:bold;border-top:2px solid #6b7c3a;}"
             // 안내
             + ".notice{margin-top:10px;font-size:11px;color:#888;}"
             // 카테고리 뱃지 (특화기능)
             + ".cat-badge{display:inline-block;padding:2px 9px;border-radius:9px;font-size:10px;font-weight:bold;color:#fff;}"
             + ".cat-badge.cat-data{background:#5b7aa8;}"
             + ".cat-badge.cat-voice{background:#c8945a;}"
             + ".cat-badge.cat-roaming{background:#9a6a3a;}"
             + ".cat-badge.cat-sms{background:#6b7c3a;}"
             + ".cat-badge.cat-default{background:#999;}"
             // 검증 상태 뱃지
             + ".verify-badge{display:inline-block;padding:2px 10px;border-radius:10px;font-size:10px;font-weight:bold;}"
             + ".verify-badge.verify-completed{background:#dde8c0;color:#4a5a26;}"
             + ".verify-badge.verify-progress{background:#f4dcb8;color:#a87434;}"
             + ".verify-badge.verify-pending{background:#e5e5dc;color:#666;}"
             // 특화기능 테이블
             + ".feature-table .feature-desc{font-size:10.5px;color:#444;line-height:1.5;}"
             + ".feature-table .sample{font-size:10.5px;color:#666;}"
             + ".ftr{text-align:center;font-size:11px;color:#888;margin-top:24px;padding-top:16px;border-top:1px dashed #ddd;}"
             + "@media print{body{background:#fff;padding:0;}.report{box-shadow:none;padding:16px;}.card{break-inside:avoid;page-break-inside:avoid;}.data-table{font-size:10px;}}"
             + "</style>";
    }
}


// ============================================================================
//  5. 데이터 조회 어댑터 (샘플 데이터)
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.ItemStatusReport;
import com.ktds.report.dto.ItemStatusReport.*;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class ItemStatusDataProvider {

    public ItemStatusReport fetch(String yearMonth, String userId) {

        // ──── 섹션 1: 전체 아이템 요약 ────
        // 무료
        List<ItemSummaryRow> freeRows = List.of(
                summaryRow("MPMD",   9,       0,    0.0,  0,    0,    9,     0),
                summaryRow("금액",   159,     21,   13.2, 19,   0,    119,   2),
                summaryRow("데이터", 2974,    1218, 41.0, 870,  2,    929,   14),
                summaryRow("로밍",   14,      1,    7.1,  12,   0,    1,     0),
                summaryRow("문자",   682,     332,  48.7, 176,  0,    174,   6),
                summaryRow("음성",   1305,    603,  46.2, 278,  1,    423,   13),
                summaryRow("컨텐츠", 26,      16,   61.5, 9,    0,    1,     0)
        );

        // 요율
        List<ItemSummaryRow> rateRows = List.of(
                summaryRow("MPMD",         1,      0,    0.0,  0,     0,     1,     0),
                summaryRow("Pass through", 46706,  800,  1.7,  7181,  10516, 28210, 7),
                summaryRow("데이터",       53613,  1695, 3.2,  13762, 24495, 13665, 4),
                summaryRow("로밍",         2063,   38,   1.8,  471,   89,    1465,  6),
                summaryRow("문자",         12722,  693,  5.4,  3453,  6154,  2422,  3),
                summaryRow("음성",         10340,  1226, 11.9, 2465,  4628,  2021,  8)
        );

        // 할인
        List<ItemSummaryRow> discountRows = List.of(
                summaryRow("Pass through", 1,   0,  0.0,  0,  1,   0,  0),
                summaryRow("금액",         258, 13, 5.0,  13, 159, 73, 1),
                summaryRow("로밍",         19,  0,  0.0,  2,  2,   15, 0),
                summaryRow("마켓",         2,   1,  50.0, 0,  1,   0,  1),
                summaryRow("선할인",       30,  12, 40.0, 5,  3,   10, 5),
                summaryRow("음성",         89,  21, 23.6, 13, 41,  14, 5)
        );

        ItemSummary summary = ItemSummary.builder()
                .typeGroups(List.of(
                        TypeGroup.builder().type(ItemType.FREE)    .rows(freeRows).build(),
                        TypeGroup.builder().type(ItemType.RATE)    .rows(rateRows).build(),
                        TypeGroup.builder().type(ItemType.DISCOUNT).rows(discountRows).build()
                ))
                .build();

        // ──── 섹션 2: 특화 기능 아이템 ────
        List<SpecialFeatureRow> sfRows = List.of(
                featureRow("YDUM",      "데이터", "KT Allowance pooling volume recurring rolling restricted non period sensitive base",
                           32,  32, "PL25CF848_A : Y덤_공유데이터 90GB",      VerifyStatus.COMPLETED),
                featureRow("3STEPQR",   "데이터", "KT Rate volume Stepped Rating excluding allowance",
                           429, 4,  "QOS200STB : 데이터 초과 요금 상한",       VerifyStatus.COMPLETED),
                featureRow("3STEPQR",   "데이터", "KT Rate volume Stepped Rating excluding allowance group level",
                           429, 4,  "QOS200STB_A : 데이터 초과 요금 상한",     VerifyStatus.COMPLETED),
                featureRow("FAMSHARE",  "데이터", "KT Family data sharing pool with priority dispatch",
                           187, 12, "FAMPACK01 : 가족 공유 데이터 100GB",      VerifyStatus.COMPLETED),
                featureRow("ROLLOVR",   "데이터", "KT Data rollover to next billing cycle with cap",
                           256, 18, "ROLLDATA1 : 이월 데이터 50GB",            VerifyStatus.IN_PROGRESS),
                featureRow("BOOSTLT",   "데이터", "KT Stepped boost rate for late-month usage",
                           89,  6,  "BOOST5G01 : 5G 부스터 30GB",              VerifyStatus.COMPLETED),
                featureRow("TIMEZON",   "음성",   "KT Time-of-day differential rating for voice",
                           142, 9,  "VOICETZ01 : 시간대별 음성 요금",          VerifyStatus.COMPLETED),
                featureRow("WKNDDIS",   "음성",   "KT Weekend discount stacking with promo codes",
                           78,  5,  "WKNDFREE1 : 주말 무료 음성",              VerifyStatus.COMPLETED),
                featureRow("INTNROAM",  "로밍",   "KT International roaming with country-tier pricing",
                           312, 21, "ROAM100GL : 글로벌 100국 로밍팩",         VerifyStatus.IN_PROGRESS),
                featureRow("DUALSIM",   "음성",   "KT Dual-SIM shared minute pool with overflow",
                           64,  4,  "DUAL5G001 : 듀얼심 공유플랜",             VerifyStatus.COMPLETED),
                featureRow("NIGHTUL",   "데이터", "KT Night unlimited data outside peak hours",
                           198, 14, "NIGHTUNL1 : 심야 무제한 데이터",          VerifyStatus.COMPLETED),
                featureRow("TIERED5G",  "데이터", "KT Tiered 5G speed cap with throttle thresholds",
                           421, 23, "5GTIER100 : 5G 단계별 속도 100GB",         VerifyStatus.PENDING)
        );

        SpecialFeature specialFeature = SpecialFeature.builder()
                .totalFeatureCount(15)
                .totalItemCount(2847)
                .rows(sfRows)
                .build();

        return ItemStatusReport.builder()
                .reportTitle("아이템별 현황")
                .periodLabel(yearMonth + " 기준")
                .generatedAt(LocalDateTime.now())
                .generatedBy(userId)
                .summary(summary)
                .specialFeature(specialFeature)
                .build();
    }

    // 헬퍼
    private ItemSummaryRow summaryRow(String category, long total, long occurred, double ratio,
                                       long noSub, long noOcc, long unused, long pit) {
        return ItemSummaryRow.builder()
                .category(category)
                .totalCount(total).occurredCount(occurred).occurredRatio(ratio)
                .noSubscribeCount(noSub).noOccurrenceCount(noOcc)
                .unusedExpiredCount(unused).pitOccurredCount(pit)
                .build();
    }

    private SpecialFeatureRow featureRow(String rateType, String category, String desc,
                                          long itemCnt, long prodCnt, String sample,
                                          VerifyStatus status) {
        return SpecialFeatureRow.builder()
                .rateType(rateType).category(category).featureDesc(desc)
                .itemCount(itemCnt).productCount(prodCnt)
                .sampleProductName(sample).verifyStatus(status)
                .build();
    }
}


// ============================================================================
//  6. SERVICE — exportItemStatus() 메서드 추가
// ============================================================================
package com.ktds.report.service;

import com.ktds.report.dto.CoverageReport;
import com.ktds.report.dto.ItemStatusReport;
import com.ktds.report.dto.ProductCoverageDetailReport;
import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.exporter.ReportExporter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final List<ReportExporter<?>> exporters;
    private final CoverageDataProvider coverageDataProvider;
    private final ProductDetailDataProvider productDetailDataProvider;
    private final ItemStatusDataProvider itemStatusDataProvider;   // 추가

    private Map<String, ReportExporter<?>> exporterMap;

    @jakarta.annotation.PostConstruct
    void init() {
        exporterMap = exporters.stream().collect(Collectors.toMap(
                e -> e.supportType().name() + ":" + e.supportFormat().name(),
                e -> e
        ));
    }

    @SuppressWarnings("unchecked")
    public void exportCoverage(ReportFormat format, OutputStream out,
                               String yearMonth, String userId) throws IOException {
        CoverageReport data = coverageDataProvider.fetch(yearMonth, userId);
        ReportExporter<CoverageReport> exporter = (ReportExporter<CoverageReport>)
                exporterMap.get(ReportType.COVERAGE_STATUS.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    @SuppressWarnings("unchecked")
    public void exportProductDetail(ReportFormat format, OutputStream out,
                                     String yearMonth, String userId) throws IOException {
        ProductCoverageDetailReport data = productDetailDataProvider.fetch(yearMonth, userId);
        ReportExporter<ProductCoverageDetailReport> exporter =
                (ReportExporter<ProductCoverageDetailReport>) exporterMap.get(
                        ReportType.PRODUCT_COVERAGE_DETAIL.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    @SuppressWarnings("unchecked")
    public void exportItemStatus(ReportFormat format, OutputStream out,
                                  String yearMonth, String userId) throws IOException {
        ItemStatusReport data = itemStatusDataProvider.fetch(yearMonth, userId);
        ReportExporter<ItemStatusReport> exporter = (ReportExporter<ItemStatusReport>)
                exporterMap.get(ReportType.ITEM_STATUS.name() + ":" + format.name());
        if (exporter == null) throw new IllegalStateException("지원하지 않는 형식: " + format);
        exporter.export(data, out);
    }

    public String buildFileName(ReportType type, ReportFormat format, String yearMonth) {
        return String.format("%s_%s.%s",
                type.getDisplayName(),
                yearMonth.replace("-", ""),
                format.getExtension());
    }
}


// ============================================================================
//  7. CONTROLLER — 엔드포인트 추가
// ============================================================================
package com.ktds.report.controller;

import com.ktds.report.enums.ReportFormat;
import com.ktds.report.enums.ReportType;
import com.ktds.report.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    /** 1번 탭 - 커버리지 현황 */
    @GetMapping("/coverage-status")
    public void downloadCoverageStatus(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.COVERAGE_STATUS, format, yearMonth),
                out -> reportService.exportCoverage(format, out, yearMonth, userId));
    }

    /** 2번 탭 - 상품별 커버리지 상세 */
    @GetMapping("/product-coverage-detail")
    public void downloadProductCoverageDetail(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.PRODUCT_COVERAGE_DETAIL, format, yearMonth),
                out -> reportService.exportProductDetail(format, out, yearMonth, userId));
    }

    /** 3번 탭 - 아이템별 현황 */
    @GetMapping("/item-status")
    public void downloadItemStatus(
            @RequestParam(defaultValue = "EXCEL") ReportFormat format,
            @RequestParam(defaultValue = "2026-01") String yearMonth,
            @RequestParam(required = false) String userId,
            HttpServletResponse response) throws IOException {
        download(response, format,
                reportService.buildFileName(ReportType.ITEM_STATUS, format, yearMonth),
                out -> reportService.exportItemStatus(format, out, yearMonth, userId));
    }

    // 공통 다운로드 처리
    @FunctionalInterface
    private interface ExportAction {
        void apply(java.io.OutputStream out) throws IOException;
    }

    private void download(HttpServletResponse res, ReportFormat format,
                          String fileName, ExportAction action) throws IOException {
        String encoded = URLEncoder.encode(fileName, StandardCharsets.UTF_8)
                .replaceAll("\\+", "%20");
        res.setContentType(format.getContentType());
        res.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + encoded + "\"; filename*=UTF-8''" + encoded);
        action.apply(res.getOutputStream());
        res.flushBuffer();
    }
}


// ============================================================================
//  8. 프론트엔드 (참고)
// ============================================================================
/*
async function downloadReport(tab, format) {
  // tab: 'coverage-status' | 'product-coverage-detail' | 'item-status'
  const yearMonth = document.querySelector('#period').textContent.trim();
  const url = `/api/reports/${tab}?format=${format}`
            + `&yearMonth=${encodeURIComponent(yearMonth)}`;

  const res = await fetch(url);
  if (!res.ok) { alert('다운로드 실패'); return; }

  const cd = res.headers.get('content-disposition') || '';
  const m = cd.match(/filename\*=UTF-8''([^;]+)/);
  const fileName = m ? decodeURIComponent(m[1]) : `report.${format.toLowerCase()}`;

  const blob = await res.blob();
  const blobUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = blobUrl;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(blobUrl);
}

// 3번 탭 버튼 바인딩
document.querySelector('#btnTab3Excel').addEventListener('click',
  () => downloadReport('item-status', 'EXCEL'));
document.querySelector('#btnTab3Html').addEventListener('click',
  () => downloadReport('item-status', 'HTML'));
*/
