package com.kt.ccs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class CcsApplication {
    public static void main(String[] args) {
        SpringApplication.run(CcsApplication.class, args);
    }
}
