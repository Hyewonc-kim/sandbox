package com.kt.ccs.service;

import com.kt.ccs.repository.ItemRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ItemService {

    private final ItemRepository itemRepository;

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<Map<String, Object>> getSummary(String baseMonth) {
        return itemRepository.getSummary(baseMonth);
    }

    public List<Map<String, Object>> getSpecialFeatures(String baseMonth) {
        return itemRepository.getSpecialFeatures(baseMonth);
    }
}
