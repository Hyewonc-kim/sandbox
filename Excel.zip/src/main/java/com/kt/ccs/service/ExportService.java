package com.kt.ccs.service;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ExportService {

    private final DashboardService dashboardService;
    private final CoverageService  coverageService;
    private final CustomerService  customerService;
    private final ProductService   productService;
    private final ItemService      itemService;
    private final MismatchService  mismatchService;
    private final RatCheckService  ratCheckService;

    public ExportService(
            DashboardService dashboardService,
            CoverageService  coverageService,
            CustomerService  customerService,
            ProductService   productService,
            ItemService      itemService,
            MismatchService  mismatchService,
            RatCheckService  ratCheckService) {
        this.dashboardService = dashboardService;
        this.coverageService  = coverageService;
        this.customerService  = customerService;
        this.productService   = productService;
        this.itemService      = itemService;
        this.mismatchService  = mismatchService;
        this.ratCheckService  = ratCheckService;
    }

    // ─── 내부 데이터 모델 ─────────────────────────────────────────────────────

    private record ExportSheet(String name, List<String> headers, List<List<Object>> rows) {}

    private record StyleKit(
            XSSFCellStyle titleBanner,
            XSSFCellStyle colHeader,
            XSSFCellStyle dataText,    // 흰 배경, 좌측
            XSSFCellStyle dataTextOdd, // 연회색, 좌측
            XSSFCellStyle dataNum,     // 흰 배경, 우측, #,##0.## 포맷
            XSSFCellStyle dataNumOdd,  // 연회색, 우측
            XSSFCellStyle dataInt,     // 흰 배경, 우측, #,##0 포맷 (대형 정수)
            XSSFCellStyle dataIntOdd,  // 연회색, 우측, #,##0
            XSSFCellStyle rateBar,     // 흰 배경, Consolas ▓░ 진행바
            XSSFCellStyle rateBarOdd   // 연회색, Consolas ▓░ 진행바
    ) {}

    // ─── 진입점 ───────────────────────────────────────────────────────────────

    public ResponseEntity<byte[]> export(String screen, String baseMonth, String format) {
        String ts       = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String filename = "CCS_" + screen + "_" + baseMonth + "_" + ts;
        if ("html".equalsIgnoreCase(format)) {
            return toHtml(screen, baseMonth, filename);
        }
        List<ExportSheet> sheets = buildSheets(screen, baseMonth);
        return toExcel(sheets, filename);
    }

    // ─── 화면별 시트 구성 ─────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private List<ExportSheet> buildSheets(String screen, String baseMonth) {
        return switch (screen) {

            case "dashboard" -> {
                Map<String, Object> batchStatus = dashboardService.getBatchStatus();
                List<ExportSheet> list = new ArrayList<>();
                list.add(mapToSheet("종합 정합 현황", dashboardService.getSummary(baseMonth)));
                for (String job : new String[]{"SNAPSHOT", "EXTRACTION", "COMPARISON", "REPORT"}) {
                    Object v = batchStatus.get(job);
                    list.add(mapToSheet("배치_" + job,
                            v instanceof Map ? (Map<String, Object>) v : Map.of()));
                }
                yield list;
            }

            case "coverage" -> List.of(
                mapToSheet("상품 커버리지",   coverageService.getProductCoverage(baseMonth)),
                mapToSheet("아이템 커버리지", coverageService.getItemCoverage(baseMonth)),
                mapToSheet("고객 커버리지",   coverageService.getCustomerCoverage(baseMonth))
            );

            case "customer" -> List.of(
                mapToSheet("고객 커버리지", customerService.getSummary(baseMonth))
            );

            case "product" -> {
                List<ExportSheet> list = new ArrayList<>();
                list.add(mapToSheet("상품 유형별 요약", productService.getSummary(baseMonth)));
                for (String type : new String[]{"m-rate", "m-addon", "w-rate", "w-addon"}) {
                    list.add(listToSheet("가입자상위_" + type, productService.getTopSubscribers(baseMonth, type)));
                    list.add(listToSheet("사용없는상품_" + type, productService.getNoUsageList(baseMonth, type)));
                }
                list.add(listToSheet("가입자없는상품", productService.getNoSubscriberList(baseMonth)));
                yield list;
            }

            case "item" -> List.of(
                listToSheet("아이템 요약",     itemService.getSummary(baseMonth)),
                listToSheet("특화 기능 아이템", itemService.getSpecialFeatures(baseMonth))
            );

            case "mismatch" -> List.of(
                mapToSheet("정합률 요약",  mismatchService.getSummary(baseMonth)),
                listToSheet("불일치 상세", mismatchService.getDetail(baseMonth))
            );

            case "rat-check" -> List.of(
                listToSheet("테이블 매핑", ratCheckService.getTableMapping(baseMonth)),
                listToSheet("인덱스 현황", ratCheckService.getIndexStatus(baseMonth)),
                listToSheet("Cycle 정보",  ratCheckService.getCycleInfo(baseMonth)),
                mapToSheet("재과금 현황",  ratCheckService.getRechargeStatus(baseMonth)),
                mapToSheet("처리 현황",    ratCheckService.getProcessingStatus(baseMonth))
            );

            default -> List.of();
        };
    }

    // ─── 데이터 변환 헬퍼 ────────────────────────────────────────────────────

    private ExportSheet mapToSheet(String name, Map<String, Object> data) {
        if (data == null || data.isEmpty()) {
            return new ExportSheet(name, List.of("항목", "값"), List.of());
        }
        List<List<Object>> rows = data.entrySet().stream()
                .map(e -> List.<Object>of(
                        e.getKey(),
                        e.getValue() != null ? e.getValue() : "—"))
                .toList();
        return new ExportSheet(name, List.of("항목", "값"), rows);
    }

    private ExportSheet listToSheet(String name, List<Map<String, Object>> data) {
        if (data == null || data.isEmpty()) {
            return new ExportSheet(name, List.of(), List.of());
        }
        List<String> headers = new ArrayList<>(data.get(0).keySet());
        List<List<Object>> rows = data.stream()
                .map(row -> headers.stream()
                        .<Object>map(h -> row.getOrDefault(h, "—"))
                        .collect(Collectors.toList()))
                .toList();
        return new ExportSheet(name, headers, rows);
    }

    // ─── Excel 생성 ──────────────────────────────────────────────────────────

    private ResponseEntity<byte[]> toExcel(List<ExportSheet> sheets, String filename) {
        try (XSSFWorkbook wb = new XSSFWorkbook()) {

            StyleKit sk = buildStyles(wb);

            for (ExportSheet s : sheets) {
                XSSFSheet sheet = wb.createSheet(sanitizeSheetName(s.name()));

                // 격자선 제거 + 인쇄 설정 (가로, 1페이지 너비)
                sheet.setDisplayGridlines(false);
                sheet.setFitToPage(true);
                sheet.getPrintSetup().setFitWidth((short) 1);
                sheet.getPrintSetup().setFitHeight((short) 0);
                sheet.getPrintSetup().setLandscape(true);

                // 항목/값 2열 시트는 3열(시각화 바 추가)로 확장
                boolean isMapSheet = s.headers().size() == 2
                        && "항목".equals(s.headers().get(0))
                        && "값".equals(s.headers().get(1));

                int colCount = isMapSheet ? 3 : Math.max(1, s.headers().size());
                sheet.setDefaultColumnWidth(16);
                int ri = 0;

                // ── 타이틀 배너 행 ───────────────────────────────────────────
                Row titleRow = sheet.createRow(ri++);
                titleRow.setHeight((short) 520);
                Cell titleCell = titleRow.createCell(0);
                titleCell.setCellValue("  " + s.name());
                titleCell.setCellStyle(sk.titleBanner());
                if (colCount > 1) {
                    sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, colCount - 1));
                }

                // ── 열 헤더 행 ───────────────────────────────────────────────
                if (!s.headers().isEmpty()) {
                    Row headerRow = sheet.createRow(ri++);
                    headerRow.setHeight((short) 400);
                    for (int c = 0; c < s.headers().size(); c++) {
                        Cell cell = headerRow.createCell(c);
                        cell.setCellValue(s.headers().get(c));
                        cell.setCellStyle(sk.colHeader());
                    }
                    if (isMapSheet) {
                        Cell barHdr = headerRow.createCell(2);
                        barHdr.setCellValue("시각화");
                        barHdr.setCellStyle(sk.colHeader());
                    }
                }

                sheet.createFreezePane(0, ri);

                // ── 데이터 행 ────────────────────────────────────────────────
                for (int di = 0; di < s.rows().size(); di++) {
                    List<Object> rowData = s.rows().get(di);
                    Row row = sheet.createRow(ri++);
                    row.setHeight((short) 350);
                    boolean odd = di % 2 == 1;

                    for (int c = 0; c < rowData.size(); c++) {
                        Object val = rowData.get(c);
                        Cell cell = row.createCell(c);
                        if (val instanceof Number n) {
                            double d = n.doubleValue();
                            boolean isWholeNum = d == Math.floor(d) && Math.abs(d) >= 1000;
                            cell.setCellStyle(isWholeNum
                                    ? (odd ? sk.dataIntOdd()  : sk.dataInt())
                                    : (odd ? sk.dataNumOdd()  : sk.dataNum()));
                            cell.setCellValue(d);
                        } else {
                            String str = val != null ? val.toString() : "";
                            boolean looksNumeric = !str.isEmpty()
                                    && str.matches("[\\d,]+\\.?\\d*%?|—");
                            cell.setCellStyle(looksNumeric
                                    ? (odd ? sk.dataNumOdd()  : sk.dataNum())
                                    : (odd ? sk.dataTextOdd() : sk.dataText()));
                            cell.setCellValue(str);
                        }
                    }

                    // 항목/값 시트: rate 키면 ▓░ 진행바 추가
                    if (isMapSheet && rowData.size() == 2) {
                        Object key = rowData.get(0);
                        Object val = rowData.get(1);
                        Cell barCell = row.createCell(2);
                        if (isRateKey(key)) {
                            barCell.setCellValue(progressBar(val));
                            barCell.setCellStyle(odd ? sk.rateBarOdd() : sk.rateBar());
                        } else {
                            barCell.setCellStyle(odd ? sk.dataTextOdd() : sk.dataText());
                        }
                    }
                }

                // ── 열 너비 ──────────────────────────────────────────────────
                if (isMapSheet) {
                    sheet.setColumnWidth(0, 32 * 256);  // 항목 — 넓게
                    sheet.setColumnWidth(1, 18 * 256);  // 값
                    sheet.setColumnWidth(2, 26 * 256);  // 시각화 바
                } else {
                    for (int c = 0; c < colCount; c++) {
                        sheet.autoSizeColumn(c);
                        int w = sheet.getColumnWidth(c);
                        sheet.setColumnWidth(c, Math.min(Math.max(w, 8 * 256), 60 * 256));
                    }
                }
            }

            ByteArrayOutputStream out = new ByteArrayOutputStream();
            wb.write(out);

            HttpHeaders h = new HttpHeaders();
            h.setContentDisposition(ContentDisposition.attachment()
                    .filename(filename + ".xlsx", StandardCharsets.UTF_8).build());
            return ResponseEntity.ok().headers(h)
                    .contentType(MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .body(out.toByteArray());

        } catch (Exception e) {
            throw new RuntimeException("Excel 생성 실패: " + e.getMessage(), e);
        }
    }

    // ─── 스타일 생성 ─────────────────────────────────────────────────────────

    private StyleKit buildStyles(XSSFWorkbook wb) {
        XSSFColor cNavy   = xColor(0x1e, 0x3a, 0x8a);
        XSSFColor cWhite  = xColor(0xff, 0xff, 0xff);
        XSSFColor cOdd    = xColor(0xf8, 0xfa, 0xfc);
        XSSFColor cBorder = xColor(0xe2, 0xe8, 0xf0);
        XSSFColor cText   = xColor(0x33, 0x41, 0x55);
        XSSFColor cGreen  = xColor(0x16, 0xa3, 0x4a);

        XSSFFont fTitle = makeFont(wb, "맑은 고딕", 11, true,  cWhite);
        XSSFFont fHdr   = makeFont(wb, "맑은 고딕",  9, true,  cWhite);
        XSSFFont fData  = makeFont(wb, "맑은 고딕",  9, false, cText);
        XSSFFont fBar   = makeFont(wb, "Consolas",   9, false, cGreen); // ▓░ 바용 고정폭

        DataFormat df = wb.createDataFormat();
        short fmtDec = df.getFormat("#,##0.##"); // 소수 (율 등)
        short fmtInt = df.getFormat("#,##0");    // 정수 (건수 등)

        // 타이틀 배너
        XSSFCellStyle titleBanner = wb.createCellStyle();
        titleBanner.setFillForegroundColor(cNavy);
        titleBanner.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        titleBanner.setAlignment(HorizontalAlignment.LEFT);
        titleBanner.setVerticalAlignment(VerticalAlignment.CENTER);
        titleBanner.setFont(fTitle);

        // 열 헤더 (THIN 유지 — 헤더는 구분선이 보여야 함)
        XSSFCellStyle colHeader = wb.createCellStyle();
        colHeader.setFillForegroundColor(cNavy);
        colHeader.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        colHeader.setAlignment(HorizontalAlignment.CENTER);
        colHeader.setVerticalAlignment(VerticalAlignment.CENTER);
        colHeader.setFont(fHdr);
        applyBorder(colHeader, BorderStyle.THIN, cNavy);

        // 데이터 셀 — HAIR 테두리 (THIN보다 섬세)
        XSSFCellStyle dataText    = dataCellStyle(wb, fData, cWhite, cBorder, HorizontalAlignment.LEFT,  (short)0);
        XSSFCellStyle dataTextOdd = dataCellStyle(wb, fData, cOdd,   cBorder, HorizontalAlignment.LEFT,  (short)0);
        XSSFCellStyle dataNum     = dataCellStyle(wb, fData, cWhite, cBorder, HorizontalAlignment.RIGHT, fmtDec);
        XSSFCellStyle dataNumOdd  = dataCellStyle(wb, fData, cOdd,   cBorder, HorizontalAlignment.RIGHT, fmtDec);
        XSSFCellStyle dataInt     = dataCellStyle(wb, fData, cWhite, cBorder, HorizontalAlignment.RIGHT, fmtInt);
        XSSFCellStyle dataIntOdd  = dataCellStyle(wb, fData, cOdd,   cBorder, HorizontalAlignment.RIGHT, fmtInt);
        XSSFCellStyle rateBar     = dataCellStyle(wb, fBar,  cWhite, cBorder, HorizontalAlignment.LEFT,  (short)0);
        XSSFCellStyle rateBarOdd  = dataCellStyle(wb, fBar,  cOdd,   cBorder, HorizontalAlignment.LEFT,  (short)0);

        return new StyleKit(titleBanner, colHeader,
                dataText, dataTextOdd,
                dataNum,  dataNumOdd,
                dataInt,  dataIntOdd,
                rateBar,  rateBarOdd);
    }

    private XSSFCellStyle dataCellStyle(XSSFWorkbook wb, XSSFFont font,
                                        XSSFColor bg, XSSFColor border,
                                        HorizontalAlignment align, short fmt) {
        XSSFCellStyle cs = wb.createCellStyle();
        cs.setFillForegroundColor(bg);
        cs.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cs.setAlignment(align);
        cs.setVerticalAlignment(VerticalAlignment.CENTER);
        cs.setFont(font);
        applyBorder(cs, BorderStyle.HAIR, border);
        if (fmt != 0) cs.setDataFormat(fmt);
        return cs;
    }

    private XSSFColor xColor(int r, int g, int b) {
        return new XSSFColor(new byte[]{(byte) r, (byte) g, (byte) b}, null);
    }

    private XSSFFont makeFont(XSSFWorkbook wb, String name, int size, boolean bold, XSSFColor color) {
        XSSFFont f = wb.createFont();
        f.setFontName(name);
        f.setFontHeightInPoints((short) size);
        f.setBold(bold);
        f.setColor(color);
        return f;
    }

    private void applyBorder(XSSFCellStyle s, BorderStyle bs, XSSFColor color) {
        s.setBorderTop(bs);    s.setTopBorderColor(color);
        s.setBorderBottom(bs); s.setBottomBorderColor(color);
        s.setBorderLeft(bs);   s.setLeftBorderColor(color);
        s.setBorderRight(bs);  s.setRightBorderColor(color);
    }

    /** rate/율/pct 등 비율 키인지 판별 */
    private boolean isRateKey(Object key) {
        if (!(key instanceof String k)) return false;
        String lower = k.toLowerCase();
        return lower.contains("rate") || lower.contains("율")
            || lower.contains("pct")  || lower.contains("ratio")
            || lower.contains("percent");
    }

    /** 0-100 퍼센트 값을 ▓░ 20칸 바로 변환 (dat 파일의 buildProgressBar 패턴) */
    private String progressBar(Object val) {
        if (!(val instanceof Number n)) return "";
        double d = n.doubleValue();
        if (d < 0 || d > 100) return "";
        int filled = (int) Math.round(d / 5);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 20; i++) sb.append(i < filled ? "▓" : "░");
        return sb.toString();
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── HTML 생성 (화면별 전용 빌더) ─────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    private ResponseEntity<byte[]> toHtml(String screen, String baseMonth, String filename) {
        String printDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일"));
        String label     = screenLabel(screen);

        String body = buildScreenHtml(screen, baseMonth);

        StringBuilder html = new StringBuilder(32768);
        html.append("<!DOCTYPE html>\n<html lang=\"ko\">\n<head>\n");
        html.append("<meta charset=\"UTF-8\">\n");
        html.append("<title>CCS — ").append(esc(label))
            .append(" (").append(esc(baseMonth)).append(")</title>\n");
        html.append(buildCss());
        html.append("</head>\n<body>\n");

        // 페이지 헤더
        html.append("<div class=\"ph\"><h1>CCS 정합 검증 &mdash; ").append(esc(label)).append("</h1>");
        html.append("<p>기준월: ").append(esc(baseMonth))
            .append(" &nbsp;&middot;&nbsp; 출력일: ").append(esc(printDate)).append("</p></div>\n");

        html.append(body);
        html.append("</body>\n</html>");

        byte[] bytes = html.toString().getBytes(StandardCharsets.UTF_8);
        HttpHeaders h = new HttpHeaders();
        h.setContentDisposition(ContentDisposition.attachment()
                .filename(filename + ".html", StandardCharsets.UTF_8).build());
        return ResponseEntity.ok().headers(h)
                .contentType(new MediaType("text", "html", StandardCharsets.UTF_8))
                .body(bytes);
    }

    // ─── 화면 라우터 ────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private String buildScreenHtml(String screen, String baseMonth) {
        return switch (screen) {
            case "dashboard"  -> buildDashboard(baseMonth);
            case "coverage"   -> buildCoverage(baseMonth);
            case "customer"   -> buildCustomer(baseMonth);
            case "product"    -> buildProduct(baseMonth);
            case "item"       -> buildItem(baseMonth);
            case "mismatch"   -> buildMismatch(baseMonth);
            case "rat-check"  -> buildRatCheck(baseMonth);
            default           -> "<p style='color:#94a3b8'>알 수 없는 화면: " + esc(screen) + "</p>";
        };
    }

    // ─── CSS ────────────────────────────────────────────────────────────────

    private String buildCss() {
        return "<style>\n"
            + "*, *::before, *::after { box-sizing: border-box; }\n"
            + "body { font-family: 'Malgun Gothic', -apple-system, BlinkMacSystemFont, sans-serif;"
            + " background: #f1f5f9; padding: 24px; margin: 0; color: #334155; font-size: 13px; }\n"
            // 페이지 헤더
            + ".ph { background: #1e3a8a; color: white; padding: 16px 24px; margin: -24px -24px 20px; }\n"
            + ".ph h1 { margin: 0; font-size: 16px; font-weight: 600; }\n"
            + ".ph p { margin: 4px 0 0; font-size: 12px; opacity: .8; }\n"
            // 카드
            + ".card { background: white; border: 1px solid #e2e8f0; border-radius: 6px;"
            + " padding: 16px; margin-bottom: 16px; overflow: hidden; }\n"
            + ".card-title { font-size: 13px; font-weight: 600; color: #1e293b;"
            + " padding-bottom: 10px; margin: -16px -16px 14px; padding: 12px 16px;"
            + " border-bottom: 1px solid #e2e8f0; }\n"
            // 그리드
            + ".g2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }\n"
            + ".g3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-bottom: 16px; }\n"
            + ".g4 { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 16px; margin-bottom: 16px; }\n"
            // KPI 카드
            + ".kpi { background: white; border: 2px solid rgba(30,58,138,.30); border-radius: 6px;"
            + " padding: 18px 20px; text-align: center; }\n"
            + ".kpi-label { font-size: 11px; color: #64748b; margin-bottom: 6px; }\n"
            + ".kpi-value { font-size: 30px; font-weight: 700; color: #1e3a8a; line-height: 1; }\n"
            + ".kpi-sub { font-size: 11px; color: #94a3b8; margin-top: 4px; }\n"
            // 메트릭 셀 (6분할 그리드용)
            + ".mc-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }\n"
            + ".mc { background: #f8fafc; border-radius: 4px; padding: 10px 12px; }\n"
            + ".mc-plain { background: #f8fafc; border-radius: 4px; padding: 10px 12px; }\n"
            + ".mc-rate  { background: #eff6ff; border-radius: 4px; padding: 10px 12px;"
            + " border-left: 3px solid #1e3a8a; }\n"
            + ".mc-label { font-size: 10px; color: #64748b; margin-bottom: 4px; }\n"
            + ".mc-value { font-size: 18px; font-weight: 700; color: #1e3a8a; }\n"
            + ".mc-value.danger { color: #dc2626; }\n"
            + ".mc-value.success { color: #16a34a; }\n"
            // KV 행
            + ".kv { display: flex; justify-content: space-between; align-items: center;"
            + " padding: 6px 0; border-bottom: 1px solid #f1f5f9; font-size: 12px; }\n"
            + ".kv:last-child { border-bottom: none; }\n"
            + ".kv-key { color: #64748b; }\n"
            + ".kv-val { font-weight: 600; }\n"
            // 진행 바
            + ".pb-wrap { background: #e2e8f0; border-radius: 99px; height: 8px;"
            + " margin: 6px 0 2px; overflow: hidden; }\n"
            + ".pb { height: 100%; border-radius: 99px; background: #1e3a8a;"
            + " transition: width .4s ease; }\n"
            + ".pb.success { background: #16a34a; }\n"
            + ".pb.warning { background: #ea580c; }\n"
            + ".pb.danger  { background: #dc2626; }\n"
            + ".pb-labels { display: flex; justify-content: space-between;"
            + " font-size: 10px; color: #94a3b8; }\n"
            // 배지
            + ".badge { display: inline-block; padding: 2px 8px; border-radius: 99px;"
            + " font-size: 11px; font-weight: 600; }\n"
            + ".badge-done    { background: #dcfce7; color: #16a34a; }\n"
            + ".badge-running { background: #dbeafe; color: #1d4ed8; }\n"
            + ".badge-failed  { background: #fee2e2; color: #dc2626; }\n"
            + ".badge-idle    { background: #f1f5f9; color: #64748b; }\n"
            + ".badge-ok      { background: #dcfce7; color: #16a34a; }\n"
            + ".badge-missing { background: #fee2e2; color: #dc2626; }\n"
            // 배치 카드 (STEP N)
            + ".bc { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px;"
            + " padding: 14px; }\n"
            + ".bc-title { font-size: 12px; font-weight: 700; color: #1e3a8a; margin-bottom: 2px; }\n"
            + ".bc-desc  { font-size: 11px; color: #64748b; margin-bottom: 8px; }\n"
            + ".bc-meta  { font-size: 10px; color: #94a3b8; font-family: monospace; margin-top: 6px; }\n"
            // 테이블
            + "table { width: 100%; border-collapse: collapse; font-size: 12px; }\n"
            + "th { background: #1e3a8a; color: white; text-align: left;"
            + " padding: 8px 12px; white-space: nowrap; font-weight: 600; }\n"
            + "td { padding: 7px 12px; border-bottom: 1px solid #f1f5f9; color: #334155; }\n"
            + "tr:nth-child(odd) td { background: #f8fafc; }\n"
            + "tr:hover td { background: #eff6ff; }\n"
            + "tr:last-child td { border-bottom: none; }\n"
            + ".td-num { text-align: right; }\n"
            + ".td-center { text-align: center; }\n"
            // 단계 카드 (커버리지 4단계)
            + ".step-card { background: white; border: 1px solid #e2e8f0; border-radius: 6px;"
            + " padding: 14px; text-align: center; position: relative; }\n"
            + ".step-num { display: inline-flex; align-items: center; justify-content: center;"
            + " width: 28px; height: 28px; border-radius: 50%; background: #1e3a8a;"
            + " color: white; font-size: 13px; font-weight: 700; margin-bottom: 8px; }\n"
            + ".step-title { font-size: 11px; color: #64748b; margin-bottom: 6px; }\n"
            + ".step-total { font-size: 22px; font-weight: 700; color: #1e3a8a; }\n"
            + ".step-breakdown { font-size: 10px; color: #94a3b8; margin-top: 6px; line-height: 1.6; }\n"
            // 경고 박스 (아이템 미추출)
            + ".danger-box { background: #fff5f5; border: 1px solid #fecaca; border-radius: 6px;"
            + " padding: 12px; }\n"
            + ".danger-box-title { font-size: 12px; font-weight: 600; color: #dc2626;"
            + " margin-bottom: 8px; }\n"
            // Cycle 그리드
            + ".cycle-grid { display: grid; grid-template-columns: repeat(6, 1fr);"
            + " gap: 8px; }\n"
            + ".cycle-cell { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 4px;"
            + " padding: 10px 8px; font-size: 11px; }\n"
            + ".cycle-month { font-weight: 700; color: #1e3a8a; font-size: 13px;"
            + " margin-bottom: 4px; }\n"
            + ".cycle-row { display: flex; justify-content: space-between;"
            + " color: #64748b; margin-top: 3px; }\n"
            + ".lock-on  { color: #dc2626; font-weight: 700; }\n"
            + ".lock-off { color: #16a34a; }\n"
            // 누적 가로 바 차트
            + ".bar-chart { height: 28px; display: flex; border-radius: 4px; overflow: hidden;"
            + " margin: 12px 0; }\n"
            + ".bar-seg { height: 100%; display: flex; align-items: center; justify-content: center;"
            + " font-size: 10px; color: white; font-weight: 600; min-width: 24px; }\n"
            + ".legend { display: flex; flex-wrap: wrap; gap: 8px; font-size: 11px;"
            + " margin-bottom: 8px; }\n"
            + ".legend-dot { display: inline-block; width: 10px; height: 10px;"
            + " border-radius: 2px; margin-right: 3px; vertical-align: middle; }\n"
            + ".empty { padding: 32px; text-align: center; color: #94a3b8; font-size: 12px; }\n"
            + "</style>\n";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── 화면별 HTML 빌더 ─────────────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    // ── 대시보드 ────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private String buildDashboard(String baseMonth) {
        Map<String, Object> sum   = dashboardService.getSummary(baseMonth);
        Map<String, Object> batch = dashboardService.getBatchStatus();

        StringBuilder sb = new StringBuilder(4096);

        // 1) KPI 카드 3개
        sb.append("<div class=\"g3\">");
        sb.append(kpiCard("건수 정합률",   pct(sum, "count_rate"),  "비교 기준 건수 정합"));
        sb.append(kpiCard("금액 정합률",   pct(sum, "amount_rate"), "비교 기준 금액 정합"));
        sb.append(kpiCard("컬링값 정합률", pct(sum, "culling_rate"), "컬링 제외 후 정합률"));
        sb.append("</div>\n");

        // 2) 종합 정합 현황 + 비교 건수 요약 (2분할)
        sb.append("<div class=\"g2\">");

        // 왼쪽 — 종합 정합 현황
        sb.append("<div class=\"card\">");
        sb.append("<div class=\"card-title\">종합 정합 현황</div>");
        sb.append("<div style='text-align:center;padding:16px 0'>");
        sb.append("<div style='font-size:11px;color:#64748b;margin-bottom:4px'>전체 정합률</div>");
        sb.append("<div style='font-size:48px;font-weight:700;color:#1e3a8a;line-height:1'>")
          .append(esc(pct(sum, "total_rate"))).append("</div>");
        sb.append("</div>");
        double totalRate = parseDouble(sum, "total_rate");
        String pbClass = totalRate >= 99.0 ? "success" : totalRate >= 95.0 ? "warning" : "danger";
        sb.append("<div class='pb-wrap'><div class='pb ").append(pbClass).append("' style='width:")
          .append(Math.min(100.0, totalRate)).append("%'></div></div>");
        sb.append("</div>"); // card

        // 오른쪽 — 비교 건수 요약
        sb.append("<div class=\"card\">");
        sb.append("<div class=\"card-title\">비교 건수 요약</div>");
        sb.append(kvRow("전체 건수",   n(sum, "total_count"),    "#334155"));
        sb.append(kvRow("일치 건수",   n(sum, "match_count"),    "#16a34a"));
        sb.append(kvRow("불일치 건수", n(sum, "mismatch_count"), "#dc2626"));
        sb.append("</div>"); // card

        sb.append("</div>\n"); // g2

        // 3) 배치 실행 현황
        sb.append("<div class=\"card\">");
        sb.append("<div class=\"card-title\">배치 실행 현황</div>");
        sb.append("<div class=\"g2\" style='margin-bottom:0'>");

        String[][] steps = {
            {"SNAPSHOT",   "STEP 1 — 스냅샷",   "ASIS/TOBE 데이터 스냅샷 생성"},
            {"EXTRACTION", "STEP 2 — 추출",     "비교 대상 데이터 추출"},
            {"COMPARISON", "STEP 3 — 검증",     "정합성 비교 및 판정"},
            {"REPORT",     "STEP 4 — 리포트",   "결과 리포트 생성"}
        };
        for (String[] step : steps) {
            Object raw = batch.get(step[0]);
            Map<String, Object> j = raw instanceof Map ? (Map<String, Object>) raw : Map.of();
            sb.append(batchCard(step[1], step[2], j));
        }
        sb.append("</div>"); // g2
        sb.append("</div>\n"); // card

        return sb.toString();
    }

    private String kpiCard(String label, String value, String sub) {
        return "<div class='kpi'>"
             + "<div class='kpi-label'>" + esc(label) + "</div>"
             + "<div class='kpi-value'>" + esc(value) + "</div>"
             + "<div class='kpi-sub'>" + esc(sub) + "</div>"
             + "</div>";
    }

    private String batchCard(String title, String desc, Map<String, Object> j) {
        String status    = v(j, "status");
        String badgeCls  = switch (status) {
            case "DONE"    -> "badge-done";
            case "RUNNING" -> "badge-running";
            case "FAILED"  -> "badge-failed";
            default        -> "badge-idle";
        };
        int processed = parseInt(j, "processedCount");
        int total     = parseInt(j, "totalCount");
        double pct    = (total > 0) ? Math.min(100.0, processed * 100.0 / total) : 0.0;
        String pbCls  = "FAILED".equals(status) ? "danger"
                      : "DONE".equals(status)   ? "success" : "";

        StringBuilder sb = new StringBuilder();
        sb.append("<div class='bc'>");
        sb.append("<div class='bc-title'>").append(esc(title)).append("</div>");
        sb.append("<div class='bc-desc'>").append(esc(desc)).append("</div>");
        sb.append("<span class='badge ").append(badgeCls).append("'>").append(esc(status)).append("</span>");
        sb.append("<div class='pb-wrap' style='margin-top:8px'><div class='pb ").append(pbCls)
          .append("' style='width:").append(String.format("%.1f", pct)).append("%'></div></div>");
        sb.append("<div class='pb-labels'><span>").append(n(j, "processedCount")).append(" / ")
          .append(n(j, "totalCount")).append("</span><span>")
          .append(String.format("%.1f", pct)).append("%</span></div>");

        String startedAt   = v(j, "startedAt");
        String completedAt = v(j, "completedAt");
        String jobId       = v(j, "jobId");
        if (!"—".equals(jobId) || !"—".equals(startedAt)) {
            sb.append("<div class='bc-meta'>");
            if (!"—".equals(jobId))       sb.append("ID: ").append(esc(jobId)).append("<br>");
            if (!"—".equals(startedAt))   sb.append("시작: ").append(esc(startedAt)).append("<br>");
            if (!"—".equals(completedAt)) sb.append("완료: ").append(esc(completedAt));
            sb.append("</div>");
        }
        sb.append("</div>"); // bc
        return sb.toString();
    }

    // ── 커버리지 ────────────────────────────────────────────────────────────

    private String buildCoverage(String baseMonth) {
        Map<String, Object> prod = coverageService.getProductCoverage(baseMonth);
        Map<String, Object> item = coverageService.getItemCoverage(baseMonth);
        Map<String, Object> cust = coverageService.getCustomerCoverage(baseMonth);

        StringBuilder sb = new StringBuilder(4096);

        // 상품 커버리지 — 4단계 가로 카드
        sb.append(htmlSection("상품 커버리지", buildProductCovSteps(prod)));

        // 아이템 커버리지 — 2분할
        sb.append(htmlSection("아이템 커버리지", buildItemCovSection(item)));

        // 고객 커버리지 — 3분할
        sb.append(htmlSection("고객 커버리지", buildCustomerCovSection(cust)));

        return sb.toString();
    }

    private String buildProductCovSteps(Map<String, Object> p) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class='g4' style='margin-bottom:0'>");

        // ① 전체 상품
        sb.append("<div class='step-card'>");
        sb.append("<div class='step-num'>&#9312;</div>");
        sb.append("<div class='step-title'>전체 상품</div>");
        sb.append("<div class='step-total'>").append(esc(n(p, "total_products"))).append("</div>");
        sb.append("<div class='step-breakdown'>");
        sb.append("무선요금: ").append(esc(n(p, "mobile_rate_products"))).append("<br>");
        sb.append("유선요금: ").append(esc(n(p, "wireline_rate_products"))).append("<br>");
        sb.append("무선부가: ").append(esc(n(p, "mobile_addon_products"))).append("<br>");
        sb.append("유선부가: ").append(esc(n(p, "wireline_addon_products")));
        sb.append("</div></div>");

        // ② 가입자 보유
        sb.append("<div class='step-card'>");
        sb.append("<div class='step-num'>&#9313;</div>");
        sb.append("<div class='step-title'>가입자 보유</div>");
        sb.append("<div class='step-total'>").append(esc(n(p, "subscribed_products"))).append("</div>");
        sb.append("<div class='step-breakdown'>");
        sb.append("무선요금: ").append(esc(n(p, "mobile_sub_rate_products"))).append("<br>");
        sb.append("유선: ").append(esc(n(p, "wireline_sub_products"))).append("<br>");
        sb.append("무선부가: ").append(esc(n(p, "mobile_sub_addon_products"))).append("<br>");
        sb.append("유선부가: ").append(esc(n(p, "wireline_sub_addon_products")));
        sb.append("</div></div>");

        // ③ 사용내역 발생
        sb.append("<div class='step-card'>");
        sb.append("<div class='step-num'>&#9314;</div>");
        sb.append("<div class='step-title'>사용내역 발생</div>");
        sb.append("<div class='step-total'>").append(esc(n(p, "used_products"))).append("</div>");
        sb.append("<div class='step-breakdown'>");
        sb.append("무선요금: ").append(esc(n(p, "mobile_used_rate_products"))).append("<br>");
        sb.append("유선: ").append(esc(n(p, "wireline_used_products")));
        sb.append("</div></div>");

        // ④ 추출 완료
        sb.append("<div class='step-card'>");
        sb.append("<div class='step-num'>&#9315;</div>");
        sb.append("<div class='step-title'>추출 완료</div>");
        sb.append("<div class='step-total'>").append(esc(n(p, "extracted_products"))).append("</div>");
        sb.append("<div class='step-breakdown'>");
        sb.append("무선요금: ").append(esc(n(p, "mobile_ext_rate_products"))).append("<br>");
        sb.append("유선: ").append(esc(n(p, "wireline_ext_products")));
        sb.append("</div></div>");

        sb.append("</div>"); // g4

        String mktExcl = n(p, "market_excl_count");
        sb.append("<p style='font-size:11px;color:#94a3b8;margin-top:10px'>")
          .append("* 마켓 제외 상품: ").append(esc(mktExcl)).append("건</p>");
        return sb.toString();
    }

    private String buildItemCovSection(Map<String, Object> it) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class='g2' style='margin-bottom:0'>");

        // 왼쪽 — 진행 바 2개
        sb.append("<div>");
        double occurRate = parseDouble(it, "item_occurred_rate");
        double extRate   = parseDouble(it, "item_extracted_rate");

        sb.append("<div style='margin-bottom:16px'>");
        sb.append("<div class='kv-key' style='font-size:12px;color:#64748b;margin-bottom:4px'>");
        sb.append("전체 &rarr; 발생 (").append(esc(pct(it, "item_occurred_rate"))).append(")</div>");
        sb.append("<div class='pb-wrap'><div class='pb' style='width:")
          .append(Math.min(100.0, occurRate)).append("%'></div></div>");
        sb.append("<div class='pb-labels'><span>발생: ").append(esc(n(it, "occurred_items"))).append("</span>")
          .append("<span>전체: ").append(esc(n(it, "total_items"))).append("</span></div>");
        sb.append("</div>");

        sb.append("<div>");
        sb.append("<div class='kv-key' style='font-size:12px;color:#64748b;margin-bottom:4px'>");
        sb.append("발생 &rarr; 추출 (").append(esc(pct(it, "item_extracted_rate"))).append(")</div>");
        sb.append("<div class='pb-wrap'><div class='pb success' style='width:")
          .append(Math.min(100.0, extRate)).append("%'></div></div>");
        sb.append("<div class='pb-labels'><span>추출: ").append(esc(n(it, "extracted_items"))).append("</span>")
          .append("<span>발생: ").append(esc(n(it, "occurred_items"))).append("</span></div>");
        sb.append("</div>");
        sb.append("</div>"); // left col

        // 오른쪽 — 미추출 현황
        sb.append("<div class='danger-box'>");
        sb.append("<div class='danger-box-title'>&#9888; 미추출 현황</div>");
        sb.append(kvRow("미추출 합계",       n(it, "not_occurred_total"),   "#dc2626"));
        sb.append(kvRow("서비스 종료",       n(it, "service_ended_count"),  "#ea580c"));
        sb.append(kvRow("가입자 없는 아이템", n(it, "no_subscriber_item_count"), "#64748b"));
        sb.append(kvRow("사용내역 없는 아이템", n(it, "no_usage_item_count"), "#64748b"));
        sb.append("</div>"); // danger-box

        sb.append("</div>"); // g2
        return sb.toString();
    }

    private String buildCustomerCovSection(Map<String, Object> c) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class='g3' style='margin-bottom:0'>");

        // 직접 커버리지
        sb.append("<div>");
        sb.append("<div style='font-size:12px;font-weight:600;color:#1e3a8a;margin-bottom:8px'>직접 커버리지</div>");
        sb.append(kvRow("총 고객 수",      n(c, "total_customers"),    "#334155"));
        sb.append(kvRow("커버 상품 수",    n(c, "total_products_cov"), "#334155"));
        sb.append(kvRow("무선 고객",       n(c, "mobile_customers"),   "#64748b"));
        sb.append(kvRow("무선 상품 커버",  n(c, "mobile_products_cov"),"#64748b"));
        sb.append(kvRow("유선 고객",       n(c, "wireline_customers"),  "#64748b"));
        sb.append(kvRow("유선 상품 커버",  n(c, "wireline_products_cov"),"#64748b"));
        sb.append(kvRow("부가상품 고객",   n(c, "addon_customers"),     "#64748b"));
        sb.append(kvRow("부가(무선)",      n(c, "addon_mobile_cov"),    "#94a3b8"));
        sb.append(kvRow("부가(유선)",      n(c, "addon_wireline_cov"),  "#94a3b8"));
        sb.append("</div>");

        // 간접 커버리지 - 요금제
        sb.append("<div>");
        sb.append("<div style='font-size:12px;font-weight:600;color:#1e3a8a;margin-bottom:8px'>간접 커버리지 &mdash; 요금제</div>");
        sb.append(kvRow("무선 간접",     n(c, "mobile_indirect_customers"),  "#64748b"));
        sb.append(kvRow("유선 간접",     n(c, "wireline_indirect_customers"), "#64748b"));
        double mRate = parseDouble(c, "mobile_indirect_rate");
        double wRate = parseDouble(c, "wireline_indirect_rate");
        sb.append("<div style='margin-top:10px;font-size:11px;color:#64748b'>무선 간접률</div>");
        sb.append("<div class='pb-wrap'><div class='pb' style='width:")
          .append(Math.min(100.0, mRate)).append("%'></div></div>");
        sb.append("<div class='pb-labels'><span>").append(esc(pct(c, "mobile_indirect_rate"))).append("</span></div>");
        sb.append("<div style='margin-top:6px;font-size:11px;color:#64748b'>유선 간접률</div>");
        sb.append("<div class='pb-wrap'><div class='pb' style='width:")
          .append(Math.min(100.0, wRate)).append("%'></div></div>");
        sb.append("<div class='pb-labels'><span>").append(esc(pct(c, "wireline_indirect_rate"))).append("</span></div>");
        sb.append("</div>");

        // 간접 커버리지 - 부가상품
        sb.append("<div>");
        sb.append("<div style='font-size:12px;font-weight:600;color:#1e3a8a;margin-bottom:8px'>간접 커버리지 &mdash; 부가상품</div>");
        sb.append(kvRow("부가 가입 수",    n(c, "addon_subscriptions"), "#334155"));
        sb.append(kvRow("커버 가입 수",    n(c, "addon_covered"),       "#16a34a"));
        sb.append(kvRow("테스트 제외",     n(c, "addon_test_excl"),     "#ea580c"));
        double addonRate = parseDouble(c, "addon_indirect_rate");
        sb.append("<div style='margin-top:10px;font-size:11px;color:#64748b'>부가 간접률</div>");
        sb.append("<div class='pb-wrap'><div class='pb success' style='width:")
          .append(Math.min(100.0, addonRate)).append("%'></div></div>");
        sb.append("<div class='pb-labels'><span>").append(esc(pct(c, "addon_indirect_rate"))).append("</span></div>");
        sb.append("</div>");

        sb.append("</div>"); // g3
        return sb.toString();
    }

    // ── 고객 커버리지 ───────────────────────────────────────────────────────

    private String buildCustomer(String baseMonth) {
        Map<String, Object> c = customerService.getSummary(baseMonth);
        StringBuilder sb = new StringBuilder(2048);

        // 직접 커버리지 카드
        sb.append(htmlSection("직접 커버리지", buildCustomerDirectKv(c)));

        // 간접 커버리지 카드
        sb.append(htmlSection("간접 커버리지", buildCustomerIndirectKv(c)));

        return sb.toString();
    }

    private String buildCustomerDirectKv(Map<String, Object> c) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class='g3' style='margin-bottom:0'>");

        sb.append("<div>");
        sb.append("<div style='font-size:11px;font-weight:600;color:#64748b;margin-bottom:6px'>전체</div>");
        sb.append(kvRow("고객 수",   n(c, "total_customers"),    "#334155"));
        sb.append(kvRow("상품 커버", n(c, "total_products_cov"), "#1e3a8a"));
        sb.append("</div>");

        sb.append("<div>");
        sb.append("<div style='font-size:11px;font-weight:600;color:#64748b;margin-bottom:6px'>무선</div>");
        sb.append(kvRow("고객 수",   n(c, "mobile_customers"),    "#334155"));
        sb.append(kvRow("상품 커버", n(c, "mobile_products_cov"), "#1e3a8a"));
        sb.append("</div>");

        sb.append("<div>");
        sb.append("<div style='font-size:11px;font-weight:600;color:#64748b;margin-bottom:6px'>유선</div>");
        sb.append(kvRow("고객 수",   n(c, "wireline_customers"),    "#334155"));
        sb.append(kvRow("상품 커버", n(c, "wireline_products_cov"), "#1e3a8a"));
        sb.append("</div>");

        sb.append("</div>"); // g3

        sb.append("<div style='margin-top:12px'>");
        sb.append("<div style='font-size:11px;font-weight:600;color:#64748b;margin-bottom:6px'>부가상품</div>");
        sb.append("<div class='g3' style='margin-bottom:0'>");
        sb.append("<div>").append(kvRow("부가 고객", n(c, "addon_customers"), "#334155")).append("</div>");
        sb.append("<div>").append(kvRow("무선 커버", n(c, "addon_mobile_cov"), "#64748b")).append("</div>");
        sb.append("<div>").append(kvRow("유선 커버", n(c, "addon_wireline_cov"), "#64748b")).append("</div>");
        sb.append("</div></div>");
        return sb.toString();
    }

    private String buildCustomerIndirectKv(Map<String, Object> c) {
        StringBuilder sb = new StringBuilder();
        sb.append("<div class='g2' style='margin-bottom:0'>");

        // 요금제 간접
        sb.append("<div>");
        sb.append("<div style='font-size:11px;font-weight:600;color:#64748b;margin-bottom:6px'>요금제</div>");
        sb.append(kvRow("무선 간접 고객",  n(c, "mobile_indirect_customers"),   "#334155"));
        sb.append(kvRow("무선 간접률",     pct(c, "mobile_indirect_rate"),      "#1e3a8a"));
        sb.append(kvRow("유선 간접 고객",  n(c, "wireline_indirect_customers"), "#334155"));
        sb.append(kvRow("유선 간접률",     pct(c, "wireline_indirect_rate"),    "#1e3a8a"));
        sb.append("</div>");

        // 부가상품 간접
        sb.append("<div>");
        sb.append("<div style='font-size:11px;font-weight:600;color:#64748b;margin-bottom:6px'>부가상품</div>");
        sb.append(kvRow("부가 가입 수",    n(c, "addon_subscriptions"), "#334155"));
        sb.append(kvRow("커버 가입 수",    n(c, "addon_covered"),       "#16a34a"));
        sb.append(kvRow("테스트 제외",     n(c, "addon_test_excl"),     "#ea580c"));
        sb.append(kvRow("부가 간접률",     pct(c, "addon_indirect_rate"), "#1e3a8a"));
        sb.append("</div>");

        sb.append("</div>"); // g2
        return sb.toString();
    }

    // ── 상품별 현황 ─────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private String buildProduct(String baseMonth) {
        Map<String, Object>        sumMap    = productService.getSummary(baseMonth);
        List<Map<String, Object>>  topAll    = new ArrayList<>();
        List<Map<String, Object>>  noUsageAll= new ArrayList<>();
        List<Map<String, Object>>  noSubList = productService.getNoSubscriberList(baseMonth);

        for (String type : new String[]{"m-rate", "m-addon", "w-rate", "w-addon"}) {
            List<Map<String, Object>> top = productService.getTopSubscribers(baseMonth, type);
            List<Map<String, Object>> nou = productService.getNoUsageList(baseMonth, type);
            if (top != null)  topAll.addAll(top);
            if (nou != null)  noUsageAll.addAll(nou);
        }

        StringBuilder sb = new StringBuilder(8192);

        // 1) 상품 유형별 요약 표
        sb.append(htmlSection("상품 유형별 요약", buildProductSummaryTable(sumMap)));

        // 2) 가입자 상위 상품
        sb.append(htmlSection("가입자 상위 상품",
            htmlTable(
                List.of("상품코드", "상품명", "가입자수", "가입자율", "발생아이템", "추출아이템", "정합률", "추출고객", "유형"),
                topAll.stream().map(r -> List.<Object>of(
                    v(r, "product_code"), v(r, "product_name"),
                    n(r, "subscriber_count"), pct(r, "subscriber_rate"),
                    n(r, "occurred_items"),   n(r, "extracted_items"),
                    pct(r, "match_rate"),     n(r, "extracted_customers"),
                    v(r, "product_type")
                )).collect(Collectors.toList())
            )
        ));

        // 3) 사용내역 없는 상품
        sb.append(htmlSection("사용내역 없는 상품",
            htmlTable(
                List.of("상품코드", "상품명", "가입자수", "가입자율", "발생아이템", "사용건수", "최근사용일", "상태", "유형"),
                noUsageAll.stream().map(r -> List.<Object>of(
                    v(r, "product_code"), v(r, "product_name"),
                    n(r, "subscriber_count"), pct(r, "subscriber_rate"),
                    n(r, "occurred_items"),   n(r, "usage_count"),
                    v(r, "last_used_date"),   v(r, "status"),
                    v(r, "product_type")
                )).collect(Collectors.toList())
            )
        ));

        // 4) 가입자 없는 상품
        sb.append(htmlSection("가입자 없는 상품",
            htmlTable(
                List.of("상품코드", "상품명", "유형", "분류", "등록일"),
                noSubList == null ? List.of() : noSubList.stream().map(r -> List.<Object>of(
                    v(r, "product_code"), v(r, "product_name"),
                    v(r, "product_type"), v(r, "classification"),
                    v(r, "registered_date")
                )).collect(Collectors.toList())
            )
        ));

        return sb.toString();
    }

    private String buildProductSummaryTable(Map<String, Object> m) {
        String[][] rows = {
            {"전체 상품 수",       "mobile_rate_total",    "wireline_rate_total",    "mobile_addon_total",    "wireline_addon_total"},
            {"정합 대상 상품 수",  "mobile_rate_target",   "wireline_rate_target",   "mobile_addon_target",   "wireline_addon_target"},
            {"가입자 없는 상품 수","no_subscriber_mobile_rate","no_subscriber_wireline_rate","no_subscriber_mobile_addon","no_subscriber_wireline_addon"},
            {"사용내역 없는 상품 수","no_usage_mobile_rate","no_usage_wireline_rate", "no_usage_mobile_addon", "no_usage_wireline_addon"},
        };

        StringBuilder sb = new StringBuilder();
        sb.append("<table><thead><tr>");
        sb.append("<th>구분</th><th class='td-num'>무선요금제</th><th class='td-num'>유선요금제</th>")
          .append("<th class='td-num'>무선부가</th><th class='td-num'>유선부가</th>");
        sb.append("</tr></thead><tbody>");
        for (String[] row : rows) {
            sb.append("<tr><td>").append(esc(row[0])).append("</td>");
            for (int i = 1; i <= 4; i++) {
                sb.append("<td class='td-num'>").append(esc(n(m, row[i]))).append("</td>");
            }
            sb.append("</tr>");
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    // ── 아이템별 현황 ───────────────────────────────────────────────────────

    private String buildItem(String baseMonth) {
        List<Map<String, Object>> summary  = itemService.getSummary(baseMonth);
        List<Map<String, Object>> special  = itemService.getSpecialFeatures(baseMonth);

        StringBuilder sb = new StringBuilder(4096);

        sb.append(htmlSection("아이템 요약",
            htmlTable(
                List.of("아이템유형", "아이템분류", "전체건수", "발생건수", "발생률", "가입자없는", "사용없는", "만료", "PIT"),
                summary == null ? List.of() : summary.stream().map(r -> List.<Object>of(
                    v(r, "item_type"), v(r, "item_category"),
                    n(r, "total_count"), n(r, "occurred_count"), pct(r, "occur_rate"),
                    n(r, "no_subscriber_count"), n(r, "no_usage_count"),
                    n(r, "expired_count"),        n(r, "pit_count")
                )).collect(Collectors.toList())
            )
        ));

        sb.append(htmlSection("특화 기능 아이템",
            htmlTable(
                List.of("요금유형", "아이템분류", "기능설명", "아이템수", "상품수", "샘플상품", "검증상태"),
                special == null ? List.of() : special.stream().map(r -> List.<Object>of(
                    v(r, "rate_type"), v(r, "item_category"), v(r, "feature_desc"),
                    n(r, "item_count"), n(r, "product_count"), v(r, "sample_product"),
                    v(r, "verify_status")
                )).collect(Collectors.toList())
            )
        ));

        return sb.toString();
    }

    // ── 정합결과 상세 ────────────────────────────────────────────────────────

    private String buildMismatch(String baseMonth) {
        Map<String, Object>        sumMap = mismatchService.getSummary(baseMonth);
        List<Map<String, Object>>  detail = mismatchService.getDetail(baseMonth);

        StringBuilder sb = new StringBuilder(4096);

        // 1) 정합률 요약 — mc-grid 6개
        String summaryContent = "<div class='mc-grid'>"
            + mcCell("전체 건수",   n(sumMap, "total_count"),       "mc-plain", false)
            + mcCell("불일치 건수", n(sumMap, "mismatch_count"),    "mc-plain", true)
            + mcCell("건수 정합률", pct(sumMap, "count_match_rate"),"mc-rate",  false)
            + mcCell("전체 금액",   n(sumMap, "total_amount"),      "mc-plain", false)
            + mcCell("불일치 금액", n(sumMap, "mismatch_amount"),   "mc-plain", true)
            + mcCell("금액 정합률", pct(sumMap, "amount_match_rate"),"mc-rate", false)
            + "</div>";
        sb.append(htmlSection("정합률 요약", summaryContent));

        // 2) 불일치 상세 테이블
        sb.append(htmlSection("불일치 상세",
            htmlTable(
                List.of("아이템유형", "아이템분류", "불일치유형", "불일치원인", "불일치건수"),
                detail == null ? List.of() : detail.stream().map(r -> List.<Object>of(
                    v(r, "item_type"), v(r, "item_category"),
                    v(r, "mismatch_type"), v(r, "mismatch_reason"),
                    n(r, "mismatch_count")
                )).collect(Collectors.toList())
            )
        ));

        return sb.toString();
    }

    private String mcCell(String label, String value, String cls, boolean danger) {
        String colorCls = danger ? " danger" : "";
        return "<div class='" + cls + "'>"
             + "<div class='mc-label'>" + esc(label) + "</div>"
             + "<div class='mc-value" + colorCls + "'>" + esc(value) + "</div>"
             + "</div>";
    }

    // ── RAT 사전 체크 ────────────────────────────────────────────────────────

    private String buildRatCheck(String baseMonth) {
        List<Map<String, Object>> tables   = ratCheckService.getTableMapping(baseMonth);
        List<Map<String, Object>> indexes  = ratCheckService.getIndexStatus(baseMonth);
        List<Map<String, Object>> cycles   = ratCheckService.getCycleInfo(baseMonth);
        Map<String, Object>        recharge = ratCheckService.getRechargeStatus(baseMonth);
        Map<String, Object>        proc     = ratCheckService.getProcessingStatus(baseMonth);

        StringBuilder sb = new StringBuilder(8192);

        // 1) 테이블 매핑
        sb.append(htmlSection("검증 대상 테이블",
            htmlTable(
                List.of("스키마유형", "테이블명", "테이블별칭", "정렬순서"),
                tables == null ? List.of() : tables.stream().map(r -> List.<Object>of(
                    v(r, "schema_type"), v(r, "table_name"),
                    v(r, "table_alias"), n(r, "sort_order")
                )).collect(Collectors.toList())
            )
        ));

        // 2) 인덱스 현황 (status 배지 포함)
        sb.append(htmlSection("인덱스 현황", buildIndexTable(indexes)));

        // 3) Cycle 정보 (6열 그리드)
        sb.append(htmlSection("Cycle 정보", buildCycleGrid(cycles)));

        // 4) 재과금 현황 + 처리 현황
        sb.append("<div class='g2'>");
        sb.append("<div class='card'><div class='card-title'>재과금 현황</div>");
        sb.append(buildRechargeKv(recharge));
        sb.append("</div>");
        sb.append("<div class='card'><div class='card-title'>처리 현황</div>");
        sb.append(buildProcessingSection(proc));
        sb.append("</div>");
        sb.append("</div>\n");

        return sb.toString();
    }

    private String buildIndexTable(List<Map<String, Object>> indexes) {
        if (indexes == null || indexes.isEmpty()) return "<div class='empty'>데이터가 없습니다.</div>";
        StringBuilder sb = new StringBuilder();
        sb.append("<table><thead><tr>");
        sb.append("<th>오너</th><th>인덱스명</th><th>테이블명</th><th>인덱스유형</th>"
                + "<th class='td-center'>상태</th><th>컬럼</th>");
        sb.append("</tr></thead><tbody>");
        for (Map<String, Object> r : indexes) {
            String status = v(r, "status");
            String badgeCls = "VALID".equalsIgnoreCase(status) || "존재".equals(status)
                            ? "badge-ok" : "badge-missing";
            String badgeLbl = "VALID".equalsIgnoreCase(status) ? "존재" : status;
            sb.append("<tr>");
            sb.append("<td>").append(esc(v(r, "owner"))).append("</td>");
            sb.append("<td>").append(esc(v(r, "index_name"))).append("</td>");
            sb.append("<td>").append(esc(v(r, "table_name"))).append("</td>");
            sb.append("<td>").append(esc(v(r, "index_type"))).append("</td>");
            sb.append("<td class='td-center'><span class='badge ").append(badgeCls).append("'>")
              .append(esc(badgeLbl)).append("</span></td>");
            sb.append("<td>").append(esc(v(r, "columns"))).append("</td>");
            sb.append("</tr>");
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    private String buildCycleGrid(List<Map<String, Object>> cycles) {
        if (cycles == null || cycles.isEmpty()) return "<div class='empty'>데이터가 없습니다.</div>";
        StringBuilder sb = new StringBuilder();
        sb.append("<div class='cycle-grid'>");
        for (Map<String, Object> c : cycles) {
            String wlLock = v(c, "wireline_lock_yn");
            String wsLock = v(c, "wireless_lock_yn");
            boolean wlOn = "Y".equalsIgnoreCase(wlLock);
            boolean wsOn = "Y".equalsIgnoreCase(wsLock);
            sb.append("<div class='cycle-cell'>");
            sb.append("<div class='cycle-month'>")
              .append(esc(v(c, "cycle_year"))).append("-").append(esc(v(c, "cycle_month")))
              .append("</div>");
            sb.append("<div class='cycle-row'><span style='color:#64748b'>유선</span>");
            sb.append("<span class='").append(wlOn ? "lock-on" : "lock-off").append("'>")
              .append(wlOn ? "&#128274;" : "&#128275;").append("</span></div>");
            sb.append("<div class='cycle-row'><span>신규</span><span>")
              .append(esc(n(c, "wireline_new_count"))).append("</span></div>");
            sb.append("<div class='cycle-row'><span>갱신</span><span>")
              .append(esc(n(c, "wireline_upd_count"))).append("</span></div>");
            sb.append("<div class='cycle-row' style='margin-top:4px'><span style='color:#64748b'>무선</span>");
            sb.append("<span class='").append(wsOn ? "lock-on" : "lock-off").append("'>")
              .append(wsOn ? "&#128274;" : "&#128275;").append("</span></div>");
            sb.append("<div class='cycle-row'><span>신규</span><span>")
              .append(esc(n(c, "wireless_new_count"))).append("</span></div>");
            sb.append("<div class='cycle-row'><span>갱신</span><span>")
              .append(esc(n(c, "wireless_upd_count"))).append("</span></div>");
            sb.append("</div>"); // cycle-cell
        }
        sb.append("</div>"); // cycle-grid
        return sb.toString();
    }

    private String buildRechargeKv(Map<String, Object> r) {
        StringBuilder sb = new StringBuilder();
        String[][] rows = {
            {"&#128101; 고객",   "customer_count",  "registered_time",   "#334155"},
            {"R 등록",           "registered_count","registered_time",    "#1e3a8a"},
            {"P 대기",           "pending_count",   "pending_time",       "#ea580c"},
            {"O 처리중",         "open_count",      "open_time",          "#0891b2"},
            {"D 완료",           "done_count",      "done_time",          "#16a34a"},
            {"Q 고객정보",       "queue_count",     "queue_time",         "#64748b"},
            {"A 에러",           "error_count",     "error_time",         "#dc2626"},
        };
        for (String[] row : rows) {
            String cnt  = n(r, row[1]);
            String time = v(r, row[2]);
            String timeStr = "—".equals(time) ? "" : (" <span style='font-size:10px;color:#94a3b8'>" + esc(time) + "</span>");
            sb.append("<div class='kv'>");
            sb.append("<span class='kv-key'>").append(row[0]).append("</span>");
            sb.append("<span class='kv-val' style='color:").append(row[3]).append("'>")
              .append(esc(cnt)).append(timeStr).append("</span>");
            sb.append("</div>");
        }
        return sb.toString();
    }

    private String buildProcessingSection(Map<String, Object> p) {
        long done    = parseLong(p, "done_count");
        long open    = parseLong(p, "open_count");
        long pending = parseLong(p, "pending_count");
        long queue   = parseLong(p, "queue_count");
        long error   = parseLong(p, "error_count");
        long total   = parseLong(p, "total_count");
        if (total == 0) total = done + open + pending + queue + error;
        if (total == 0) total = 1; // 0으로 나누기 방지

        double doneP    = done    * 100.0 / total;
        double openP    = open    * 100.0 / total;
        double pendingP = pending * 100.0 / total;
        double queueP   = queue   * 100.0 / total;
        double errorP   = error   * 100.0 / total;

        StringBuilder sb = new StringBuilder();

        // 누적 가로 바
        sb.append("<div class='bar-chart'>");
        sb.append(barSeg(doneP,    "#16a34a", "완료"));
        sb.append(barSeg(openP,    "#0891b2", "처리중"));
        sb.append(barSeg(pendingP, "#ea580c", "대기"));
        sb.append(barSeg(queueP,   "#64748b", "큐"));
        sb.append(barSeg(errorP,   "#dc2626", "에러"));
        sb.append("</div>");

        // 범례
        sb.append("<div class='legend'>");
        sb.append(legendItem("#16a34a", "완료("    + done    + ")"));
        sb.append(legendItem("#0891b2", "처리중("  + open    + ")"));
        sb.append(legendItem("#ea580c", "대기("    + pending + ")"));
        sb.append(legendItem("#64748b", "큐("      + queue   + ")"));
        sb.append(legendItem("#dc2626", "에러("    + error   + ")"));
        sb.append("</div>");

        // 요약 메트릭 3개
        long totalRec  = parseLong(p, "total_record_count");
        long custCnt   = parseLong(p, "customer_count");
        long rejectCnt = parseLong(p, "reject_count");
        double complRate = (parseLong(p, "total_count") > 0)
                         ? done * 100.0 / parseLong(p, "total_count") : doneP;
        double procRate  = (totalRec > 0) ? parseLong(p, "process_count") * 100.0 / totalRec : 0.0;

        sb.append("<div class='mc-grid' style='margin-top:10px'>");
        sb.append(mcCell("처리완료율",  String.format("%.1f%%", complRate), "mc-rate",  false));
        sb.append(mcCell("고객 수",     String.valueOf(custCnt),            "mc-plain", false));
        sb.append(mcCell("반려 건수",   String.valueOf(rejectCnt),          "mc-plain", rejectCnt > 0));
        sb.append("</div>");

        return sb.toString();
    }

    private String barSeg(double pct, String color, String label) {
        if (pct < 0.5) return "";
        return "<div class='bar-seg' style='width:" + String.format("%.1f", pct)
             + "%;background:" + color + "'>" + esc(label) + "</div>";
    }

    private String legendItem(String color, String label) {
        return "<span><span class='legend-dot' style='background:" + color + "'></span>"
             + esc(label) + "</span>";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── HTML 공통 헬퍼 ───────────────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    /** Map에서 문자열 값 반환. null이면 "—" */
    private String v(Map<String, Object> m, String key) {
        if (m == null) return "—";
        Object val = m.get(key);
        return (val != null) ? val.toString() : "—";
    }

    /** Map에서 숫자 값을 천단위 쉼표 형식으로 반환 */
    private String n(Map<String, Object> m, String key) {
        if (m == null) return "—";
        Object val = m.get(key);
        if (val == null) return "—";
        try {
            long lv = Long.parseLong(val.toString().replaceAll("[,\\s]", ""));
            return String.format("%,d", lv);
        } catch (NumberFormatException e1) {
            try {
                double dv = Double.parseDouble(val.toString().replaceAll("[,\\s]", ""));
                return String.format("%,.2f", dv);
            } catch (NumberFormatException e2) {
                return val.toString();
            }
        }
    }

    /** Map에서 퍼센트 값 반환 (예: "99.9%") */
    private String pct(Map<String, Object> m, String key) {
        if (m == null) return "—";
        Object val = m.get(key);
        if (val == null) return "—";
        String s = val.toString().replaceAll("[,\\s]", "");
        if (s.endsWith("%")) return s;
        try {
            double d = Double.parseDouble(s);
            return String.format("%.1f%%", d);
        } catch (NumberFormatException e) {
            return val.toString();
        }
    }

    /** double 값 파싱 (실패 시 0.0) */
    private double parseDouble(Map<String, Object> m, String key) {
        if (m == null) return 0.0;
        Object val = m.get(key);
        if (val == null) return 0.0;
        try {
            return Double.parseDouble(val.toString().replaceAll("[,%\\s]", ""));
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    /** int 값 파싱 (실패 시 0) */
    private int parseInt(Map<String, Object> m, String key) {
        if (m == null) return 0;
        Object val = m.get(key);
        if (val == null) return 0;
        try {
            return Integer.parseInt(val.toString().replaceAll("[,\\s]", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** long 값 파싱 (실패 시 0) */
    private long parseLong(Map<String, Object> m, String key) {
        if (m == null) return 0L;
        Object val = m.get(key);
        if (val == null) return 0L;
        try {
            return Long.parseLong(val.toString().replaceAll("[,\\s]", ""));
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    /** 범용 스타일 테이블 생성 */
    private String htmlTable(List<String> headers, List<List<Object>> rows) {
        if (rows == null || rows.isEmpty()) {
            return "<div class='empty'>데이터가 없습니다.</div>";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("<table><thead><tr>");
        for (String h : headers) {
            sb.append("<th>").append(esc(h)).append("</th>");
        }
        sb.append("</tr></thead><tbody>");
        for (List<Object> row : rows) {
            sb.append("<tr>");
            for (Object cell : row) {
                String s = cell != null ? cell.toString() : "—";
                sb.append("<td>").append(esc(s)).append("</td>");
            }
            sb.append("</tr>");
        }
        sb.append("</tbody></table>");
        return sb.toString();
    }

    /** 카드 래퍼 (card-title + content) */
    private String htmlSection(String title, String content) {
        return "<div class='card'>"
             + "<div class='card-title'>" + esc(title) + "</div>"
             + content
             + "</div>\n";
    }

    /** 키-값 행 div */
    private String kvRow(String key, String val, String color) {
        return "<div class='kv'>"
             + "<span class='kv-key'>" + esc(key) + "</span>"
             + "<span class='kv-val' style='color:" + color + "'>" + esc(val) + "</span>"
             + "</div>";
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // ─── 유틸 ─────────────────────────────────────────────────────────────────
    // ═══════════════════════════════════════════════════════════════════════════

    private String sanitizeSheetName(String name) {
        String safe = name.replaceAll("[/\\\\?*\\[\\]:]", "_");
        return safe.length() > 31 ? safe.substring(0, 31) : safe;
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private String screenLabel(String screen) {
        return switch (screen) {
            case "dashboard" -> "대시보드";
            case "coverage"  -> "커버리지 현황";
            case "customer"  -> "고객 커버리지";
            case "product"   -> "상품별 현황";
            case "item"      -> "아이템별 현황";
            case "mismatch"  -> "정합결과 상세";
            case "rat-check" -> "RAT 사전 체크";
            default          -> screen;
        };
    }
}
