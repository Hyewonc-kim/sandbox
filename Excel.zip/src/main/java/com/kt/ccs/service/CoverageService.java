package com.kt.ccs.service;

import com.kt.ccs.repository.CoverageRepository;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CoverageService {

    private final CoverageRepository coverageRepository;

    public CoverageService(CoverageRepository coverageRepository) {
        this.coverageRepository = coverageRepository;
    }

    public Map<String, Object> getProductCoverage(String baseMonth) {
        return coverageRepository.getProductCoverage(baseMonth);
    }

    public Map<String, Object> getItemCoverage(String baseMonth) {
        return coverageRepository.getItemCoverage(baseMonth);
    }

    public Map<String, Object> getCustomerCoverage(String baseMonth) {
        return coverageRepository.getCustomerCoverage(baseMonth);
    }
}
