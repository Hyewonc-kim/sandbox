package com.kt.ccs.service;

import com.kt.ccs.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Map<String, Object> getSummary(String baseMonth) {
        return productRepository.getSummary(baseMonth);
    }

    public List<Map<String, Object>> getTopSubscribers(String baseMonth, String productType) {
        return productRepository.getTopSubscribers(baseMonth, productType);
    }

    public List<Map<String, Object>> getNoUsageList(String baseMonth, String productType) {
        return productRepository.getNoUsageList(baseMonth, productType);
    }

    public List<Map<String, Object>> getNoSubscriberList(String baseMonth) {
        return productRepository.getNoSubscriberList(baseMonth);
    }
}
