package com.kt.ccs.service;

import com.kt.ccs.common.QueryLoader;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class QueryService {

    private final QueryLoader queryLoader;

    public QueryService(QueryLoader queryLoader) {
        this.queryLoader = queryLoader;
    }

    public Map<String, Object> getAllQueries(String screen) {
        return queryLoader.getAllQueries(screen);
    }

    public String getQuery(String screen, String key) {
        return queryLoader.getQuery(screen, key);
    }

    public void saveQuery(String screen, String key, String sql) {
        queryLoader.saveQuery(screen, key, sql);
    }
}
