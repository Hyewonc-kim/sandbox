package com.kt.ccs.service;

import com.kt.ccs.repository.RatCheckRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class RatCheckService {

    private final RatCheckRepository ratCheckRepository;

    public RatCheckService(RatCheckRepository ratCheckRepository) {
        this.ratCheckRepository = ratCheckRepository;
    }

    public List<Map<String, Object>> getTableMapping(String baseMonth) {
        return ratCheckRepository.getTableMapping(baseMonth);
    }

    public List<Map<String, Object>> getIndexStatus(String baseMonth) {
        return ratCheckRepository.getIndexStatus(baseMonth);
    }

    public List<Map<String, Object>> getCycleInfo(String baseMonth) {
        return ratCheckRepository.getCycleInfo(baseMonth);
    }

    public Map<String, Object> getRechargeStatus(String baseMonth) {
        return ratCheckRepository.getRechargeStatus(baseMonth);
    }

    public Map<String, Object> getProcessingStatus(String baseMonth) {
        return ratCheckRepository.getProcessingStatus(baseMonth);
    }

    public int insertRecharge(String baseMonth, String customerId) {
        return ratCheckRepository.insertRecharge(baseMonth, customerId);
    }

    public int insertUpdateHandler(String baseMonth, String requestId, String beforeStatus) {
        return ratCheckRepository.insertUpdateHandler(baseMonth, requestId, beforeStatus);
    }
}
