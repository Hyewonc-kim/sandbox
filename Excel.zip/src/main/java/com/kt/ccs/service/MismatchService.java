package com.kt.ccs.service;

import com.kt.ccs.repository.MismatchRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class MismatchService {

    private final MismatchRepository mismatchRepository;

    public MismatchService(MismatchRepository mismatchRepository) {
        this.mismatchRepository = mismatchRepository;
    }

    public Map<String, Object> getSummary(String baseMonth) {
        return mismatchRepository.getSummary(baseMonth);
    }

    public List<Map<String, Object>> getDetail(String baseMonth) {
        return mismatchRepository.getDetail(baseMonth);
    }
}
