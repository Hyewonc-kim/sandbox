package com.kt.ccs.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kt.ccs.repository.DashboardRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class DashboardService {

    private final DashboardRepository dashboardRepository;
    private final ObjectMapper objectMapper;

    @Value("${ccs.batch-status-path}")
    private String batchStatusPath;

    @Value("${ccs.batch-jar}")
    private String batchJarPath;

    private static final Map<Integer, String> STEP_TO_JOB_TYPE = Map.of(
            1, "SNAPSHOT",
            2, "EXTRACTION",
            3, "COMPARISON",
            4, "REPORT"
    );

    public DashboardService(DashboardRepository dashboardRepository, ObjectMapper objectMapper) {
        this.dashboardRepository = dashboardRepository;
        this.objectMapper = objectMapper;
    }

    public Map<String, Object> getSummary(String baseMonth) {
        return dashboardRepository.getSummary(baseMonth);
    }

    public Map<String, Object> getBatchStatus() {
        Map<String, Object> result = new LinkedHashMap<>();
        for (String jobType : new String[]{"SNAPSHOT", "EXTRACTION", "COMPARISON", "REPORT"}) {
            result.put(jobType, readBatchStatusFile(jobType));
        }
        return result;
    }

    @Async("batchExecutor")
    public void executeStepAsync(int step, String baseMonth) {
        String jobType = STEP_TO_JOB_TYPE.get(step);
        if (jobType == null) return;

        String jobId = UUID.randomUUID().toString();
        writeBatchStatus(jobType, jobId, "RUNNING", 0, 0, LocalDateTime.now(), null, null);
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    "java", "-jar",
                    Paths.get(batchJarPath).toAbsolutePath().toString(),
                    "--step=" + step,
                    "--baseMonth=" + baseMonth
            );
            pb.redirectErrorStream(true);
            Process process = pb.start();
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                writeBatchStatus(jobType, jobId, "DONE", 1, 1, null, LocalDateTime.now(), null);
            } else {
                writeBatchStatus(jobType, jobId, "FAILED", 0, 0, null, LocalDateTime.now(),
                        "배치 종료 코드: " + exitCode);
            }
        } catch (Exception e) {
            writeBatchStatus(jobType, jobId, "FAILED", 0, 0, null, LocalDateTime.now(), e.getMessage());
        }
    }

    private Map<String, Object> readBatchStatusFile(String jobType) {
        File file = Paths.get(batchStatusPath, jobType + ".json").toAbsolutePath().toFile();
        if (!file.exists()) {
            return idleStatus(jobType);
        }
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> status = objectMapper.readValue(file, Map.class);
            return status;
        } catch (Exception e) {
            return idleStatus(jobType);
        }
    }

    private void writeBatchStatus(String jobType, String jobId, String status,
                                  int processed, int total,
                                  LocalDateTime startedAt, LocalDateTime completedAt,
                                  String errorMsg) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("jobId", jobId);
        data.put("jobType", jobType);
        data.put("status", status);
        data.put("processedCount", processed);
        data.put("totalCount", total);
        data.put("startedAt", startedAt != null ? startedAt.toString() : null);
        data.put("completedAt", completedAt != null ? completedAt.toString() : null);
        data.put("errorMsg", errorMsg);

        try {
            Files.createDirectories(Paths.get(batchStatusPath));
            File file = Paths.get(batchStatusPath, jobType + ".json").toAbsolutePath().toFile();
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file, data);
        } catch (Exception e) {
            throw new RuntimeException("배치 상태 파일 저장 실패: " + jobType, e);
        }
    }

    private Map<String, Object> idleStatus(String jobType) {
        Map<String, Object> m = new HashMap<>();
        m.put("jobId", null);
        m.put("jobType", jobType);
        m.put("status", "IDLE");
        m.put("processedCount", 0);
        m.put("totalCount", 0);
        m.put("startedAt", null);
        m.put("completedAt", null);
        m.put("errorMsg", null);
        return m;
    }
}
