package com.kt.ccs.service;

import com.kt.ccs.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Map<String, Object> getSummary(String baseMonth) {
        return customerRepository.getSummary(baseMonth);
    }
}
