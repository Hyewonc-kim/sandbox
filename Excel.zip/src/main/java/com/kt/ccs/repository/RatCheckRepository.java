package com.kt.ccs.repository;

import com.kt.ccs.common.QueryLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Lazy
@Repository
public class RatCheckRepository {

    private static final String APPLICATION_ID = "W5R38";

    private final JdbcTemplate jdbcTemplate;
    private final QueryLoader queryLoader;

    public RatCheckRepository(JdbcTemplate jdbcTemplate, QueryLoader queryLoader) {
        this.jdbcTemplate = jdbcTemplate;
        this.queryLoader = queryLoader;
    }

    public List<Map<String, Object>> getTableMapping(String baseMonth) {
        String sql = queryLoader.getQuery("rat-check", "ratCheck.getTableMapping");
        return jdbcTemplate.queryForList(sql, baseMonth);
    }

    public List<Map<String, Object>> getIndexStatus(String baseMonth) {
        String sql = queryLoader.getQuery("rat-check", "ratCheck.getIndexStatus");
        return jdbcTemplate.queryForList(sql, baseMonth);
    }

    public List<Map<String, Object>> getCycleInfo(String baseMonth) {
        String sql = queryLoader.getQuery("rat-check", "ratCheck.getCycleInfo");
        return jdbcTemplate.queryForList(sql, baseMonth);
    }

    public Map<String, Object> getRechargeStatus(String baseMonth) {
        String sql = queryLoader.getQuery("rat-check", "ratCheck.getRechargeStatus");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }

    public Map<String, Object> getProcessingStatus(String baseMonth) {
        String sql = queryLoader.getQuery("rat-check", "ratCheck.getProcessingStatus");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }

    /** 재과금 등록. H2 로컬에서는 테이블 없음으로 0 반환. */
    public int insertRecharge(String baseMonth, String customerId) {
        String sql = queryLoader.getQuery("rat-check", "ratCheck.insertRecharge");
        try {
            return jdbcTemplate.update(sql, APPLICATION_ID, baseMonth, customerId);
        } catch (DataAccessException e) {
            return 0;
        }
    }

    /** UpdateHandler 등록. H2 로컬에서는 테이블 없음으로 0 반환. */
    public int insertUpdateHandler(String baseMonth, String requestId, String beforeStatus) {
        String sql = queryLoader.getQuery("rat-check", "ratCheck.insertUpdateHandler");
        try {
            return jdbcTemplate.update(sql, APPLICATION_ID, requestId, beforeStatus);
        } catch (DataAccessException e) {
            return 0;
        }
    }
}
