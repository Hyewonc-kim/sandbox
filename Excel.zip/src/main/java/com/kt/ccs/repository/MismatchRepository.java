package com.kt.ccs.repository;

import com.kt.ccs.common.QueryLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Lazy
@Repository
public class MismatchRepository {

    private final JdbcTemplate jdbcTemplate;
    private final QueryLoader queryLoader;

    public MismatchRepository(JdbcTemplate jdbcTemplate, QueryLoader queryLoader) {
        this.jdbcTemplate = jdbcTemplate;
        this.queryLoader = queryLoader;
    }

    public Map<String, Object> getSummary(String baseMonth) {
        String sql = queryLoader.getQuery("mismatch", "mismatch.getSummary");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }

    public List<Map<String, Object>> getDetail(String baseMonth) {
        String sql = queryLoader.getQuery("mismatch", "mismatch.getDetail");
        return jdbcTemplate.queryForList(sql, baseMonth);
    }
}
