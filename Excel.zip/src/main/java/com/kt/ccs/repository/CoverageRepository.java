package com.kt.ccs.repository;

import com.kt.ccs.common.QueryLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Lazy
@Repository
public class CoverageRepository {

    private final JdbcTemplate jdbcTemplate;
    private final QueryLoader queryLoader;

    public CoverageRepository(JdbcTemplate jdbcTemplate, QueryLoader queryLoader) {
        this.jdbcTemplate = jdbcTemplate;
        this.queryLoader = queryLoader;
    }

    public Map<String, Object> getProductCoverage(String baseMonth) {
        String sql = queryLoader.getQuery("coverage", "coverage.getProductCoverage");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }

    public Map<String, Object> getItemCoverage(String baseMonth) {
        String sql = queryLoader.getQuery("coverage", "coverage.getItemCoverage");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }

    public Map<String, Object> getCustomerCoverage(String baseMonth) {
        String sql = queryLoader.getQuery("coverage", "coverage.getCustomerCoverage");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }
}
