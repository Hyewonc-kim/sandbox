package com.kt.ccs.repository;

import com.kt.ccs.common.QueryLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Lazy
@Repository
public class ItemRepository {

    private final JdbcTemplate jdbcTemplate;
    private final QueryLoader queryLoader;

    public ItemRepository(JdbcTemplate jdbcTemplate, QueryLoader queryLoader) {
        this.jdbcTemplate = jdbcTemplate;
        this.queryLoader = queryLoader;
    }

    public List<Map<String, Object>> getSummary(String baseMonth) {
        String sql = queryLoader.getQuery("item", "item.getSummary");
        return jdbcTemplate.queryForList(sql, baseMonth);
    }

    public List<Map<String, Object>> getSpecialFeatures(String baseMonth) {
        String sql = queryLoader.getQuery("item", "item.getSpecialFeatures");
        return jdbcTemplate.queryForList(sql, baseMonth);
    }
}
