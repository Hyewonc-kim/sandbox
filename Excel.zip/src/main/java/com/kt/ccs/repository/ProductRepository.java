package com.kt.ccs.repository;

import com.kt.ccs.common.QueryLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Lazy
@Repository
public class ProductRepository {

    private final JdbcTemplate jdbcTemplate;
    private final QueryLoader queryLoader;

    public ProductRepository(JdbcTemplate jdbcTemplate, QueryLoader queryLoader) {
        this.jdbcTemplate = jdbcTemplate;
        this.queryLoader = queryLoader;
    }

    public Map<String, Object> getSummary(String baseMonth) {
        String sql = queryLoader.getQuery("product", "product.getSummary");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }

    public List<Map<String, Object>> getTopSubscribers(String baseMonth, String productType) {
        String sql = queryLoader.getQuery("product", "product.getTopSubscribers");
        return jdbcTemplate.queryForList(sql, baseMonth, productType);
    }

    public List<Map<String, Object>> getNoUsageList(String baseMonth, String productType) {
        String sql = queryLoader.getQuery("product", "product.getNoUsageList");
        return jdbcTemplate.queryForList(sql, baseMonth, productType);
    }

    public List<Map<String, Object>> getNoSubscriberList(String baseMonth) {
        String sql = queryLoader.getQuery("product", "product.getNoSubscriberList");
        return jdbcTemplate.queryForList(sql, baseMonth);
    }
}
