package com.kt.ccs.repository;

import com.kt.ccs.common.QueryLoader;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Lazy
@Repository
public class CustomerRepository {

    private final JdbcTemplate jdbcTemplate;
    private final QueryLoader queryLoader;

    public CustomerRepository(JdbcTemplate jdbcTemplate, QueryLoader queryLoader) {
        this.jdbcTemplate = jdbcTemplate;
        this.queryLoader = queryLoader;
    }

    public Map<String, Object> getSummary(String baseMonth) {
        String sql = queryLoader.getQuery("customer", "customer.getSummary");
        Map<String, Object> result = jdbcTemplate.queryForMap(sql, baseMonth);
        return result != null ? result : new HashMap<>();
    }
}
