package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.CoverageService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/coverage")
public class CoverageController {

    private final CoverageService coverageService;

    public CoverageController(CoverageService coverageService) {
        this.coverageService = coverageService;
    }

    @GetMapping("/product")
    public ApiResponse<Map<String, Object>> getProductCoverage(@RequestParam String baseMonth) {
        return ApiResponse.success(coverageService.getProductCoverage(baseMonth));
    }

    @GetMapping("/item")
    public ApiResponse<Map<String, Object>> getItemCoverage(@RequestParam String baseMonth) {
        return ApiResponse.success(coverageService.getItemCoverage(baseMonth));
    }

    @GetMapping("/customer")
    public ApiResponse<Map<String, Object>> getCustomerCoverage(@RequestParam String baseMonth) {
        return ApiResponse.success(coverageService.getCustomerCoverage(baseMonth));
    }
}
