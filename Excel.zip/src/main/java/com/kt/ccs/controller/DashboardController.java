package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    @GetMapping("/summary")
    public ApiResponse<Map<String, Object>> getSummary(@RequestParam String baseMonth) {
        return ApiResponse.success(dashboardService.getSummary(baseMonth));
    }

    @GetMapping("/batch-status")
    public ApiResponse<Map<String, Object>> getBatchStatus() {
        return ApiResponse.success(dashboardService.getBatchStatus());
    }

    @PostMapping("/step/{step}/execute")
    public ResponseEntity<ApiResponse<Void>> executeStep(
            @PathVariable int step,
            @RequestParam String baseMonth) {
        dashboardService.executeStepAsync(step, baseMonth);
        return ResponseEntity.accepted().body(ApiResponse.success(null));
    }
}
