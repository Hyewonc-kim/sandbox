package com.kt.ccs.controller;

import com.kt.ccs.service.ExportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/export")
public class ExportController {

    private final ExportService exportService;

    public ExportController(ExportService exportService) {
        this.exportService = exportService;
    }

    @GetMapping("/{screen}")
    public ResponseEntity<byte[]> export(
            @PathVariable String screen,
            @RequestParam String baseMonth,
            @RequestParam(defaultValue = "excel") String format) {
        return exportService.export(screen, baseMonth, format);
    }
}
