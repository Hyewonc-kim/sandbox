package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.ItemService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/item")
public class ItemController {

    private final ItemService itemService;

    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @GetMapping("/summary")
    public ApiResponse<List<Map<String, Object>>> getSummary(@RequestParam String baseMonth) {
        return ApiResponse.success(itemService.getSummary(baseMonth));
    }

    @GetMapping("/special-features")
    public ApiResponse<List<Map<String, Object>>> getSpecialFeatures(@RequestParam String baseMonth) {
        return ApiResponse.success(itemService.getSpecialFeatures(baseMonth));
    }
}
