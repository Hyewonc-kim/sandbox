package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.ProductService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/product")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/summary")
    public ApiResponse<Map<String, Object>> getSummary(@RequestParam String baseMonth) {
        return ApiResponse.success(productService.getSummary(baseMonth));
    }

    @GetMapping("/top-subscribers")
    public ApiResponse<List<Map<String, Object>>> getTopSubscribers(
            @RequestParam String baseMonth,
            @RequestParam(defaultValue = "m-rate") String productType) {
        return ApiResponse.success(productService.getTopSubscribers(baseMonth, productType));
    }

    @GetMapping("/no-usage-list")
    public ApiResponse<List<Map<String, Object>>> getNoUsageList(
            @RequestParam String baseMonth,
            @RequestParam(defaultValue = "m-rate") String productType) {
        return ApiResponse.success(productService.getNoUsageList(baseMonth, productType));
    }

    @GetMapping("/no-subscriber-list")
    public ApiResponse<List<Map<String, Object>>> getNoSubscriberList(@RequestParam String baseMonth) {
        return ApiResponse.success(productService.getNoSubscriberList(baseMonth));
    }
}
