package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.RatCheckService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/rat-check")
public class RatCheckController {

    private final RatCheckService ratCheckService;

    public RatCheckController(RatCheckService ratCheckService) {
        this.ratCheckService = ratCheckService;
    }

    @GetMapping("/table-mapping")
    public ApiResponse<List<Map<String, Object>>> getTableMapping(@RequestParam String baseMonth) {
        return ApiResponse.success(ratCheckService.getTableMapping(baseMonth));
    }

    @GetMapping("/index-status")
    public ApiResponse<List<Map<String, Object>>> getIndexStatus(@RequestParam String baseMonth) {
        return ApiResponse.success(ratCheckService.getIndexStatus(baseMonth));
    }

    @GetMapping("/cycle-info")
    public ApiResponse<List<Map<String, Object>>> getCycleInfo(@RequestParam String baseMonth) {
        return ApiResponse.success(ratCheckService.getCycleInfo(baseMonth));
    }

    @GetMapping("/recharge-status")
    public ApiResponse<Map<String, Object>> getRechargeStatus(@RequestParam String baseMonth) {
        return ApiResponse.success(ratCheckService.getRechargeStatus(baseMonth));
    }

    @GetMapping("/processing-status")
    public ApiResponse<Map<String, Object>> getProcessingStatus(@RequestParam String baseMonth) {
        return ApiResponse.success(ratCheckService.getProcessingStatus(baseMonth));
    }

    @PostMapping("/recharge")
    public ApiResponse<Integer> insertRecharge(
            @RequestParam String baseMonth,
            @RequestBody Map<String, String> body) {
        int affected = ratCheckService.insertRecharge(baseMonth, body.get("customerId"));
        return ApiResponse.success(affected);
    }

    @PostMapping("/update-handler")
    public ApiResponse<Integer> insertUpdateHandler(
            @RequestParam String baseMonth,
            @RequestBody Map<String, String> body) {
        int affected = ratCheckService.insertUpdateHandler(
                baseMonth, body.get("requestId"), body.get("beforeStatus"));
        return ApiResponse.success(affected);
    }
}
