package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.CustomerService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping("/summary")
    public ApiResponse<Map<String, Object>> getSummary(@RequestParam String baseMonth) {
        return ApiResponse.success(customerService.getSummary(baseMonth));
    }
}
