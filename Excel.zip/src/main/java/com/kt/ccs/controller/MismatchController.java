package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.MismatchService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/mismatch")
public class MismatchController {

    private final MismatchService mismatchService;

    public MismatchController(MismatchService mismatchService) {
        this.mismatchService = mismatchService;
    }

    @GetMapping("/summary")
    public ApiResponse<Map<String, Object>> getSummary(@RequestParam String baseMonth) {
        return ApiResponse.success(mismatchService.getSummary(baseMonth));
    }

    @GetMapping("/detail")
    public ApiResponse<List<Map<String, Object>>> getDetail(@RequestParam String baseMonth) {
        return ApiResponse.success(mismatchService.getDetail(baseMonth));
    }
}
