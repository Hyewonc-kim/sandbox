package com.kt.ccs.controller;

import com.kt.ccs.common.ApiResponse;
import com.kt.ccs.service.QueryService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/queries")
public class QueryController {

    private final QueryService queryService;

    public QueryController(QueryService queryService) {
        this.queryService = queryService;
    }

    @GetMapping("/{screen}")
    public ApiResponse<Map<String, Object>> getAllQueries(@PathVariable String screen) {
        return ApiResponse.success(queryService.getAllQueries(screen));
    }

    @GetMapping("/{screen}/{key}")
    public ApiResponse<Map<String, String>> getQuery(
            @PathVariable String screen,
            @PathVariable String key) {
        return ApiResponse.success(Map.of("sql", queryService.getQuery(screen, key)));
    }

    @PutMapping("/{screen}/{key}")
    public ApiResponse<Void> saveQuery(
            @PathVariable String screen,
            @PathVariable String key,
            @RequestBody Map<String, String> body) {
        queryService.saveQuery(screen, key, body.get("sql"));
        return ApiResponse.success(null);
    }
}
