package com.kt.ccs.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class QueryLoader {

    @Value("${ccs.query-path}")
    private String queryPath;

    public String getQuery(String screen, String key) {
        Map<String, Object> queries = loadYaml(screen);
        Object sql = queries.get(key);
        if (sql == null) {
            throw new IllegalArgumentException("쿼리 키를 찾을 수 없습니다: " + screen + " / " + key);
        }
        return sql.toString().trim();
    }

    public Map<String, Object> getAllQueries(String screen) {
        return loadYaml(screen);
    }

    public void saveQuery(String screen, String key, String sql) {
        Path filePath = resolveFile(screen);
        Map<String, Object> queries = loadYaml(screen);
        queries.put(key, sql);

        Yaml yaml = new Yaml();
        try (FileWriter writer = new FileWriter(filePath.toFile())) {
            yaml.dump(queries, writer);
        } catch (IOException e) {
            throw new RuntimeException("쿼리 저장 실패: " + filePath, e);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> loadYaml(String screen) {
        Path filePath = resolveFile(screen);
        if (!Files.exists(filePath)) {
            throw new RuntimeException("쿼리 파일이 없습니다: " + filePath);
        }
        Yaml yaml = new Yaml();
        try (InputStream is = new FileInputStream(filePath.toFile())) {
            Map<String, Object> result = yaml.load(is);
            return result != null ? result : new LinkedHashMap<>();
        } catch (IOException e) {
            throw new RuntimeException("쿼리 파일 읽기 실패: " + filePath, e);
        }
    }

    private Path resolveFile(String screen) {
        String fileName = screen + ".yml";
        return Paths.get(queryPath).resolve(fileName).toAbsolutePath().normalize();
    }
}
