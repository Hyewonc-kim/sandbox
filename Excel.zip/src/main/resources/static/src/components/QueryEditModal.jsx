const { useState: useStateQEM, useEffect: useEffectQEM } = React;
const { X, Save } = lucide;

const QueryEditModal = ({ screen, queryKey, label, onClose, onSaved }) => {
  const [sql, setSql] = useStateQEM('');
  const [loading, setLoading] = useStateQEM(true);
  const [saving, setSaving] = useStateQEM(false);
  const [error, setError] = useStateQEM(null);

  useEffectQEM(() => {
    api.fetchQuery(screen, queryKey)
      .then(res => {
        if (res.success) setSql(res.data.sql || '');
        else setError(res.message);
      })
      .catch(() => setError('쿼리를 불러오지 못했습니다'))
      .finally(() => setLoading(false));
  }, [screen, queryKey]);

  const handleSave = () => {
    setSaving(true);
    api.saveQuery(screen, queryKey, sql)
      .then(res => {
        if (res.success) { onSaved && onSaved(); onClose(); }
        else setError(res.message);
      })
      .catch(() => setError('저장에 실패했습니다'))
      .finally(() => setSaving(false));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }}>
      <div className="bg-white rounded-lg shadow-xl w-[700px] max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <div>
            <div className="text-sm font-semibold text-slate-800">쿼리 수정</div>
            <div className="text-xs text-slate-500 mt-0.5">{screen} / {queryKey}{label ? ` — ${label}` : ''}</div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-auto p-5">
          {loading && <div className="text-center text-slate-500 py-8">불러오는 중...</div>}
          {error && <div className="text-red-600 bg-red-50 rounded p-3 text-sm">{error}</div>}
          {!loading && !error && (
            <textarea
              value={sql}
              onChange={e => setSql(e.target.value)}
              className="w-full h-64 font-mono text-xs border border-slate-300 rounded p-3 focus:outline-none focus:border-slate-500 resize-y"
              spellCheck={false}
            />
          )}
        </div>
        <div className="flex justify-end gap-2 px-5 py-4 border-t border-slate-200">
          <button onClick={onClose} className="px-4 py-2 rounded border border-slate-300 text-sm text-slate-700 hover:bg-slate-50">취소</button>
          <button
            onClick={handleSave}
            disabled={saving || loading}
            className="px-4 py-2 rounded text-white text-sm flex items-center gap-1.5 disabled:opacity-50"
            style={{ background: '#2563eb' }}
          >
            <Save className="w-4 h-4" />
            {saving ? '저장 중...' : '저장'}
          </button>
        </div>
      </div>
    </div>
  );
};
