const Section = ({ c, title, icon: Icon, action, children }) => (
  <div className="bg-white rounded border border-slate-200 mb-4">
    <div className="flex items-center justify-between px-4 pt-4 pb-2">
      <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
        {Icon && <Icon className="w-4 h-4" style={{ color: c.primary }} />}
        {title}
      </div>
      {action}
    </div>
    <div className="px-4 pb-4">{children}</div>
  </div>
);
