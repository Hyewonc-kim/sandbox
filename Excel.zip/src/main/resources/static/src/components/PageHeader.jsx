const { FileSpreadsheet, FileCode } = lucide;

const PageHeader = ({ c, month, title, screen }) => {
  const displayMonth = month.replace(/(\d{4})(\d{2})/, '$1년 $2월');
  return (
    <div className="flex items-center justify-between mb-5">
      <div className="text-lg font-semibold text-slate-800">≡ {title}</div>
      <div className="flex gap-2">
        <span className="px-3 py-1.5 rounded text-white text-xs font-semibold" style={{ background: c.headerBg }}>
          {displayMonth}
        </span>
        <button
          onClick={() => screen && api.exportData(screen, month, 'excel')}
          className="px-3 py-1.5 rounded bg-white border border-slate-300 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-1"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" /> Excel
        </button>
        <button
          onClick={() => screen && api.exportData(screen, month, 'html')}
          className="px-3 py-1.5 rounded bg-white border border-slate-300 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-1"
        >
          <FileCode className="w-3.5 h-3.5" /> HTML
        </button>
      </div>
    </div>
  );
};
