const { Users: UsersIconC } = lucide;

const CustomerPage = ({ c, month }) => (
  <>
    <PageHeader c={c} month={month} title="고객 커버리지" screen="customer" />

    <div className="bg-white rounded p-5 border border-slate-200 mb-4">
      <div className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
        <UsersIconC className="w-4 h-4" style={{ color: c.primary }} />
        고객 커버리지
      </div>
      <div className="grid grid-cols-3 gap-6">
        <div>
          <div className="font-semibold text-sm mb-3 pb-2 border-b-2" style={{ color: c.primary, borderColor: c.primary }}>직접 커버리지</div>
          <div className="space-y-2 text-sm">
            {[
              ['전체 가입자','27,302,245','4,263'],
              ['모바일','24,475,497','4,236'],
              ['인터넷전화','2,826,748','27'],
              ['부가상품','66,388,875','726'],
              ['모바일','64,713,515','641'],
              ['인터넷전화','1,675,360','81'],
            ].map(([k, v1, v2], i) => (
              <div key={i} className="flex justify-between items-center text-xs border-b border-slate-100 py-1.5">
                <span className="text-slate-700">{k}</span>
                <span className="tabular-nums text-right"><span className="font-semibold">{v1}</span> / <span className="text-slate-600">{v2}</span></span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div className="font-semibold text-sm mb-3 pb-2 border-b-2" style={{ color: c.primary, borderColor: c.primary }}>간접 커버리지 — 요금제</div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5"><span>전체 커버 가입자</span><span className="tabular-nums font-semibold">9,638,602 (35.3%)</span></div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5"><span>모바일 커버 가입자</span><span className="tabular-nums">9,638,602 (39.4%)</span></div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5"><span>인터넷전화 커버 가입자</span><span className="tabular-nums">0 (0.0%)</span></div>
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1"><span>요금제 간접 커버리지</span><span className="font-bold">35.3%</span></div>
              <div className="h-3 bg-slate-100 rounded overflow-hidden"><div className="h-full" style={{ width: '35.3%', background: c.danger }} /></div>
            </div>
          </div>
        </div>
        <div>
          <div className="font-semibold text-sm mb-3 pb-2 border-b-2" style={{ color: c.primary, borderColor: c.primary }}>간접 커버리지 — 부가상품</div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5"><span>전체 가입 건수</span><span className="tabular-nums font-semibold">66,388,875</span></div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5"><span>커버 가입 건수</span><span className="tabular-nums">19,443,056 (29.3%)</span></div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5"><span>테스트 제외 (일시정지 등)</span><span className="tabular-nums">583,676</span></div>
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1"><span>부가상품 간접 커버리지</span><span className="font-bold">29.3%</span></div>
              <div className="h-3 bg-slate-100 rounded overflow-hidden"><div className="h-full" style={{ width: '29.3%', background: c.danger }} /></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div className="rounded p-4 border" style={{ background: `${c.accent}10`, borderColor: `${c.accent}40` }}>
      <div className="text-xs font-semibold mb-2 flex items-center gap-1" style={{ color: c.accent }}>💡 고객 커버리지 설명</div>
      <ul className="text-xs text-slate-600 space-y-1 list-disc list-inside">
        <li><strong>직접 커버리지</strong>: 추출된 고객이 실제로 가입한 상품의 고객 수</li>
        <li><strong>간접 커버리지</strong>: 추출된 고객이 가입한 상품을 이용하는 전체 고객의 비율</li>
        <li><strong>검증 완료 고객</strong>: 정합 검증이 완료된 고객의 수 및 비율</li>
      </ul>
    </div>
  </>
);
