const { Package: PkgIcon, Tag: TagIcon, Users: UsersIcon } = lucide;

const CoveragePage = ({ c, month }) => (
  <>
    <PageHeader c={c} month={month} title="커버리지 현황" screen="coverage" />

    <div className="bg-white rounded p-4 border border-slate-200 mb-4">
      <div className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
        <PkgIcon className="w-4 h-4" style={{ color: c.primary }} />
        상품 커버리지
      </div>
      <div className="grid grid-cols-4 gap-3">
        {[
          { num: 1, label: '전체 상품',     total: '7,244', a: '7,202', b: '42',  rateLabel: '' },
          { num: 2, label: '가입자 보유',   total: '4,263', a: '4,236', b: '27',  rateLabel: '요금제 58.8% / 부가상품 36.7%' },
          { num: 3, label: '사용내역 발생', total: '52',    a: '52',    b: '0',   rateLabel: '요금제 1.2% / 부가상품 5.8%' },
          { num: 4, label: '추출 완료',     total: '55',    a: '55',    b: '0',   rateLabel: '요금제 105.8% / 부가상품 100%' },
        ].map((s, i) => (
          <div key={i} className="border border-slate-200 rounded p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: c.primary }}>{s.num}</span>
              <span className="text-xs text-slate-500">{s.label}</span>
            </div>
            <div className="text-2xl font-bold text-slate-900 mb-1 tabular-nums">{s.total}</div>
            <div className="text-xs text-slate-500 space-y-0.5">
              <div className="flex justify-between"><span>요금제 모바일</span><span className="tabular-nums">{s.a}</span></div>
              <div className="flex justify-between"><span>인터넷전화</span><span className="tabular-nums">{s.b}</span></div>
              <div className="text-[10px] mt-1 text-slate-400">{s.rateLabel}</div>
            </div>
          </div>
        ))}
      </div>
      <div className="text-xs text-slate-500 mt-3 flex items-center gap-1">
        <span className="px-1.5 py-0.5 rounded text-white text-[10px]" style={{ background: c.warning }}>마켓상품 94개</span>
        가입 없이 적용되는 상품으로 커버리지 대상에서 제외됩니다.
      </div>
    </div>

    <div className="bg-white rounded p-4 border border-slate-200 mb-4">
      <div className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
        <TagIcon className="w-4 h-4" style={{ color: c.primary }} />
        아이템 커버리지
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 space-y-3">
          {[
            { label: '전체 아이템 → 발생 아이템',    val: '26,280 / 151,147 (17.4%)', pct: 17.4, color: c.accent },
            { label: '발생 아이템 → 고객 추출 완료', val: '26,267 / 26,280 (100.0%)', pct: 99.9, color: c.success },
          ].map((r, i) => (
            <div key={i}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600">{r.label}</span>
                <span className="tabular-nums text-slate-700">{r.val}</span>
              </div>
              <div className="h-3 bg-slate-100 rounded overflow-hidden">
                <div className="h-full" style={{ width: `${r.pct}%`, background: r.color }} />
              </div>
              <div className="text-xs font-semibold mt-0.5" style={{ color: r.color }}>{r.pct.toFixed(1)}%</div>
            </div>
          ))}
        </div>
        <div className="rounded p-3" style={{ background: `${c.danger}10`, border: `1px solid ${c.danger}30` }}>
          <div className="text-xs font-semibold mb-2" style={{ color: c.danger }}>⊘ 미추출 현황</div>
          <div className="text-2xl font-bold mb-2" style={{ color: c.danger }}>13개</div>
          <div className="text-xs text-slate-600 space-y-1">
            <div>전체 미발생 <span className="float-right tabular-nums">124,867개</span></div>
            <div>▸ 서비스·상품 종료된 아이템 <span className="float-right tabular-nums">49,726개</span></div>
            <div>▸ 가입자 없는 상품의 아이템 <span className="float-right tabular-nums">28,844개</span></div>
            <div>▸ 가입자 미사용 아이템 <span className="float-right tabular-nums">46,297개</span></div>
          </div>
        </div>
      </div>
    </div>

    <div className="bg-white rounded p-5 border border-slate-200 mb-4">
      <div className="text-sm font-semibold text-slate-800 mb-4 flex items-center gap-2">
        <UsersIcon className="w-4 h-4" style={{ color: c.primary }} />
        고객 커버리지
      </div>
      <div className="grid grid-cols-3 gap-6">
        <div>
          <div className="font-semibold text-sm mb-3 pb-2 border-b-2" style={{ color: c.primary, borderColor: c.primary }}>직접 커버리지</div>
          <div className="space-y-2 text-sm">
            {[
              ['전체 가입자',  '27,302,245', '4,263'],
              ['모바일',       '24,475,497', '4,236'],
              ['인터넷전화',   '2,826,748',  '27'],
              ['부가상품',     '66,388,875', '726'],
              ['ㄴ 모바일',    '64,713,515', '641'],
              ['ㄴ 인터넷전화','1,675,360',  '81'],
            ].map(([label, v1, v2], i) => (
              <div key={i} className="flex justify-between items-center text-xs border-b border-slate-100 py-1.5">
                <span className="text-slate-700">{label}</span>
                <span className="tabular-nums text-right">
                  <span className="font-semibold">{v1}</span>
                  {' / '}
                  <span className="text-slate-600">{v2}</span>
                </span>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div className="font-semibold text-sm mb-3 pb-2 border-b-2" style={{ color: c.primary, borderColor: c.primary }}>간접 커버리지 — 요금제</div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5">
              <span>전체 커버 가입자</span><span className="tabular-nums font-semibold">9,638,602 (35.3%)</span>
            </div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5">
              <span>모바일 커버 가입자</span><span className="tabular-nums">9,638,602 (39.4%)</span>
            </div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5">
              <span>인터넷전화 커버 가입자</span><span className="tabular-nums">0 (0.0%)</span>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1">
                <span>요금제 간접 커버리지</span><span className="font-bold">35.3%</span>
              </div>
              <div className="h-3 bg-slate-100 rounded overflow-hidden">
                <div className="h-full" style={{ width: '35.3%', background: c.danger }} />
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="font-semibold text-sm mb-3 pb-2 border-b-2" style={{ color: c.primary, borderColor: c.primary }}>간접 커버리지 — 부가상품</div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5">
              <span>전체 가입 건수</span><span className="tabular-nums font-semibold">66,388,875</span>
            </div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5">
              <span>커버 가입 건수</span><span className="tabular-nums">19,443,056 (29.3%)</span>
            </div>
            <div className="flex justify-between text-xs border-b border-slate-100 py-1.5">
              <span>테스트 제외 (일시정지 등)</span><span className="tabular-nums">583,676</span>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1">
                <span>부가상품 간접 커버리지</span><span className="font-bold">29.3%</span>
              </div>
              <div className="h-3 bg-slate-100 rounded overflow-hidden">
                <div className="h-full" style={{ width: '29.3%', background: c.danger }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div className="rounded p-4 border" style={{ background: `${c.accent}10`, borderColor: `${c.accent}40` }}>
      <div className="text-xs font-semibold mb-2 flex items-center gap-1" style={{ color: c.accent }}>💡 고객 커버리지 설명</div>
      <ul className="text-xs text-slate-600 space-y-1 list-disc list-inside">
        <li><strong>직접 커버리지</strong>: 추출된 고객이 실제로 가입한 상품의 고객 수</li>
        <li><strong>간접 커버리지</strong>: 추출된 고객이 가입한 상품을 이용하는 전체 고객의 비율</li>
        <li><strong>검증 완료 고객</strong>: 정합 검증이 완료된 고객의 수 및 비율</li>
      </ul>
    </div>
  </>
);
