const { useState: useStateR } = React;
const { Database, Layers: LayersR, FileText: FileTextR, RefreshCw, Lock, Unlock, Search: SearchR, Save: SaveR, Zap, PlusCircle: PlusR } = lucide;

const RatCheckPage = ({ c, month }) => {
  const [selectedStatus, setSelectedStatus] = useStateR('Q');

  const statusRows = [
    { key: null, label: '👥 고객건수',   count: '109명', time: '—',                    clickable: false },
    { key: null, label: 'R 등록',        count: '109건', time: '2026-05-11 16:19:23', clickable: false },
    { key: 'P',  label: 'P 대기(P)',      count: '0건',   time: '—',                    clickable: false },
    { key: 'O',  label: 'O 처리중(O)',    count: '0건',   time: '—',                    clickable: true },
    { key: 'D',  label: 'D 완료(D)',      count: '0건',   time: '—',                    clickable: true },
    { key: 'Q',  label: 'Q 고객정보(Q)', count: '0건',   time: '—',                    clickable: true },
    { key: 'A',  label: 'A 에러(A)',      count: '0건',   time: '—',                    clickable: true },
  ];

  const rightPanelType = (selectedStatus === 'O' || selectedStatus === 'D') ? 'stats' : 'handler';

  return (
    <>
      <PageHeader c={c} month={month} title="RAT 사전 체크" screen="rat-check" />

      <Section c={c} title="검증 대상 테이블" icon={Database} action={
        <button className="px-2 py-1 rounded text-white text-xs flex items-center gap-1" style={{ background: c.accent }}>
          <SaveR className="w-3 h-3" /> 저장
        </button>
      }>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-3">구분</th>
              <th className="text-left py-2 px-3"><span className="px-1.5 py-0.5 rounded text-xs font-semibold mr-1" style={{ background: c.warning, color: 'white' }}>ASIS</span>테이블명</th>
              <th className="text-left py-2 px-3"><span className="px-1.5 py-0.5 rounded text-xs font-semibold mr-1" style={{ background: c.accent, color: 'white' }}>TOBE</span>테이블명</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-slate-100">
              <td className="py-2 px-3 font-medium flex items-center gap-1"><Zap className="w-3.5 h-3.5" style={{ color: c.warning }} /> Rated Event</td>
              <td className="py-2 px-3 font-mono text-xs">Z_TMP_APE1_RATED_EVENT1</td>
              <td className="py-2 px-3 font-mono text-xs">HBASE_TEMP_BBD979D2</td>
            </tr>
            <tr>
              <td className="py-2 px-3 font-medium flex items-center gap-1"><LayersR className="w-3.5 h-3.5" style={{ color: c.primary }} /> Accumulators</td>
              <td className="py-2 px-3 font-mono text-xs">Z_TMP_APE1_ACCUMULATORS1</td>
              <td className="py-2 px-3"><input type="text" placeholder="TOBE Accumulators 테이블명" className="border border-slate-300 rounded px-2 py-1 text-xs w-full font-mono" /></td>
            </tr>
          </tbody>
        </table>
      </Section>

      <Section c={c} title="인덱스 확인 및 생성" icon={LayersR} action={
        <button className="px-2 py-1 rounded text-xs flex items-center gap-1 border" style={{ borderColor: c.warning, color: c.warning, background: 'white' }}>
          <SearchR className="w-3 h-3" /> 인덱스 확인
        </button>
      }>
        <table className="w-full text-xs">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-2">구분</th>
              <th className="text-left py-2 px-2">테이블명</th>
              <th className="text-left py-2 px-2">상태</th>
              <th className="text-left py-2 px-2">인덱스명</th>
              <th className="text-left py-2 px-2">유형</th>
              <th className="text-left py-2 px-2">컬럼</th>
            </tr>
          </thead>
          <tbody>
            {[
              { tag: 'ASIS RE', tbl: 'Z_TMP_APE1_RATED_EVENT1',   status: '존재', idx: 'IDX_Z_TMP_APE1_RATED_EVENT1',   type: 'NORMAL', cols: 'CUSTOMER_ID, EVENT_TYPE_ID, L9_PRODUCT_CODE, L9_AIRTIME_FT_CD, START_TIME, SUBSCRIBER_ID' },
              { tag: 'TOBE RE', tbl: 'HBASE_TEMP_BBD979D2',        status: '존재', idx: 'IDX_HBASE_TEMP_BBD979D2',        type: 'NORMAL', cols: 'CYCLE_CODE, CYCLE_INSTANCE, CYCLE_YEAR, CUSTOMER_SEGMENT, CUSTOMER_ID, OWNER_ID, ITEM_ID, OFFER_INSTANCE, ACCUM_TYPE_ID, OWNER_TYPE' },
              { tag: 'ASIS PI', tbl: 'Z_TMP_APE1_ACCUMULATORS1',  status: '존재', idx: 'IDX_Z_TMP_APE1_ACCUMULATORS1',  type: 'NORMAL', cols: 'CUSTOMER_ID, L9_ROLE, ACCUM_TYPE_ID, L9_PRODUCT_CODE, L9_AIRTIME_FT_CD' },
              { tag: 'TOBE PI', tbl: '(미설정)',                    status: '없음', idx: '테이블명이 설정되지 않았습니다.', type: '—',      cols: '—' },
            ].map((r, i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2 px-2">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold text-white" style={{ background: r.tag.includes('ASIS') ? c.warning : c.accent }}>{r.tag}</span>
                </td>
                <td className="py-2 px-2 font-mono">{r.tbl}</td>
                <td className="py-2 px-2">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold" style={{ background: r.status === '존재' ? `${c.success}20` : `${c.danger}20`, color: r.status === '존재' ? c.success : c.danger }}>
                    {r.status === '존재' ? '✓ 존재' : '✗ 없음'}
                  </span>
                </td>
                <td className="py-2 px-2 font-mono">{r.idx}</td>
                <td className="py-2 px-2">{r.type !== '—' ? <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-200 text-slate-700">{r.type}</span> : <span className="text-slate-400">—</span>}</td>
                <td className="py-2 px-2 text-[10px] text-slate-600 max-w-xs">{r.cols}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Section>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <Section c={c} title="검증대상 요약" icon={FileTextR} action={
          <button className="px-2 py-1 rounded text-white text-xs flex items-center gap-1" style={{ background: c.accent }}>
            <SearchR className="w-3 h-3" /> 조회
          </button>
        }>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-white text-xs" style={{ background: c.headerBg }}>
                <th className="text-left py-2 px-3">구분</th>
                <th className="text-right py-2 px-3"><span className="px-1.5 py-0.5 rounded text-[10px] text-white" style={{ background: c.warning }}>ASIS</span></th>
                <th className="text-right py-2 px-3"><span className="px-1.5 py-0.5 rounded text-[10px] text-white" style={{ background: c.accent }}>TOBE</span></th>
                <th className="text-right py-2 px-3">차이</th>
              </tr>
            </thead>
            <tbody>
              {['Customer','Subscriber','Rated Event','Accumulators'].map((k, i) => (
                <tr key={i} className="border-b border-slate-100">
                  <td className="py-2 px-3 text-slate-700">{k}</td>
                  <td className="py-2 px-3 text-right text-slate-400">—</td>
                  <td className="py-2 px-3 text-right text-slate-400">—</td>
                  <td className="py-2 px-3 text-right text-slate-400">—</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Section>

        <Section c={c} title="Cycle 정보" icon={RefreshCw} action={
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span className="flex items-center gap-1"><Lock className="w-3 h-3" style={{ color: c.danger }} /> 잠금</span>
            <span className="flex items-center gap-1"><Unlock className="w-3 h-3" style={{ color: c.success }} /> 미잠금</span>
            <button className="px-2 py-1 rounded text-white text-xs flex items-center gap-1" style={{ background: c.accent }}>
              <SearchR className="w-3 h-3" /> 조회
            </button>
          </div>
        }>
          <div className="grid grid-cols-4 gap-2">
            {[
              {wlLock:true, wlNew:12,wlUpd:8,  wdLock:true, wdNew:9, wdUpd:5},
              {wlLock:true, wlNew:15,wlUpd:11, wdLock:true, wdNew:7, wdUpd:6},
              {wlLock:true, wlNew:18,wlUpd:9,  wdLock:false,wdNew:11,wdUpd:4},
              {wlLock:false,wlNew:22,wlUpd:14, wdLock:false,wdNew:13,wdUpd:8},
              {wlLock:false,wlNew:16,wlUpd:10, wdLock:false,wdNew:10,wdUpd:7},
              {wlLock:false,wlNew:19,wlUpd:12, wdLock:false,wdNew:8, wdUpd:5},
              {wlLock:false,wlNew:14,wlUpd:9,  wdLock:false,wdNew:6, wdUpd:3},
              {wlLock:false,wlNew:11,wlUpd:7,  wdLock:false,wdNew:5, wdUpd:4},
              {wlLock:false,wlNew:8, wlUpd:5,  wdLock:false,wdNew:4, wdUpd:2},
              {wlLock:false,wlNew:6, wlUpd:3,  wdLock:false,wdNew:3, wdUpd:2},
              {wlLock:false,wlNew:3, wlUpd:1,  wdLock:false,wdNew:2, wdUpd:1},
              {wlLock:false,wlNew:0, wlUpd:0,  wdLock:false,wdNew:0, wdUpd:0},
            ].map((d, m) => {
              const isCurrent = m === 0;
              return (
                <div key={m} className="border rounded p-2 text-xs" style={{ borderColor: isCurrent ? c.primary : '#e2e8f0', background: isCurrent ? c.primaryLight : 'white' }}>
                  <div className="flex items-center justify-between mb-1.5 pb-1 border-b border-slate-100">
                    <span className="text-[11px] font-semibold" style={{ color: isCurrent ? c.primary : '#334155' }}>📅 2026년</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-semibold" style={{ background: isCurrent ? c.primary : '#f1f5f9', color: isCurrent ? 'white' : '#64748b' }}>{m+1}월</span>
                  </div>
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="flex items-center gap-1 text-slate-700 font-medium">
                      {d.wlLock ? <Lock className="w-2.5 h-2.5" style={{ color: c.danger }} /> : <Unlock className="w-2.5 h-2.5" style={{ color: c.success }} />}
                      무선
                    </span>
                    <span className="flex gap-1.5 text-[10px] tabular-nums">
                      <span style={{ color: c.success }}>New {d.wlNew}</span>
                      <span style={{ color: c.accent }}>Upd {d.wlUpd}</span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1 text-slate-700 font-medium">
                      {d.wdLock ? <Lock className="w-2.5 h-2.5" style={{ color: c.danger }} /> : <Unlock className="w-2.5 h-2.5" style={{ color: c.success }} />}
                      유선
                    </span>
                    <span className="flex gap-1.5 text-[10px] tabular-nums">
                      <span style={{ color: c.success }}>New {d.wdNew}</span>
                      <span style={{ color: c.accent }}>Upd {d.wdUpd}</span>
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      </div>

      <div className="bg-white rounded border border-slate-200">
        <div className="flex items-center justify-between px-4 pt-4 pb-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-800">
            <RefreshCw className="w-4 h-4" style={{ color: c.primary }} /> 재과금 현황
          </div>
          <div className="flex gap-2">
            <button className="px-2 py-1 rounded bg-white border border-slate-300 text-slate-700 text-xs flex items-center gap-1 hover:bg-slate-50">
              <RefreshCw className="w-3 h-3" /> 새로고침
            </button>
            <button className="px-2 py-1 rounded text-white text-xs flex items-center gap-1" style={{ background: c.danger }}>
              <PlusR className="w-3 h-3" /> 재과금 등록
            </button>
          </div>
        </div>
        <div className="px-4 pb-4">
          <div className="flex items-center gap-2 text-sm mb-4">
            <span className="text-slate-700">🔑 APPLICATION ID</span>
            <span className="px-2 py-0.5 rounded font-mono text-sm font-bold" style={{ background: `${c.danger}15`, color: c.danger }}>W5R38</span>
            <button className="px-2 py-1 rounded text-xs" style={{ background: c.primaryLight, color: c.primary }}>🔄 갱신</button>
            <span className="text-xs text-slate-500">— 재과금 등록 시 이 키가 APPLICATION_ID 에 저장됩니다.</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                <FileTextR className="w-3.5 h-3.5" style={{ color: c.primary }} />
                재과금 현황
                <span className="text-[10px] font-normal text-slate-500">(APPLICATION_ID: W5R38)</span>
              </div>
              <table className="w-full text-sm" style={{ tableLayout: 'fixed' }}>
                <colgroup><col /><col style={{ width: '80px' }} /><col style={{ width: '140px' }} /></colgroup>
                <thead>
                  <tr className="text-white text-xs" style={{ background: c.headerBg }}>
                    <th className="text-left py-2 px-3">구분</th>
                    <th className="text-right py-2 px-3">건수</th>
                    <th className="text-right py-2 px-3">최종시간</th>
                  </tr>
                </thead>
                <tbody>
                  {statusRows.map((row, i) => {
                    const isSelected = row.clickable && selectedStatus === row.key;
                    return (
                      <tr key={i} onClick={() => row.clickable && setSelectedStatus(row.key)}
                        className="border-b border-slate-100"
                        style={{ cursor: row.clickable ? 'pointer' : 'default', background: isSelected ? c.primaryLight : 'transparent' }}
                        onMouseEnter={(e) => { if (row.clickable && !isSelected) e.currentTarget.style.background = '#f8fafc'; }}
                        onMouseLeave={(e) => { if (row.clickable && !isSelected) e.currentTarget.style.background = 'transparent'; }}
                      >
                        <td className="py-2 px-3 text-xs text-slate-700">
                          <span className="flex items-center gap-2">
                            <span>{row.label}</span>
                            {isSelected && <span className="text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ color: 'white', background: c.primary }}>선택</span>}
                          </span>
                        </td>
                        <td className="py-2 px-3 text-right tabular-nums font-semibold">{row.count}</td>
                        <td className="py-2 px-3 text-right text-[10px] text-slate-500">{row.time}</td>
                      </tr>
                    );
                  })}
                  <tr>
                    <td colSpan={3} className="py-2 px-3 text-[10px] text-slate-500 bg-slate-50">
                      ⓘ O · D · Q · A 행을 클릭하면 우측 패널이 전환됩니다.
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div>
              {rightPanelType === 'handler' ? (
                <>
                  <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                    <span className="px-1.5 py-0.5 rounded text-[10px] text-white" style={{ background: c.accent }}>Update Handler 등록</span>
                    <span className="text-[10px] font-normal text-slate-500">(APPLICATION_ID: W5R38)</span>
                  </div>
                  <div className="border border-slate-200 rounded p-4">
                    <div className="text-xs text-slate-700 mb-3">
                      🔑 APPLICATION ID: <strong>W5R38</strong> · 상태:{' '}
                      <span className="px-1.5 py-0.5 rounded text-[10px]" style={{
                        background: selectedStatus === 'Q' ? `${c.warning}20` : `${c.danger}20`,
                        color: selectedStatus === 'Q' ? c.warning : c.danger,
                      }}>
                        {selectedStatus === 'Q' ? 'Q 고객정보(Q)' : 'A 에러(A)'}
                      </span>
                    </div>
                    <label className="text-xs font-semibold text-slate-700 block mb-1">Request ID <span style={{ color: c.danger }}>*</span></label>
                    <div className="flex gap-2">
                      <input type="text" placeholder="Request ID를 입력하세요" className="flex-1 border border-slate-300 rounded px-2 py-1.5 text-sm" />
                      <button className="px-3 py-1.5 rounded text-white text-xs font-semibold" style={{ background: c.warning }}>➕ 등록</button>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                    <span className="px-1.5 py-0.5 rounded text-[10px] text-white" style={{ background: selectedStatus === 'O' ? c.warning : c.success }}>
                      {selectedStatus === 'O' ? '처리중(O)' : '완료(D)'} 항목별 집계
                    </span>
                    <span className="text-[10px] font-normal text-slate-500">(APPLICATION_ID: W5R38)</span>
                  </div>
                  <table className="w-full text-sm" style={{ tableLayout: 'fixed' }}>
                    <colgroup><col /><col style={{ width: '100px' }} /></colgroup>
                    <thead>
                      <tr className="text-white text-xs" style={{ background: c.headerBg }}>
                        <th className="text-left py-2 px-3">항목</th>
                        <th className="text-right py-2 px-3">건수</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { icon: '👥', label: '고객수',           value: '0명', color: '#334155' },
                        { icon: '📤', label: '추출 레코드건수',   value: '0건', color: '#334155' },
                        { icon: '✓',  label: '처리 레코드건수',   value: '0건', color: c.accent },
                        { icon: '⊘',  label: 'REJECT 레코드건수', value: '0건', color: c.danger },
                        { icon: '🗑',  label: 'DROP 레코드건수',   value: '0건', color: c.warning },
                        { icon: '≡',  label: '전체 레코드건수',   value: '0건', color: '#334155', bold: true },
                      ].map((row, i) => (
                        <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                          <td className="py-2 px-3 text-xs text-slate-700"><span className="mr-1.5">{row.icon}</span>{row.label}</td>
                          <td className="py-2 px-3 text-right tabular-nums" style={{ color: row.color, fontWeight: row.bold ? 700 : 600 }}>{row.value}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </>
              )}
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                <RefreshCw className="w-3.5 h-3.5" style={{ color: c.primary }} />
                처리현황
              </div>
              <div className="text-[10px] text-slate-500">전체 등록 <span className="font-bold text-slate-700">109건</span> · 고객 109명</div>
            </div>
            {(() => {
              const segments = [
                { key: 'D', label: '완료',    count: 47, color: c.success },
                { key: 'O', label: '처리중',  count: 28, color: c.accent },
                { key: 'P', label: '대기',    count: 15, color: c.warning },
                { key: 'Q', label: '고객정보', count: 12, color: '#0891b2' },
                { key: 'A', label: '에러',    count: 7,  color: c.danger },
              ];
              const total = segments.reduce((s, x) => s + x.count, 0);
              return (
                <>
                  <div className="h-7 bg-slate-100 rounded-md overflow-hidden flex">
                    {segments.map((s, i) => {
                      const pct = (s.count / total) * 100;
                      return (
                        <div key={i} className="h-full flex items-center justify-center text-[10px] font-bold text-white transition-all hover:opacity-90 cursor-pointer"
                          style={{ width: `${pct}%`, background: s.color, borderRight: i < segments.length - 1 ? '2px solid white' : 'none' }}
                          title={`${s.label}: ${s.count}건 (${pct.toFixed(1)}%)`}>
                          {pct >= 8 && `${s.count}`}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-between mt-3 flex-wrap gap-3">
                    {segments.map((s, i) => {
                      const pct = (s.count / total) * 100;
                      return (
                        <div key={i} className="flex items-center gap-2 text-xs">
                          <span className="w-3 h-3 rounded-sm" style={{ background: s.color }} />
                          <span className="text-slate-700 font-medium">{s.label}</span>
                          <span className="tabular-nums font-semibold text-slate-900">{s.count}건</span>
                          <span className="text-slate-500 text-[10px] tabular-nums">({pct.toFixed(1)}%)</span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-4 grid grid-cols-3 gap-3">
                    {[
                      { label: '처리 완료율', val: ((47/109)*100).toFixed(1)+'%', sub: '47 / 109건', color: c.success },
                      { label: '진행률 (완료+처리중)', val: (((47+28)/109)*100).toFixed(1)+'%', sub: '75 / 109건', color: c.accent },
                      { label: '확인 필요 (Q+A)', val: (((12+7)/109)*100).toFixed(1)+'%', sub: '19 / 109건', color: c.danger },
                    ].map((item, i) => (
                      <div key={i} className="rounded p-2.5" style={{ background: `${item.color}10`, border: `1px solid ${item.color}30` }}>
                        <div className="text-[10px] text-slate-500 mb-0.5">{item.label}</div>
                        <div className="text-lg font-bold tabular-nums" style={{ color: item.color }}>{item.val}</div>
                        <div className="text-[10px] text-slate-500">{item.sub}</div>
                      </div>
                    ))}
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      </div>
    </>
  );
};
