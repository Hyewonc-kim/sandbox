const { Layers: LayersI, Star } = lucide;

const ItemPage = ({ c, month }) => {
  const itemRows = [
    ['무료','MPMD',9,0,0.0,0,0,9,0],
    ['무료','금액',159,21,13.2,19,0,119,2],
    ['무료','데이터',2974,1218,41.0,870,2,929,14],
    ['무료','로밍',14,1,7.1,12,0,1,0],
    ['무료','문자',682,332,48.7,176,0,174,6],
    ['무료','음성',1305,603,46.2,278,1,423,13],
    ['무료','컨텐츠',26,16,61.5,9,0,1,0],
    ['요율','MPMD',1,0,0.0,0,0,1,0],
    ['요율','Pass through',46706,800,1.7,7181,10516,28210,7],
    ['요율','데이터',53613,1695,3.2,13762,24495,13665,4],
    ['요율','로밍',2063,38,1.8,471,89,1465,6],
    ['요율','문자',12722,693,5.4,3453,6154,2422,3],
    ['요율','음성',10340,1226,11.9,2465,4628,2021,8],
    ['할인','Pass through',1,0,0.0,0,1,0,0],
    ['할인','금액',258,13,5.0,13,159,73,1],
    ['할인','로밍',19,0,0.0,2,2,15,0],
    ['할인','마켓',2,1,50.0,0,1,0,1],
    ['할인','선할인',30,12,40.0,5,3,10,5],
    ['할인','음성',89,21,23.6,13,41,14,5],
  ];

  const specialFeatures = [
    ['YDUM','데이터','KT Allowance pooling volume recurring rolling restricted non period sensitive base',32,32,'PL25CF848_A : Y덤_공유데이터 90GB','검증완료'],
    ['3STEPQR','데이터','KT Rate volume Stepped Rating excluding allowance',429,4,'QOS200STB : 데이터 초과 요금 상한','검증완료'],
    ['3STEPQR','데이터','KT Rate volume Stepped Rating excluding allowance group level',429,4,'QOS200STB_A : 데이터 초과 요금 상한','검증완료'],
    ['FAMSHARE','데이터','KT Family data sharing pool with priority dispatch',187,12,'FAMPACK01 : 가족 공유 데이터 100GB','검증완료'],
    ['ROLLOVR','데이터','KT Data rollover to next billing cycle with cap',256,18,'ROLLDATA1 : 이월 데이터 50GB','검증중'],
    ['BOOSTLT','데이터','KT Stepped boost rate for late-month usage',89,6,'BOOST5G01 : 5G 부스터 30GB','검증완료'],
    ['TIMEZON','음성','KT Time-of-day differential rating for voice',142,9,'VOICETZ01 : 시간대별 음성 요금','검증완료'],
    ['WKNDDIS','음성','KT Weekend discount stacking with promo codes',78,5,'WKNDFREE1 : 주말 무료 음성','검증완료'],
    ['INTNROAM','로밍','KT International roaming with country-tier pricing',312,21,'ROAM100GL : 글로벌 100국 로밍팩','검증중'],
    ['DUALSIM','음성','KT Dual-SIM shared minute pool with overflow',64,4,'DUAL5G001 : 듀얼심 공유플랜','검증완료'],
    ['NIGHTUL','데이터','KT Night unlimited data outside peak hours',198,14,'NIGHTUNL1 : 심야 무제한 데이터','검증완료'],
    ['TIERED5G','데이터','KT Tiered 5G speed cap with throttle thresholds',421,23,'5GTIER100 : 5G 단계별 속도 100GB','대기'],
  ];

  const ratioColor = (r) => r >= 30 ? c.success : r >= 10 ? c.warning : r > 0 ? '#94a3b8' : '#cbd5e1';
  const typeBg    = { '무료': '#e0e7ff', '요율': `${c.warning}20`, '할인': `${c.accent}20` };
  const typeColor = { '무료': '#4338ca', '요율': c.warning, '할인': c.accent };
  const fmt = (n) => n.toLocaleString();

  return (
    <>
      <PageHeader c={c} month={month} title="아이템별 현황" screen="item" />

      <div className="bg-white rounded p-4 border border-slate-200 mb-4">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <LayersI className="w-4 h-4" style={{ color: c.primary }} />
            전체 아이템 요약
          </div>
          <div className="flex items-center gap-3 text-[10px] text-slate-500">
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded" style={{ background: c.success }} />30%+</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded" style={{ background: c.warning }} />10~30%</span>
            <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-slate-400" />10% 미만</span>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-3">유형</th>
              <th className="text-left py-2 px-3">카테고리</th>
              <th className="text-right py-2 px-3">건수</th>
              <th className="text-right py-2 px-3">발생건수</th>
              <th className="text-left py-2 px-3" style={{ width: '22%' }}>발생비율</th>
              <th className="text-right py-2 px-3">미가입건수</th>
              <th className="text-right py-2 px-3">미발생건수</th>
              <th className="text-right py-2 px-3">미사용/만료</th>
              <th className="text-right py-2 px-3">PIT 건수(발생)</th>
            </tr>
          </thead>
          <tbody>
            {itemRows.map((row, i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2 px-3">
                  <span className="px-1.5 py-0.5 rounded text-xs font-medium" style={{ background: typeBg[row[0]], color: typeColor[row[0]] }}>{row[0]}</span>
                </td>
                <td className="py-2 px-3 text-slate-700">{row[1]}</td>
                <td className="py-2 px-3 text-right tabular-nums">{fmt(row[2])}</td>
                <td className="py-2 px-3 text-right tabular-nums font-semibold">{fmt(row[3])}</td>
                <td className="py-2 px-3">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-3 bg-slate-100 rounded overflow-hidden">
                      <div className="h-full transition-all" style={{ width: `${row[4]}%`, background: ratioColor(row[4]) }} />
                    </div>
                    <span className="text-xs tabular-nums font-semibold w-12 text-right" style={{ color: ratioColor(row[4]) }}>{row[4].toFixed(1)}%</span>
                  </div>
                </td>
                <td className="py-2 px-3 text-right tabular-nums text-slate-600">{fmt(row[5])}</td>
                <td className="py-2 px-3 text-right tabular-nums text-slate-600">{fmt(row[6])}</td>
                <td className="py-2 px-3 text-right tabular-nums text-slate-600">{fmt(row[7])}</td>
                <td className="py-2 px-3 text-right tabular-nums">{row[8]}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="text-[10px] text-slate-400 mt-2">ⓘ Pre rate 및 기능 Pricing Item Type 제외</div>
      </div>

      <div className="bg-white rounded p-4 border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <Star className="w-4 h-4" style={{ color: c.warning }} />
            특화 기능 아이템
            <span className="text-xs font-normal text-slate-500">(요금제 정합 검증 시 별도 처리가 필요한 KT 특화 로직)</span>
          </div>
          <div className="text-xs text-slate-500">총 <span className="font-semibold">15</span>개 특화기능 · <span className="font-semibold">2,847</span>개 아이템</div>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-3">요율유형</th>
              <th className="text-left py-2 px-3">카테고리</th>
              <th className="text-left py-2 px-3">특화기능</th>
              <th className="text-right py-2 px-3">아이템건수</th>
              <th className="text-right py-2 px-3">상품건수</th>
              <th className="text-left py-2 px-3 pl-6">상품명 (샘플)</th>
              <th className="text-right py-2 px-3">검증 상태</th>
            </tr>
          </thead>
          <tbody>
            {specialFeatures.map((row, i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2 px-3 font-mono text-xs font-semibold" style={{ color: c.primary }}>{row[0]}</td>
                <td className="py-2 px-3">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium" style={{
                    background: row[1] === '데이터' ? `${c.accent}20` : row[1] === '음성' ? '#e0e7ff' : `${c.warning}20`,
                    color: row[1] === '데이터' ? c.accent : row[1] === '음성' ? '#4338ca' : c.warning,
                  }}>{row[1]}</span>
                </td>
                <td className="py-2 px-3 text-xs text-slate-700 max-w-md">{row[2]}</td>
                <td className="py-2 px-3 text-right tabular-nums font-semibold">{row[3].toLocaleString()}</td>
                <td className="py-2 px-3 text-right tabular-nums text-slate-600">{row[4]}</td>
                <td className="py-2 px-3 pl-6 text-xs text-slate-600">{row[5]}</td>
                <td className="py-2 px-3 text-right">
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold" style={{
                    background: row[6] === '검증완료' ? `${c.success}20` : row[6] === '검증중' ? `${c.warning}20` : '#f1f5f9',
                    color: row[6] === '검증완료' ? c.success : row[6] === '검증중' ? c.warning : '#64748b',
                  }}>{row[6]}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};
