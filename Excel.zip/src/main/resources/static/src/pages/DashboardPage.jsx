const { useState, useEffect } = React;
const { Hash, CircleDollarSign, Layers, Play, CheckCircle2 } = lucide;

const DashboardPage = ({ c, month }) => {
  const [batchStatus, setBatchStatus] = useState({
    SNAPSHOT:   { status: 'IDLE', processedCount: 0, totalCount: 0, jobId: null },
    EXTRACTION: { status: 'IDLE', processedCount: 0, totalCount: 0, jobId: null },
    COMPARISON: { status: 'DONE', processedCount: 1, totalCount: 1, jobId: '6aa6525a-583c-46b9-9a18-6a6968413f1b' },
    REPORT:     { status: 'IDLE', processedCount: 0, totalCount: 0, jobId: null },
  });
  const [summary, setSummary] = useState(null);
  const [loadingStep, setLoadingStep] = useState(null);

  const isAnyRunning = Object.values(batchStatus).some(s => s.status === 'RUNNING');

  useEffect(() => {
    if (!isAnyRunning) return;
    const timer = setInterval(() => {
      api.fetchBatchStatus()
        .then(res => { if (res.success) setBatchStatus(res.data); })
        .catch(() => {});
    }, 3000);
    return () => clearInterval(timer);
  }, [isAnyRunning]);

  const handleExecute = (step, jobType) => {
    setLoadingStep(step);
    api.executeStep(step, month)
      .then(res => {
        if (res.success) {
          setBatchStatus(prev => ({
            ...prev,
            [jobType]: { ...prev[jobType], status: 'RUNNING', processedCount: 0 },
          }));
        }
      })
      .catch(() => {})
      .finally(() => setLoadingStep(null));
  };

  const steps = [
    { step: 1, jobType: 'SNAPSHOT',   title: '상품 스냅샷 생성',   tag: 'snapshot',   desc: '기준월 기준 유효한 상품/패키지/아이템 데이터 추출 및 스냅샷 저장' },
    { step: 2, jobType: 'EXTRACTION', title: '테스트 고객 추출',   tag: 'extract',    desc: '발생 아이템 기준 고객 추출 (아이템별 10명 + 상품 보완 + 특이케이스)' },
    { step: 3, jobType: 'COMPARISON', title: '데이터 비교 정합',   tag: 'validate',   desc: '신구 시스템 과금 결과 정합성 비교 및 불일치 사유 분석' },
    { step: 4, jobType: 'REPORT',     title: '레포트 데이터 생성', tag: 'report-gen', desc: '검증 결과를 바탕으로 통계 및 시각화용 데이터 가공' },
  ];

  const statusLabel = (s) => ({ IDLE: '미실행', RUNNING: '실행중', DONE: '완료', FAILED: '실패' }[s] || s);
  const statusPct   = (bs) => {
    if (bs.status === 'DONE') return 100;
    if (bs.status === 'RUNNING' && bs.totalCount > 0) return Math.round((bs.processedCount / bs.totalCount) * 100);
    if (bs.status === 'RUNNING') return 45;
    return 0;
  };

  return (
    <>
      <PageHeader c={c} month={month} title="대시보드" screen="dashboard" />

      <div className="grid grid-cols-3 gap-4 mb-5">
        {[
          { icon: Hash,            label: '건수 정합률',   value: summary ? summary.countRate  : '0.0%' },
          { icon: CircleDollarSign, label: '금액 정합률',  value: summary ? summary.amountRate : '0.0%' },
          { icon: Layers,           label: '컬링값 정합률', value: summary ? summary.cullingRate : '0.0%' },
        ].map((card, i) => {
          const Icon = card.icon;
          return (
            <div key={i} className="bg-white rounded p-4" style={{ border: `2px solid ${c.primary}30` }}>
              <Icon className="w-5 h-5 mb-2" style={{ color: c.primary }} />
              <div className="text-xs mb-1" style={{ color: c.primary }}>{card.label}</div>
              <div className="text-3xl font-bold" style={{ color: c.primary }}>{card.value}</div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-5">
        <div className="bg-white rounded p-4 border border-slate-200">
          <div className="text-sm font-semibold text-slate-800 mb-3">종합 정합 현황</div>
          <div className="flex flex-col items-center justify-center h-44">
            <div className="relative w-32 h-32 rounded-full flex items-center justify-center" style={{ border: `8px solid ${c.primary}30` }}>
              <div className="text-center">
                <div className="text-2xl font-bold text-slate-900">{summary ? summary.totalRate : '0.0%'}</div>
                <div className="text-xs text-slate-500">종합 정합률</div>
              </div>
            </div>
            <div className="flex gap-3 mt-3 text-xs text-slate-600">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm" style={{ background: c.success }} />일치</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-sm" style={{ background: c.danger }} />불일치</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded p-4 border border-slate-200">
          <div className="text-sm font-semibold text-slate-800 mb-3">비교 건수 요약</div>
          <div className="space-y-2 text-sm">
            {[
              { label: '전체 레코드 수', v: summary ? summary.totalCount  : '—', color: '#334155' },
              { label: '일치 건수',      v: summary ? summary.matchCount  : '—', dot: c.success, color: c.success },
              { label: '불일치 건수',    v: summary ? summary.mismatchCount : '—', dot: c.danger,  color: c.danger },
            ].map((r, i) => (
              <div key={i} className="flex items-center justify-between border-b border-slate-100 py-1.5">
                <span className="flex items-center gap-2">
                  {r.dot && <span className="w-2 h-2 rounded-sm" style={{ background: r.dot }} />}
                  <span className="text-slate-700">{r.label}</span>
                </span>
                <span className="font-semibold tabular-nums" style={{ color: r.color }}>{r.v}</span>
              </div>
            ))}
            <div className="grid grid-cols-3 gap-2 mt-3 text-center">
              {['건수', '금액', '컬링값'].map((l) => (
                <div key={l} className="bg-slate-50 rounded p-2">
                  <div className="text-xs text-slate-500">{l}</div>
                  <div className="text-sm font-bold text-slate-800">0.0%</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded p-4 border border-slate-200">
        <div className="flex items-center justify-between mb-4">
          <div className="text-sm font-semibold text-slate-800">배치 실행 현황</div>
          <div className="text-xs text-slate-600">실행 대상 월 <span className="bg-slate-100 px-2 py-0.5 rounded font-medium">{month}</span></div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {steps.map((s) => {
            const bs = batchStatus[s.jobType];
            const pct = statusPct(bs);
            const done = bs.status === 'DONE';
            const running = bs.status === 'RUNNING';
            const failed = bs.status === 'FAILED';
            const barColor = done ? c.primary : running ? c.accent : failed ? c.danger : '#94a3b8';
            const labelColor = done ? c.primary : running ? c.accent : failed ? c.danger : '#64748b';
            const labelBg = done ? `${c.primary}15` : running ? `${c.accent}15` : failed ? `${c.danger}15` : '#f1f5f9';
            return (
              <div key={s.step} className="border border-slate-200 rounded p-3">
                <div className="flex items-center justify-between mb-1">
                  <div className="font-semibold text-sm text-slate-800 flex items-center gap-1.5">
                    STEP {s.step} — {s.title}
                    {done && <CheckCircle2 className="w-3.5 h-3.5" style={{ color: c.success }} />}
                  </div>
                  <span className="text-xs text-slate-500 font-mono">{s.tag}</span>
                </div>
                <div className="text-xs text-slate-500 mb-2">{s.desc}</div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs px-2 py-0.5 rounded font-medium" style={{ background: labelBg, color: labelColor }}>{statusLabel(bs.status)}</span>
                  <div className="flex-1 h-2 bg-slate-100 rounded overflow-hidden">
                    <div className="h-full transition-all" style={{ width: `${pct}%`, background: barColor }} />
                  </div>
                  <span className="text-xs text-slate-500 tabular-nums w-10 text-right">{pct}%</span>
                </div>
                {bs.jobId && <div className="text-[10px] text-slate-400 mt-1 truncate font-mono">Job ID: {bs.jobId}</div>}
                <div className="flex gap-2 mt-2 flex-wrap">
                  <button
                    onClick={() => handleExecute(s.step, s.jobType)}
                    disabled={running || loadingStep === s.step}
                    className="px-2 py-1 rounded text-white text-xs flex items-center gap-1 disabled:opacity-50"
                    style={{ background: c.accent }}
                  >
                    <Play className="w-3 h-3" /> STEP {s.step} 실행
                  </button>
                  {s.step === 3 && (
                    <>
                      <button className="px-2 py-1 rounded text-xs" style={{ background: `${c.primary}15`, color: c.primary }}>⚡ 간단비교</button>
                      <button className="px-2 py-1 rounded text-xs" style={{ background: `${c.primary}15`, color: c.primary }}>⚡ 사유분석 재실행</button>
                    </>
                  )}
                  <button className="px-2 py-1 rounded bg-slate-100 text-slate-700 text-xs hover:bg-slate-200">상태 확인</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};
