const { useState: useStateP } = React;
const { Package: PkgP, CheckCircle2: CC2P, AlertTriangle: AlertP, XCircle, Smartphone, PlusCircle, Wifi } = lucide;

const ProductPage = ({ c, month }) => {
  const [topTab, setTopTab] = useStateP('m-rate');
  const [unusedTab, setUnusedTab] = useStateP('m-rate');

  const tabs = [
    { id: 'm-rate',  label: '무선 요금제',  icon: Smartphone },
    { id: 'm-addon', label: '무선 부가상품', icon: PlusCircle },
    { id: 'w-rate',  label: '유선 요금제',  icon: Wifi },
    { id: 'w-addon', label: '유선 부가상품', icon: Wifi },
  ];

  const topData = {
    'm-rate': [
      ['BSSIOTPP1','헬로표준','3,132,462','12.8%','1','1','100.0%','0'],
      ['PL23B1942','5G 슬림 4GB','939,226','3.84%','65','65','100.0%','4'],
      ['5GINTMPP2','5G 슬림 14GB','831,803','3.4%','65','65','100.0%','1'],
      ['5GINTMPP3','베이직','697,324','2.85%','65','65','100.0%','4'],
      ['KDRTLTE40','LTE 베이직','615,335','2.51%','62','62','100.0%','4'],
      ['PL225V838','5G 심플 30GB','611,458','2.5%','65','65','100.0%','4'],
      ['5GINTMPP7','5G 심플 110GB','581,912','2.38%','65','65','100.0%','3'],
      ['DATATGWRA','데이터 투게더 Wearable','563,463','2.3%','51','51','100.0%','75'],
      ['PL2093132','5G 슬림 7GB','545,766','2.23%','65','65','100.0%','0'],
      ['W3GMONITR','3G중계기감시용','519,513','2.12%','1','1','100.0%','0'],
    ],
    'm-addon': [
      ['SMARTNMON','스마트폰(종량)-일반','15,461,013','23.89%','6','6','100.0%','82'],
      ['5GDTCHDEF','5G 무료채널','9,472,267','14.64%','16','16','100.0%','0'],
      ['5GDTRM080','슈퍼팬 베이직','1,844,826','2.85%','1','1','100.0%','0'],
      ['VOICEDEF1','기본음성 부가','1,253,409','1.94%','4','4','100.0%','2'],
      ['DATAGFTOP','데이터 선물하기','987,514','1.53%','8','8','100.0%','5'],
      ['SAFEDRIVE','안전운전 부가','754,201','1.17%','3','3','100.0%','1'],
      ['MELONPACK','멜론 스트리밍 팩','612,890','0.95%','2','2','100.0%','3'],
      ['TMAPNAVI1','T맵 내비게이션','554,128','0.86%','5','5','100.0%','0'],
      ['VIDEOEXT2','영상통화 확장','421,567','0.65%','4','4','100.0%','0'],
      ['DATAROAM3','데이터 로밍 안심','389,201','0.6%','12','12','100.0%','1'],
    ],
    'w-rate': [
      ['0V2101','biz 인터넷전화 Centrex','1,260,769','44.6%','36','36','100.0%','0'],
      ['0V1201','biz 인터넷전화','565,184','19.99%','25','25','100.0%','0'],
      ['0V0201','인터넷전화 Home','429,583','15.2%','37','37','100.0%','0'],
      ['0V1601','biz 인터넷전화 고급형','313,664','11.1%','23','23','100.0%','0'],
      ['0V1401','biz 국가정보통신 C그룹','52,998','1.87%','29','29','100.0%','0'],
      ['0V5101','스마트홈_폰','13,610','0.48%','9','9','100.0%','0'],
    ],
    'w-addon': [
      ['WIPHADD01','와이파이 확장팩','85,432','5.1%','4','4','100.0%','0'],
      ['IPTVADD02','IPTV 채널 추가','54,128','3.23%','8','8','100.0%','1'],
      ['LANDLINE3','유선 부가서비스','32,891','1.96%','5','5','100.0%','0'],
      ['INTERNET4','인터넷 보안팩','21,054','1.26%','3','3','100.0%','0'],
      ['VOICEMAIL','음성사서함','15,632','0.93%','2','2','100.0%','0'],
      ['CALLERID5','발신자번호표시','12,408','0.74%','1','1','100.0%','0'],
    ],
  };

  const unusedData = {
    'm-rate': [
      ['OLD3GLG01','3G LG 구형 요금제','8,432','0.03%','—','0','2024-08-12','사용없음'],
      ['LEGACY2G1','2G 종량형','5,128','0.02%','—','0','2024-06-30','사용없음'],
      ['TESTPROD1','테스트용 요금제 A','2,891','0.01%','—','0','2025-02-15','테스트'],
      ['PROMO2024','2024 프로모션 종료','1,054','0.00%','—','0','2024-12-31','종료'],
      ['INACTIV01','휴면 전용 요금제','832','0.00%','—','0','2024-11-20','휴면'],
      ['DISCONT02','단종 데이터팩','421','0.00%','—','0','2024-05-10','단종'],
      ['SPECEVT01','특별 이벤트 종료','289','0.00%','—','0','2024-09-30','종료'],
      ['BETATEST1','베타 테스트 요금제','154','0.00%','—','0','2025-01-05','베타'],
      ['LIMITED01','한정판 요금제 A','98','0.00%','—','0','2024-12-15','한정판'],
      ['TEMPHOLD1','임시 보류 요금제','42','0.00%','—','0','2025-03-20','보류'],
    ],
    'm-addon': [
      ['ADDLEGACY','구형 부가 A','4,201','—','—','0','2024-07-15','단종'],
      ['OLDVOICE2','구 음성 부가','2,508','—','—','0','2024-05-22','단종'],
      ['DEPRADD03','단종 데이터 부가','1,892','—','—','0','2024-03-10','단종'],
      ['TESTADD04','테스트 부가','1,234','—','—','0','2025-02-01','테스트'],
      ['EVENTADD5','이벤트 부가 종료','754','—','—','0','2024-10-30','종료'],
    ],
    'w-rate': [
      ['OLDWIRE01','구형 유선 A','234','—','—','0','2024-06-15','단종'],
      ['LEGACYW02','유선 종량 구형','128','—','—','0','2024-04-20','단종'],
    ],
    'w-addon': [
      ['OLDWADD01','구형 유선 부가','521','—','—','0','2024-08-22','단종'],
      ['DEPRWADD2','단종 유선 부가','342','—','—','0','2024-05-15','단종'],
      ['TESTWADD3','테스트 유선 부가','188','—','—','0','2025-01-10','테스트'],
    ],
  };

  const noSubData = [
    ['NOSUB001','신규 미출시 요금제 A','무선 요금제','준비중','2025-12-15'],
    ['NOSUB002','준비중인 부가서비스','무선 부가상품','준비중','2025-12-20'],
    ['NOSUB003','테스트용 상품 코드','무선 요금제','테스트','2025-11-30'],
    ['NOSUB004','내부 검증 상품','유선 요금제','내부용','2025-10-15'],
    ['NOSUB005','마이그레이션 임시','무선 부가상품','임시','2025-09-22'],
    ['NOSUB006','신상품 후보 B','유선 부가상품','준비중','2025-12-01'],
    ['NOSUB007','베타 미출시','무선 요금제','베타','2025-11-10'],
    ['NOSUB008','마켓 종료 후보','유선 요금제','검토중','2025-10-30'],
  ];

  const TabToggle = ({ activeId, onChange, activeColor }) => (
    <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
      {tabs.map((t) => {
        const TIcon = t.icon;
        const active = activeId === t.id;
        return (
          <button
            key={t.id}
            onClick={() => onChange(t.id)}
            className="px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 transition"
            style={{
              background: active ? 'white' : 'transparent',
              color: active ? activeColor : '#64748b',
              boxShadow: active ? '0 1px 2px rgba(0,0,0,0.05)' : 'none',
            }}
          >
            <TIcon className="w-3.5 h-3.5" />
            {t.label}
          </button>
        );
      })}
    </div>
  );

  return (
    <>
      <PageHeader c={c} month={month} title="상품별 커버리지 상세" screen="product" />

      <div className="bg-white rounded p-4 border border-slate-200 mb-4">
        <div className="text-sm font-semibold text-slate-800 mb-3 flex items-center gap-2">
          <PkgP className="w-4 h-4" style={{ color: c.primary }} />
          상품 유형별 요약
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-slate-700 border-b-2" style={{ borderColor: c.headerBg }}>
              <th className="text-left py-2 px-3 font-semibold">구분</th>
              <th className="text-right py-2 px-3 font-semibold"><Smartphone className="w-3 h-3 inline mr-1" />무선 요금제</th>
              <th className="text-right py-2 px-3 font-semibold"><Wifi className="w-3 h-3 inline mr-1" />유선 요금제</th>
              <th className="text-right py-2 px-3 font-semibold"><PlusCircle className="w-3 h-3 inline mr-1" />무선 부가상품</th>
              <th className="text-right py-2 px-3 font-semibold"><PlusCircle className="w-3 h-3 inline mr-1" />유선 부가상품</th>
            </tr>
          </thead>
          <tbody>
            {[
              ['전체 상품 수',       '7,202개','42개','1,879개','96개'],
              ['정합 대상 상품 수',  '52개',   '0개', '42개',   '0개'],
              ['가입자 없는 상품 수','2,966개','15개','1,238개','15개'],
              ['사용내역 없는 상품 수','4,184개','27개','599개','81개'],
            ].map(([k, ...vs], i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2 px-3 text-slate-700 font-medium">{k}</td>
                {vs.map((v, j) => <td key={j} className="py-2 px-3 text-right tabular-nums text-slate-700">{v}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-white rounded p-4 border border-slate-200 mb-4">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <CC2P className="w-4 h-4" style={{ color: c.success }} />
            가입자 상위 10개 상품
          </div>
          <TabToggle activeId={topTab} onChange={setTopTab} activeColor={c.primary} />
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-3">상품코드</th>
              <th className="text-left py-2 px-3">상품명</th>
              <th className="text-right py-2 px-3">전체 가입자 수</th>
              <th className="text-right py-2 px-3">가입자 비율</th>
              <th className="text-right py-2 px-3">발생 아이템</th>
              <th className="text-right py-2 px-3">추출 아이템</th>
              <th className="text-right py-2 px-3">검증 결과</th>
              <th className="text-right py-2 px-3">추출 고객수</th>
            </tr>
          </thead>
          <tbody>
            {(topData[topTab] || []).map((row, i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2 px-3 font-mono text-xs text-slate-600">{row[0]}</td>
                <td className="py-2 px-3 text-slate-700">{row[1]}</td>
                <td className="py-2 px-3 text-right tabular-nums font-semibold text-slate-800">{row[2]}</td>
                <td className="py-2 px-3 text-right tabular-nums text-slate-600">{row[3]}</td>
                <td className="py-2 px-3 text-right tabular-nums">{row[4]}</td>
                <td className="py-2 px-3 text-right tabular-nums">{row[5]}</td>
                <td className="py-2 px-3 text-right">
                  <span className="px-2 py-0.5 rounded text-xs font-semibold tabular-nums" style={{ background: `${c.success}20`, color: c.success }}>{row[6]}</span>
                </td>
                <td className="py-2 px-3 text-right tabular-nums">{row[7]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-white rounded p-4 border border-slate-200 mb-4">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <AlertP className="w-4 h-4" style={{ color: c.warning }} />
            사용내역 없는 상품 — 가입자 상위 10개
            <span className="text-xs font-normal text-slate-500">(가입자는 있으나 PIT 추출 불가 → 검증 대상 제외)</span>
          </div>
          <TabToggle activeId={unusedTab} onChange={setUnusedTab} activeColor={c.warning} />
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-3">상품코드</th>
              <th className="text-left py-2 px-3">상품명</th>
              <th className="text-right py-2 px-3">가입자 수</th>
              <th className="text-right py-2 px-3">가입자 비율</th>
              <th className="text-right py-2 px-3">발생 아이템</th>
              <th className="text-right py-2 px-3">사용내역</th>
              <th className="text-right py-2 px-3">최근 사용일</th>
              <th className="text-right py-2 px-3">상태</th>
            </tr>
          </thead>
          <tbody>
            {(unusedData[unusedTab] || []).map((row, i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50 text-slate-500">
                <td className="py-2 px-3 font-mono text-xs">{row[0]}</td>
                <td className="py-2 px-3">{row[1]}</td>
                <td className="py-2 px-3 text-right tabular-nums">{row[2]}</td>
                <td className="py-2 px-3 text-right tabular-nums">{row[3]}</td>
                <td className="py-2 px-3 text-right tabular-nums">{row[4]}</td>
                <td className="py-2 px-3 text-right tabular-nums">{row[5]}</td>
                <td className="py-2 px-3 text-right text-xs">{row[6]}</td>
                <td className="py-2 px-3 text-right">
                  <span className="px-2 py-0.5 rounded text-xs font-medium bg-slate-200 text-slate-600">{row[7]}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-white rounded p-4 border border-slate-200">
        <div className="flex items-center justify-between mb-3">
          <div className="text-sm font-semibold text-slate-800 flex items-center gap-2">
            <XCircle className="w-4 h-4" style={{ color: c.danger }} />
            가입자 없는 상품 — 샘플
            <span className="text-xs font-normal text-slate-500">(전체 4,234개 중 8개 샘플)</span>
          </div>
          <button className="px-2 py-1 rounded text-xs flex items-center gap-1 border" style={{ borderColor: c.primary, color: c.primary, background: 'white' }}>전체 보기</button>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-3">상품코드</th>
              <th className="text-left py-2 px-3">상품명</th>
              <th className="text-left py-2 px-3">상품 유형</th>
              <th className="text-left py-2 px-3">분류</th>
              <th className="text-right py-2 px-3">등록일</th>
            </tr>
          </thead>
          <tbody>
            {noSubData.map((row, i) => (
              <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-2 px-3 font-mono text-xs text-slate-600">{row[0]}</td>
                <td className="py-2 px-3 text-slate-700">{row[1]}</td>
                <td className="py-2 px-3 text-xs text-slate-600">{row[2]}</td>
                <td className="py-2 px-3">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium" style={{
                    background: row[3] === '준비중' ? `${c.accent}20` : (row[3] === '테스트' || row[3] === '베타') ? `${c.warning}20` : '#f1f5f9',
                    color: row[3] === '준비중' ? c.accent : (row[3] === '테스트' || row[3] === '베타') ? c.warning : '#64748b',
                  }}>{row[3]}</span>
                </td>
                <td className="py-2 px-3 text-right text-xs text-slate-500">{row[4]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};
