const { Smartphone, Wifi } = lucide;

const MismatchPage = ({ c, month }) => {
  const summaryMetrics = [
    { label: '전체 건수',   sub: null,         value: '—',    isRate: false },
    { label: '고객 건수',   sub: null,         value: '—',    isRate: false },
    { label: '금액 정합율', sub: null,         value: '0.0%', isRate: true  },
    { label: '건수 정합율', sub: null,         value: '0.0%', isRate: true  },
    { label: '금액 정합율', sub: '(고객단위)', value: '0.0%', isRate: true  },
    { label: '건수 정합율', sub: '(고객단위)', value: '0.0%', isRate: true  },
  ];

  return (
    <>
      <PageHeader c={c} month={month} title="정합결과 상세 조회" screen="mismatch" />

      {/* 전체 정합률 요약 — 모바일 / 인터넷전화 */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        {[
          { label: '모바일',    Icon: Smartphone },
          { label: '인터넷전화', Icon: Wifi       },
        ].map(({ label, Icon }, ci) => (
          <div key={ci} className="bg-white rounded border border-slate-200 p-4">
            <div className="flex items-center gap-2 mb-4 pb-2 border-b-2" style={{ borderColor: c.primary }}>
              <Icon className="w-4 h-4" style={{ color: c.primary }} />
              <span className="text-sm font-semibold" style={{ color: c.primary }}>{label}</span>
            </div>
            <div className="flex flex-col">
              {summaryMetrics.map((item, ii) => (
                <div
                  key={ii}
                  className="flex items-center justify-between py-2 border-b border-slate-100 last:border-b-0"
                >
                  <span className="text-xs text-slate-600">
                    {item.label}
                    {item.sub && <span className="text-slate-400"> {item.sub}</span>}
                  </span>
                  <span
                    className="text-sm font-semibold tabular-nums"
                    style={{ color: item.isRate ? c.primary : '#1e293b' }}
                  >
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* 불일치 분석 */}
      <div className="grid grid-cols-2 gap-4 mb-4">
        {['불일치 분석 - 건수', '불일치 분석 - 금액'].map((title, idx) => (
          <div key={idx} className="bg-white rounded p-4 border border-slate-200">
            <div className="text-sm font-semibold text-slate-800 mb-3">{title}</div>
            <div className="flex items-end gap-4 h-44 mb-3 relative">
              <div className="flex-1 h-full bg-slate-50 rounded relative">
                <div className="absolute inset-0 flex flex-col justify-between text-[10px] text-slate-400 p-2 pointer-events-none">
                  {[1.0, 0.8, 0.6, 0.4, 0.2, 0].map((v) => <span key={v}>{v.toFixed(1)}</span>)}
                </div>
              </div>
            </div>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-white text-xs" style={{ background: c.headerBg }}>
                  <th className="text-left py-1.5 px-2">유형</th>
                  <th className="text-right py-1.5 px-2">{idx === 0 ? '전체 건수' : '전체 금액'}</th>
                  <th className="text-right py-1.5 px-2">{idx === 0 ? '불일치 건수' : '불일치 금액'}</th>
                  <th className="text-right py-1.5 px-2">정합률</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-slate-100">
                  <td className="py-2 px-2 font-medium">합계</td>
                  <td className="py-2 px-2 text-right">—</td>
                  <td className="py-2 px-2 text-right">—</td>
                  <td className="py-2 px-2 text-right">
                    <span className="px-2 py-0.5 rounded text-xs font-semibold" style={{ background: `${c.warning}20`, color: c.warning }}>0.0%</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ))}
      </div>

      {/* 불일치 상세 내역 */}
      <div className="bg-white rounded p-4 border border-slate-200">
        <div className="text-sm font-semibold text-slate-800 mb-3">불일치 상세 내역</div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-white text-xs" style={{ background: c.headerBg }}>
              <th className="text-left py-2 px-3">유형</th>
              <th className="text-left py-2 px-3">카테고리</th>
              <th className="text-left py-2 px-3">불일치 유형</th>
              <th className="text-left py-2 px-3">불일치 사유</th>
              <th className="text-right py-2 px-3">건수</th>
            </tr>
          </thead>
          <tbody>
            <tr><td colSpan="5" className="py-10 text-center text-xs text-slate-400">데이터가 없습니다.</td></tr>
          </tbody>
        </table>
      </div>
    </>
  );
};
