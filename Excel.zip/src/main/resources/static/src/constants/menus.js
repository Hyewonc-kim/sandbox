const { LayoutDashboard, Target, Package, Tag, AlertTriangle, Search } = lucide;

const MENUS = [
  { id: "dashboard", label: "대시보드",      icon: LayoutDashboard },
  { id: "coverage",  label: "커버리지 현황", icon: Target },
  { id: "product",   label: "상품별 현황",   icon: Package },
  { id: "item",      label: "아이템별 현황", icon: Tag },
  { id: "mismatch",  label: "정합결과 상세", icon: AlertTriangle },
  { id: "ratCheck",  label: "RAT 사전 체크", icon: Search },
];
