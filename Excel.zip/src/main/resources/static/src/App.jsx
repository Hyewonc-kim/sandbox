const { useState: useStateApp } = React;
const { ChevronDown, ChevronLeft, ChevronRight, CheckCircle2: CC2App } = lucide;

const App = () => {
  const [palette, setPalette] = useStateApp('beigeGreen');
  const [activeMenu, setActiveMenu] = useStateApp('dashboard');
  const [month, setMonth] = useStateApp('202601');
  const [showMonthPicker, setShowMonthPicker] = useStateApp(false);
  const [pickerYear, setPickerYear] = useStateApp(2026);

  const c = PALETTES[palette];

  const renderPage = () => {
    switch (activeMenu) {
      case 'dashboard': return React.createElement(DashboardPage, { c, month });
      case 'coverage':  return React.createElement(CoveragePage,  { c, month });
      case 'product':   return React.createElement(ProductPage,   { c, month });
      case 'item':      return React.createElement(ItemPage,      { c, month });
      case 'mismatch':  return React.createElement(MismatchPage,  { c, month });
      case 'ratCheck':  return React.createElement(RatCheckPage,  { c, month });
      default:          return React.createElement(DashboardPage, { c, month });
    }
  };

  const displayMonth = month.replace(/(\d{4})(\d{2})/, '$1년 $2월');

  const openPicker = () => {
    setPickerYear(parseInt(month.slice(0, 4), 10));
    setShowMonthPicker(true);
  };

  const selectMonth = (m) => {
    setMonth(`${pickerYear}${String(m).padStart(2, '0')}`);
    setShowMonthPicker(false);
  };

  return (
    <div className="h-screen overflow-hidden flex flex-col bg-slate-100">

      {/* 상단 헤더 — 고정 높이 */}
      <div className="flex-shrink-0 bg-white border-b border-slate-200 shadow-sm z-10">
        <div className="max-w-[1600px] mx-auto px-6 py-3">
          <div className="text-sm font-semibold text-slate-900">CCS 정합 검증</div>
          <div className="text-xs text-slate-500">KT Amdocs 마이그레이션 데이터 정합성 검증 시스템</div>
        </div>
      </div>

      {/* 본문 — 나머지 높이 전부 사용, 내부만 스크롤 */}
      <div className="flex-1 overflow-hidden">
        <div className="max-w-[1600px] mx-auto bg-white h-full flex">

          {/* 사이드바 — 뷰포트 내에서만 존재, 스크롤 없음 */}
          <aside className="w-56 flex-shrink-0 flex flex-col border-r border-slate-200" style={{ background: c.sidebar }}>
            <div className="p-4 border-b border-slate-200 flex-shrink-0">
              <div className="flex items-center gap-2 font-bold text-sm" style={{ color: c.primary }}>
                <div className="w-5 h-5 rounded" style={{ background: c.primary }} />
                CCS 정합 검증
              </div>
            </div>
            <div className="p-3 flex-shrink-0 relative">
              <div className="text-xs text-slate-500 mb-1">검증월</div>
              <button
                onClick={openPicker}
                className="w-full bg-white rounded border border-slate-300 px-2 py-1.5 text-sm flex items-center justify-between hover:border-slate-400"
              >
                {displayMonth}
                <ChevronDown
                  className="w-4 h-4 text-slate-400 transition-transform"
                  style={{ transform: showMonthPicker ? 'rotate(180deg)' : 'rotate(0deg)' }}
                />
              </button>

              {showMonthPicker && (
                <>
                  {/* 외부 클릭 시 닫기 */}
                  <div className="fixed inset-0 z-40" onClick={() => setShowMonthPicker(false)} />

                  {/* 드롭다운 피커 */}
                  <div className="absolute left-3 right-3 top-full mt-1 bg-white border border-slate-200 rounded-lg shadow-xl z-50 p-3">
                    {/* 연도 네비게이션 */}
                    <div className="flex items-center justify-between mb-3">
                      <button
                        onClick={(e) => { e.stopPropagation(); setPickerYear(y => y - 1); }}
                        className="w-6 h-6 flex items-center justify-center rounded hover:bg-slate-100 text-slate-600"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <span className="text-sm font-semibold text-slate-700">{pickerYear}년</span>
                      <button
                        onClick={(e) => { e.stopPropagation(); setPickerYear(y => y + 1); }}
                        className="w-6 h-6 flex items-center justify-center rounded hover:bg-slate-100 text-slate-600"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>

                    {/* 월 그리드 */}
                    <div className="grid grid-cols-3 gap-1">
                      {[1,2,3,4,5,6,7,8,9,10,11,12].map((m) => {
                        const val = `${pickerYear}${String(m).padStart(2, '0')}`;
                        const isSelected = val === month;
                        return (
                          <button
                            key={m}
                            onClick={(e) => { e.stopPropagation(); selectMonth(m); }}
                            className="py-1.5 rounded text-xs font-medium transition"
                            style={{
                              background: isSelected ? c.primary : 'transparent',
                              color: isSelected ? '#fff' : '#475569',
                            }}
                            onMouseEnter={(e) => { if (!isSelected) e.currentTarget.style.background = '#f1f5f9'; }}
                            onMouseLeave={(e) => { if (!isSelected) e.currentTarget.style.background = 'transparent'; }}
                          >
                            {m}월
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* 메뉴 — 남은 공간 차지, 항목 많으면 내부 스크롤 */}
            <nav className="px-2 mt-1 flex-1 overflow-y-auto">
              {MENUS.map((m) => {
                const Icon = m.icon;
                const active = activeMenu === m.id;
                const showDivider = m.id === 'ratCheck';
                return (
                  <div key={m.id}>
                    {showDivider && (
                      <div className="my-2 px-3">
                        <div className="border-t border-slate-200" />
                        <div className="text-[10px] text-slate-400 uppercase tracking-wider mt-2 mb-1 px-0">사전 점검</div>
                      </div>
                    )}
                    <button
                      onClick={() => setActiveMenu(m.id)}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded text-sm mb-0.5 transition"
                      style={{
                        background: active ? c.primaryLight : 'transparent',
                        color: active ? c.primary : '#475569',
                        fontWeight: active ? 600 : 400,
                      }}
                    >
                      <Icon className="w-4 h-4" />
                      {m.label}
                    </button>
                  </div>
                );
              })}
            </nav>

            {/* 테마 선택 — 항상 사이드바 하단에 고정 */}
            <div className="p-3 border-t border-slate-200 flex-shrink-0">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2 px-1">테마</div>
              <div className="space-y-1">
                {Object.entries(PALETTES).map(([key, p]) => {
                  const active = palette === key;
                  return (
                    <button
                      key={key}
                      onClick={() => setPalette(key)}
                      className="w-full flex items-center gap-2 px-2 py-1.5 rounded text-xs transition"
                      style={{
                        background: active ? c.primaryLight : 'transparent',
                        color: active ? c.primary : '#64748b',
                        fontWeight: active ? 600 : 400,
                      }}
                      onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = '#f8fafc'; }}
                      onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = 'transparent'; }}
                    >
                      <span className="flex gap-0.5 flex-shrink-0">
                        <span className="w-3 h-3 rounded-sm" style={{ background: p.primary }} />
                        <span className="w-3 h-3 rounded-sm" style={{ background: p.headerBg }} />
                      </span>
                      <span className="truncate">{p.name}</span>
                      {active && <CC2App className="w-3 h-3 ml-auto flex-shrink-0" style={{ color: c.primary }} />}
                    </button>
                  );
                })}
              </div>
            </div>
          </aside>

          {/* 메인 콘텐츠 — 독립적으로 스크롤 */}
          <main className="flex-1 p-6 bg-white overflow-y-auto">{renderPage()}</main>
        </div>
      </div>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(React.createElement(App));
