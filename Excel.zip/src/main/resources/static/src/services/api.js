const api = {
  fetchDashboardSummary: (month) =>
    fetch(`/api/dashboard/summary?baseMonth=${month}`).then(r => r.json()),

  fetchBatchStatus: () =>
    fetch('/api/dashboard/batch-status').then(r => r.json()),

  executeStep: (step, baseMonth) =>
    fetch(`/api/dashboard/step/${step}/execute?baseMonth=${baseMonth}`, { method: 'POST' }).then(r => r.json()),

  fetchCoverageProduct: (month) =>
    fetch(`/api/coverage/product?baseMonth=${month}`).then(r => r.json()),

  fetchCoverageItem: (month) =>
    fetch(`/api/coverage/item?baseMonth=${month}`).then(r => r.json()),

  fetchCoverageCustomer: (month) =>
    fetch(`/api/coverage/customer?baseMonth=${month}`).then(r => r.json()),

  fetchCustomerSummary: (month) =>
    fetch(`/api/customer/summary?baseMonth=${month}`).then(r => r.json()),

  fetchProductSummary: (month) =>
    fetch(`/api/product/summary?baseMonth=${month}`).then(r => r.json()),

  fetchItemSummary: (month) =>
    fetch(`/api/item/summary?baseMonth=${month}`).then(r => r.json()),

  fetchMismatchSummary: (month) =>
    fetch(`/api/mismatch/summary?baseMonth=${month}`).then(r => r.json()),

  fetchRatCheckTableMapping: (month) =>
    fetch(`/api/rat-check/table-mapping?baseMonth=${month}`).then(r => r.json()),

  fetchRatCheckIndexStatus: (month) =>
    fetch(`/api/rat-check/index-status?baseMonth=${month}`).then(r => r.json()),

  fetchRatCheckCycleInfo: (month) =>
    fetch(`/api/rat-check/cycle-info?baseMonth=${month}`).then(r => r.json()),

  fetchRatCheckRechargeStatus: (month) =>
    fetch(`/api/rat-check/recharge-status?baseMonth=${month}`).then(r => r.json()),

  fetchRatCheckProcessingStatus: (month) =>
    fetch(`/api/rat-check/processing-status?baseMonth=${month}`).then(r => r.json()),

  insertRatCheckRecharge: (month, customerId) =>
    fetch(`/api/rat-check/recharge?baseMonth=${month}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ customerId }),
    }).then(r => r.json()),

  insertRatCheckUpdateHandler: (month, requestId, beforeStatus) =>
    fetch(`/api/rat-check/update-handler?baseMonth=${month}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requestId, beforeStatus }),
    }).then(r => r.json()),

  fetchQuery: (screen, key) =>
    fetch(`/api/queries/${screen}/${key}`).then(r => r.json()),

  saveQuery: (screen, key, sql) =>
    fetch(`/api/queries/${screen}/${key}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql }),
    }).then(r => r.json()),

  exportData: (screen, month, format) => {
    window.location.href = `/api/export/${screen}?baseMonth=${month}&format=${format}`;
  },
};
