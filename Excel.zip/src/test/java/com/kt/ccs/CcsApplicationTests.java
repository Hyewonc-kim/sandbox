package com.kt.ccs;

import org.junit.jupiter.api.Test;

class CcsApplicationTests {

    @Test
    void contextLoads() {
    }
}
